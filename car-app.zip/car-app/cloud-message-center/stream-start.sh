#!/bin/bash

docker cp ./austin-stream/target/austin-stream-0.0.1-SNAPSHOT.jar austin_jobmanager_1:/opt/
docker exec -ti austin_jobmanager_1 flink run /opt/austin-stream-0.0.1-SNAPSHOT.jar

# stream local test
# docker cp ./push-stream-0.0.1-SNAPSHOT.jar austin_jobmanager_1:/opt/push-stream-test-0.0.1-SNAPSHOT.jar
# docker exec -ti austin_jobmanager_1 flink run /opt/push-stream-test-0.0.1-SNAPSHOT.jar


# data-house
# ./flink run push-data-house-0.0.1-SNAPSHOT.jar

