package com.xjmz.message.support.domain;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@TableName("t_message_inbox_message_category")
public class InboxMessageCategory {
    
    @TableId(value = "id",type = IdType.AUTO)
    private Long id;
    
    /**
     * 分类名称
     */
    @NotBlank(message = "分类名称不能为空")
    private String categoryName;
    
    /**
     * 分类介绍
     */
    private String categoryDesc;
    
    /**
     * 父分类ID
     */
    @NotNull(message = "父分类ID不能为空")
    private Long parentCategoryId;
    
    /**
     * 排序 
     */
    private Long sort;
    
    /**
     * 状态 
     */
    private Integer status;
    
    /**
     * 是否删除
     * 0：未删除
     * 1：已删除
     */
    private Integer deleteFlag;
    
    /**
     * 创建者
     */
    private String creator;
    
    /**
     * 修改者
     */
    private String updator;
    
    /**
     * 创建时间 单位 s
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    
    /**
     * 更新时间 单位s
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    
    @TableField(exist = false)
    private List<InboxMessageCategory> children;
    
}
