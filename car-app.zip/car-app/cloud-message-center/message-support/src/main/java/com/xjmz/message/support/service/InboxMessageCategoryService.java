package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.InboxMessageCategory;

import java.util.List;

public interface InboxMessageCategoryService extends IService<InboxMessageCategory> {
    
    List<InboxMessageCategory> tree();
    
    Boolean create(InboxMessageCategory imc);
    
    Boolean edit(InboxMessageCategory imc);
    
    Boolean delete(Long id);
}
