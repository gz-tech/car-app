package com.xjmz.message.support.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xjmz.message.support.vo.UserInboxMessageVo;
import com.xjmz.message.support.domain.UserInboxMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserInboxMessageMapper extends BaseMapper<UserInboxMessage> {
    
//    List<UserInboxMessageVo> pageList(UserInboxMessageQueryDto queryDto);
    
    Page<UserInboxMessageVo> pageList(Page page, @Param("title") String title, @Param("status") Integer status, @Param("categoryId") Long categoryId, @Param("userId") Long userId);
    
}
