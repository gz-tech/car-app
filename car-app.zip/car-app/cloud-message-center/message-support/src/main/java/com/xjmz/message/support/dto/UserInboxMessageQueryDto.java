package com.xjmz.message.support.dto;

import com.xjmz.message.common.enums.InboxMessageStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value = "站内信消息查询vo")
public class UserInboxMessageQueryDto {

    private static final long serialVersionUID = 1L;

    /**
     * @see InboxMessageStatus
     */
    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "消息标题")
    private String title;

    @ApiModelProperty(value = "用户ID")
    private Long userId;
    
    @ApiModelProperty(value = "消息分类")
    private Long categoryId;

}