package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.dto.UserInboxMessageQueryDto;
import com.xjmz.message.support.vo.PageVO;
import com.xjmz.message.support.vo.UserInboxMessageVo;
import com.xjmz.message.support.domain.UserInboxMessage;

public interface UserInboxMessageService extends IService<UserInboxMessage> {
    
    IPage<UserInboxMessageVo> listByPage(UserInboxMessageQueryDto userInboxMessageQueryDto, PageVO pageVO);
    
    Boolean editStatus( Long uimId, Long userId, Integer status);
}
