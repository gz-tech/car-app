package com.xjmz.message.support.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjmz.message.support.domain.ChannelAccount;
import org.apache.ibatis.annotations.Mapper;

/**
 * 渠道账号信息 Dao
 *
 * @author 3y
 */
@Mapper
public interface ChannelAccountMapper extends BaseMapper<ChannelAccount> {
    
}
