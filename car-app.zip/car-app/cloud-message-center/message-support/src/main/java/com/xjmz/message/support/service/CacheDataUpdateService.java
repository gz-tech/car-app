package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.CacheDataUpdate;

public interface CacheDataUpdateService extends IService<CacheDataUpdate> {
}
