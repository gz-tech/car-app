package com.xjmz.message.support.domain;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@TableName("t_message_inbox_message")
public class InboxMessage {
    
    @TableId(value = "id",type = IdType.AUTO)
    private Long id;
    
    /**
     * 标题
     */
    private String title;
    
    /**
     * 内容
     */
    private String content;
    
    /**
     * 分类ID
     */
    private Long categoryId;
    
    /**
     * 是否删除
     * 0：未删除
     * 1：已删除
     */
    private Integer deleteFlag;
    
    /**
     * 发送范围 
     */
//    private String messageRange;
    
    /**
     * 发送人ID 
     */
    private Long senderId;
    
    /**
     * 接收人ID 
     */
    private String recIds;
    
    /**
     * 创建者
     */
    private String creator;
    
    /**
     * 修改者
     */
    private String updator;
    
    /**
     * 创建时间 单位 s
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    
    /**
     * 更新时间 单位s
     */
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    
}
