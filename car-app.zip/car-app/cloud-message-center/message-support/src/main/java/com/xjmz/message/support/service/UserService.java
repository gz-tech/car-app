package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.User;
import com.meizu.usercenter.inner.model.MemberInfoVO;

public interface UserService extends IService<User> {
    
    User getByFlymeUserId(Long userId);
    
    MemberInfoVO getMemberInfoByFlymeUserId(Long userId);
    
    Boolean bindJPushRid(Long userId, String jpushRid);
    
}
