package com.xjmz.message.support.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjmz.message.support.domain.InboxMessageCategory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface InboxMessageCategoryMapper extends BaseMapper<InboxMessageCategory> {
    
    // 查询指定父类下的最大排序值 
    @Select("SELECT MAX(sort) FROM inbox_message_category WHERE parent_category_id = #{parentCategoryId} and delete_flag = 0")
    Long selectMaxSortByParentCategoryId(@Param("parentCategoryId") Long parentCategoryId);
    
    
    
}
