package com.xjmz.message.support.dto;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class InboxMessageCreateDto {
    
    private String recIds;
    private String title;
    private String content;
    private Long categoryId;
    
}
