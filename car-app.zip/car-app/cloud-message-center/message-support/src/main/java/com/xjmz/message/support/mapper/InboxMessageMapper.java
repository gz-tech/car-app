package com.xjmz.message.support.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjmz.message.support.domain.InboxMessage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface InboxMessageMapper extends BaseMapper<InboxMessage> {
    
}
