package com.xjmz.message.support.vo;

import lombok.Data;

import java.util.Date;

@Data
public class UserInboxMessageVo {
    
    private Long id;
    private Long userId;
    private String title;
    private String content;
    private Integer status;
    private Long categoryId;
    private Date createTime;
    private Date updateTime;
    
}
