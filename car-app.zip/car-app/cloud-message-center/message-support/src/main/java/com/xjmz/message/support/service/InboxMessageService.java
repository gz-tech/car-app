package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.InboxMessage;
import com.xjmz.message.support.dto.InboxMessageCreateDto;

public interface InboxMessageService extends IService<InboxMessage> {
    
    boolean create(InboxMessageCreateDto dto);
    
}
