package com.xjmz.message.support.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjmz.message.support.domain.SmsRecord;
import org.apache.ibatis.annotations.Mapper;


/**
 * 短信记录的Dao
 *
 * @author 3y
 */
@Mapper
public interface SmsRecordMapper extends BaseMapper<SmsRecord> {

}
