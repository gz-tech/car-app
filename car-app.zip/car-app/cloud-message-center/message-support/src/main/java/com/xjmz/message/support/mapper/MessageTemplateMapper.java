package com.xjmz.message.support.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjmz.message.support.domain.MessageTemplate;
import org.apache.ibatis.annotations.Mapper;


/**
 * 消息模板Dao
 *
 * @author 3y
 */
@Mapper
public interface MessageTemplateMapper extends BaseMapper<MessageTemplate> {
    

}
