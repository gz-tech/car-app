package com.xjmz.message.support.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.ChannelAccount;

import java.util.List;

/**
 * 渠道账号接口
 *
 * @author 3y
 */
public interface ChannelAccountService extends IService<ChannelAccount> {


    /**
     * 保存/修改渠道账号信息
     *
     * @param channelAccount
     * @return
     */
    boolean sou(ChannelAccount channelAccount);

    /**
     * 根据渠道标识查询账号信息
     *
     * @param channelType 渠道标识
     * @param creator     创建者
     * @return
     */
    List<ChannelAccount> queryByChannelType(Integer channelType, String creator);
    
    /**
     * 查询 列表
     *
     * @param channelType 渠道值
     * @return
     */
    List<ChannelAccount> queryBySendChannel(Integer channelType);


    /**
     * 列表信息
     *
     * @param creator
     * @return
     */
    List<ChannelAccount> list(String creator);

    /**
     * 软删除(deleted=1)
     *
     * @param ids
     */
    void deleteByIds(List<Long> ids);

}
