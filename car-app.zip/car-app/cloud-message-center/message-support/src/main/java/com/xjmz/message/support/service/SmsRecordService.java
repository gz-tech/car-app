package com.xjmz.message.support.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.message.support.domain.SmsRecord;

import java.util.List;

public interface SmsRecordService extends IService<SmsRecord> {
    
    /**
     * 通过日期和手机号找到发送记录
     *
     * @param phone
     * @param sendDate
     * @return
     */
    List<SmsRecord> findByPhoneAndSendDate(String phone, Integer sendDate);
    
}
