package com.xjmz.message.support.utils;

import cn.hutool.core.text.CharSequenceUtil;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xjmz.message.support.vo.PageVO;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * 分页工具
 *
 * @author Chopper
 * @version v4.0
 * @since 2020/11/26 15:23
 */
@Slf4j
public class PageUtil {

    //有order by 注入风险，限制长度
    static final Integer orderByLengthLimit = 20;

    /**
     * Mybatis-Plus分页封装
     *
     * @param page 分页VO
     * @param <T>  范型
     * @return 分页响应
     */
    public static <T> Page<T> initPage(PageVO page) {

        int pageNumber = page.getPage();
        int pageSize = page.getPerPage();
        String sort = page.getSort();
        String order = page.getOrder();

        if (pageNumber < 1) {
            pageNumber = 1;
        }
        if (pageSize < 1) {
            pageSize = 10;
        }
        if (pageSize > 100) {
            pageSize = 100;
        }

        Page<T> p = new Page<>(pageNumber, pageSize);

        if (CharSequenceUtil.isNotBlank(sort)) {

            if (sort.length() > orderByLengthLimit || SqlFilter.hit(sort)) {
                log.error("排序字段长度超过限制或包含sql关键字，请关注：{}", sort);
                return p;
            }

            boolean isAsc = false;
            if (!CharSequenceUtil.isBlank(order)) {
                if ("desc".equals(order.toLowerCase())) {
                    isAsc = false;
                } else if ("asc".equals(order.toLowerCase())) {
                    isAsc = true;
                }
            }

            if (isAsc) {
                p.addOrder(OrderItem.asc(sort));
            } else {
                p.addOrder(OrderItem.desc(sort));
            }

        }
        return p;
    }


    /**
     * List 手动分页
     *
     * @param page 分页对象
     * @param list 分页集合
     * @return 范型结果
     */
    public static <T> List<T> listToPage(PageVO page, List<T> list) {

        int pageNumber = page.getPage() - 1;
        int pageSize = page.getPerPage();

        if (pageNumber < 0) {
            pageNumber = 0;
        }
        if (pageSize < 1) {
            pageSize = 10;
        }
        if (pageSize > 100) {
            pageSize = 100;
        }

        int fromIndex = pageNumber * pageSize;
        int toIndex = pageNumber * pageSize + pageSize;

        if (fromIndex > list.size()) {
            return new ArrayList<>();
        } else if (toIndex >= list.size()) {
            return list.subList(fromIndex, list.size());
        } else {
            return list.subList(fromIndex, toIndex);
        }
    }

}
