package com.xjmz.message;

import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import org.junit.Test;

public class Demo1 {
    
    @Test
    public void test1(){
        String appId = "xjmzauto-mp";
        String nonce = RandomUtil.randomString(12);
        System.out.println("nonce: " + nonce);
        String secret = "xjmzauto-mp";
        String timestamp = System.currentTimeMillis() + "";
        System.out.println("timestamp: " + timestamp);
        String toSignStr = secret + appId + nonce +timestamp + secret;
        String sign = SecureUtil.md5(toSignStr);
        System.out.println("sign: " + sign);
    }
    
}
