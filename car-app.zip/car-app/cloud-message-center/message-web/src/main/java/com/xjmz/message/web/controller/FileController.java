package com.xjmz.message.web.controller;

import com.xjmz.message.common.vo.BasicResultVO;
import com.xjmz.message.support.service.bos.BosService;
import com.xjmz.message.web.annotation.AustinResult;
import com.xjmz.message.web.vo.FileUploadRespVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Api(tags = "文件管理")
@RestController
@RequestMapping("/admin/file/fos")
public class FileController {
    
    @Autowired
    private BosService bosService;
    
    @ApiOperation(value = "上传文件")
    @PostMapping("/upload")
    public BasicResultVO<FileUploadRespVo> upload(@RequestParam("file") MultipartFile file) throws IOException {
        return BasicResultVO.success(new FileUploadRespVo(bosService.upload(file)));
    }
    
    @ApiOperation(value = "下载文件")
    @GetMapping("/download/{fileName}")
    public void download(@PathVariable("fileName") String fileName, HttpServletResponse response) throws IOException {
        bosService.download(fileName, response);
    }
    
}
