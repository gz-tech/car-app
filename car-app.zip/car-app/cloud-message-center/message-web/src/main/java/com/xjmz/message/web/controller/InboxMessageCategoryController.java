package com.xjmz.message.web.controller;

import cn.hutool.core.util.StrUtil;
import com.xjmz.message.common.enums.RespStatusEnum;
import com.xjmz.message.common.vo.BasicResultVO;
import com.xjmz.message.support.domain.InboxMessageCategory;
import com.xjmz.message.support.service.InboxMessageCategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/inbox-message-category")
@Api(tags = "站内信消息分类接口")
@Validated
public class InboxMessageCategoryController {
    
    @Autowired
    private InboxMessageCategoryService inboxMessageCategoryService;
    
    @GetMapping("/tree")
    @ApiOperation("获取树形列表")
    public BasicResultVO<List<InboxMessageCategory>> tree() {
        return BasicResultVO.success(inboxMessageCategoryService.tree());
    }
    
    @PostMapping("/create")
    @ApiOperation("添加分类")
    public BasicResultVO<Boolean> create(@RequestBody @Validated InboxMessageCategory imc) {
        if (imc.getParentCategoryId() == null) {
            imc.setParentCategoryId(0L);
        }
        // 校验分类名称不能为空
//        if (StrUtil.isBlank(imc.getCategoryName())) {
//            return BasicResultVO.fail(RespStatusEnum.CLIENT_BAD_PARAMETERS,"分类名称不能为空");
//        }
        return BasicResultVO.success(inboxMessageCategoryService.create(imc));
    }
    
    @PostMapping("/update")
    @ApiOperation("更新分类")
    public BasicResultVO<Boolean> update(@RequestBody @Validated InboxMessageCategory imc) {
        // 校验分类名称不能为空
//        if (StrUtil.isBlank(imc.getCategoryName())) {
//            return BasicResultVO.fail(RespStatusEnum.CLIENT_BAD_PARAMETERS,"分类名称不能为空");
//        }
        return BasicResultVO.success(inboxMessageCategoryService.edit(imc));
    }
    
    @PostMapping("/delete")
    @ApiOperation("删除分类")
    public BasicResultVO<Boolean> delete(Long id) {
        return BasicResultVO.success(inboxMessageCategoryService.delete(id));
    }
    
    @GetMapping("/detail")
    @ApiOperation("分类详情")
    public BasicResultVO<InboxMessageCategory> detail(Long id) {
        return BasicResultVO.success(inboxMessageCategoryService.getById(id));
    }
}
 