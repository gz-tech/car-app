package com.xjmz.message;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.meizu.xjsd.platform.rocketmq.anno.EnableUnionRocketMQCluster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;


/**
 * @author 3y
 */
@SpringBootApplication(scanBasePackages = {"com.xjmz.dreamcar", "com.xjmz.message"})
@Slf4j
@EnableApolloConfig
@EnableUnionRocketMQCluster
@ImportResource({"classpath:spring-kiev-client.xml"})
//@EnableDynamicTp
public class MessageApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(MessageApplication.class, args);

    }
    
}
