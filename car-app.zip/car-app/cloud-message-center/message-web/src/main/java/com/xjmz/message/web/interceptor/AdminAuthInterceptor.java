package com.xjmz.message.web.interceptor;

import com.xjmz.message.common.enums.RespStatusEnum;
import com.xjmz.message.common.exception.CommonException;
import com.xjmzauto.portal.sdk.web.AuthCheckInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
@Slf4j
public class AdminAuthInterceptor extends AuthCheckInterceptor {
    
    @Override
    protected void handleNotLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        super.handleNotLogin(request, response);
        throw new CommonException(RespStatusEnum.NO_LOGIN);
    }
    
    @Override
    protected void handleAuthLimit(HttpServletRequest request, HttpServletResponse response) {
        super.handleAuthLimit(request, response);
        throw new CommonException(RespStatusEnum.ERROR_401);
    }
    
}
