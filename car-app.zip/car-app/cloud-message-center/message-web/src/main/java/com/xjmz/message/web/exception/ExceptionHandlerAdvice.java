package com.xjmz.message.web.exception;

import com.xjmz.message.common.exception.CommonException;
import com.xjmz.message.common.enums.RespStatusEnum;
import com.xjmz.message.common.vo.BasicResultVO;
import com.xjmz.message.support.utils.RequestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Throwables;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @author kl
 * @version 1.0.0
 * @description 拦截异常统一返回
 * @date 2023/2/9 19:03
 */
@ControllerAdvice(basePackages = "com.xjmz.message.web.controller")
@ResponseBody
public class ExceptionHandlerAdvice {
    private static final Logger log = LoggerFactory.getLogger(ExceptionHandlerAdvice.class);


    @ExceptionHandler({Throwable.class})
    @ResponseStatus(HttpStatus.OK)
    public BasicResultVO<String> exceptionResponse(Throwable e) {
        String errStackStr = Throwables.getStackTrace(e);
        log.error(errStackStr);
        return BasicResultVO.fail(RespStatusEnum.ERROR_500);
    }

    @ExceptionHandler({CommonException.class})
    @ResponseStatus(HttpStatus.OK)
    public BasicResultVO commonResponse(CommonException ce) {
        log.warn(Throwables.getStackTrace(ce));
        return new BasicResultVO(ce.getCode(), ce.getMessage(), ce.getRespStatusEnum());
    }
    
    @ExceptionHandler({IllegalArgumentException.class})
    @ResponseStatus(HttpStatus.OK)
    public BasicResultVO illegalArgumentException(IllegalArgumentException e) {
        log.error(Throwables.getStackTrace(e));
        return new BasicResultVO(RespStatusEnum.CLIENT_BAD_PARAMETERS.getCode(), e.getMessage());
    }
    
    @ExceptionHandler(value = {MethodArgumentNotValidException.class, BindException.class})
    public BasicResultVO validErrorHandler(MethodArgumentNotValidException e, HttpServletRequest request) {
        List<ObjectError> errors = e.getBindingResult().getAllErrors();
        
        StringBuffer errorStr = new StringBuffer();
        if (CollectionUtils.isNotEmpty(errors)) {
            errors.forEach(error-> errorStr.append(error.getDefaultMessage()).append(";"));
            errorStr.deleteCharAt(errorStr.lastIndexOf(";"));
        }
        log.warn("ValidException [errorMsg={}],[reqUrl={}],[ip={}]", errorStr, request.getRequestURI(), RequestUtils.getIpAddress(request));
        return new BasicResultVO(RespStatusEnum.CLIENT_BAD_PARAMETERS.getCode(), errorStr.toString());
    }
}

