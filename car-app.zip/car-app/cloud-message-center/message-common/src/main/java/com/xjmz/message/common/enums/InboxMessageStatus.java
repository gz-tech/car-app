package com.xjmz.message.common.enums;

import lombok.Getter;

/**
 * 消息状态枚举
 *
 * @author pikachu
 * @since 2020/12/8 9:46
 */
@Getter
public enum InboxMessageStatus {

    //未读消息
    UN_READY(0,"未读消息"),
    //已读消息
    ALREADY_READY(1,"已读消息"),
    //回收站
    ALREADY_REMOVE(-1,"回收站");

    private final Integer code;
    private final String description;

    InboxMessageStatus(Integer code, String description) {
        this.code = code;
        this.description = description;
    }
    

}
