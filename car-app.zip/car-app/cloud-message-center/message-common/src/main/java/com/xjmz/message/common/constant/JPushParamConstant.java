package com.xjmz.message.common.constant;

public class JPushParamConstant {
    
    public static final String REGISTRATION_ID = "registration_id";
    
}
