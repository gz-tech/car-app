package com.xjmz.message.common.constant;

public class GatewayConstant {
    
    public static final String HEADER_USER_ID = "xm-user-id";
    
}
