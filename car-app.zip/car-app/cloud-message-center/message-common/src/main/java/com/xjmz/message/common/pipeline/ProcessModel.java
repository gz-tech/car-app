package com.xjmz.message.common.pipeline;


/**
 * 真正存储着责任链的数据
 *
 * @author 3y
 */
public interface ProcessModel {

}
