package com.xjmz.dreamcar.gateway.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @Author: wulong
 * @Date: 2024/7/9 09:57
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Data
@ConfigurationProperties(prefix = "xjmzauto.gateway.sign")
public class GwProperties {

    /**
     * 是否启用
     */
    private boolean enabled;

    /**
     * appId 网关提供
     */
    private String appId;

    /**
     * Secret 网关提供
     */
    private String secret;

    /**
     * 拦截器顺序
     */
    private int order = 0;

    /**
     * 添加路径
     */
    private String[] addPath = new String[]{"/**"};

    /**
     * 排除路径
     */
    private String[] excludePath = new String[]{"/doc.html","/webjars/**","/swagger-resources","/v2/api-docs"};
}
