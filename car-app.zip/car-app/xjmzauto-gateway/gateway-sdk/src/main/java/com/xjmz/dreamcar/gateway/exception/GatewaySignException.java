package com.xjmz.dreamcar.gateway.exception;

/**
 * @Author: wulong
 * @Date: 2024/7/9 16:17
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
public class GatewaySignException extends RuntimeException{

    public GatewaySignException(String msg) {
        super(msg);
    }
}
