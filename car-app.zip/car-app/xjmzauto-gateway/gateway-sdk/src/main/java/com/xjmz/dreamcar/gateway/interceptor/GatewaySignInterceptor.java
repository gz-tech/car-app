package com.xjmz.dreamcar.gateway.interceptor;

import com.xjmz.dreamcar.gateway.exception.GatewaySignException;
import com.xjmz.dreamcar.gateway.sign.SignHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author: wulong
 * @Date: 2024/7/10 17:12
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
@Component
public class GatewaySignInterceptor implements HandlerInterceptor {

    @Autowired
    private SignHelper signHelper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!signHelper.checkSign(request)) {
            throw new GatewaySignException("Sign Error");
        }
        return true;
    }
}
