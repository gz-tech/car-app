package com.xjmz.dreamcar.gateway;

import com.xjmz.dreamcar.gateway.config.GwProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: wulong
 * @Date: 2024/7/8 17:26
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(GwProperties.class)
public class GatewayAutoConfiguration {

    public GatewayAutoConfiguration() {
        log.info("[Gateway] Sign Running...");
    }

}
