package com.xjmz.dreamcar.gateway.config;

import com.xjmz.dreamcar.gateway.interceptor.GatewaySignInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @Author: wulong
 * @Date: 2024/7/11 10:42
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
@Configuration
@ConditionalOnProperty(value = "xjmzauto.gateway.sign.enabled", havingValue = "true")
public class GatewaySignWebConfig implements WebMvcConfigurer {

    @Autowired
    private GwProperties properties;

    @Autowired
    private GatewaySignInterceptor gatewaySignInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(gatewaySignInterceptor)
                .order(properties.getOrder())
                .addPathPatterns(properties.getAddPath())
                .excludePathPatterns(properties.getExcludePath());
    }
}
