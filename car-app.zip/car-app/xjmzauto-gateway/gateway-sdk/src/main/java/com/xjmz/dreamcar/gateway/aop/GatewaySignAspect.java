package com.xjmz.dreamcar.gateway.aop;

import com.xjmz.dreamcar.gateway.exception.GatewaySignException;
import com.xjmz.dreamcar.gateway.sign.SignHelper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @Author: wulong
 * @Date: 2024/7/9 16:19
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
@Component
@Aspect
public class GatewaySignAspect {

    @Autowired
    private SignHelper signHelper;

    @Pointcut("@annotation(com.xjmz.dreamcar.gateway.annotation.GatewayCheckSign)")
    public void checkSignPoint() {}

    @Before("checkSignPoint()")
    public void checkSignBefore(JoinPoint joinPoint) {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        assert servletRequestAttributes != null;
        HttpServletRequest request = servletRequestAttributes.getRequest();
        if (!signHelper.checkSign(request)) {
            throw new GatewaySignException("Sign Error");
        }
    }
}
