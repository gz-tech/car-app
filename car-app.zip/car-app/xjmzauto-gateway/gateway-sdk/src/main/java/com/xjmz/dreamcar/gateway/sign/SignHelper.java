package com.xjmz.dreamcar.gateway.sign;

import com.google.common.base.Strings;
import com.xjmz.dreamcar.gateway.config.GwProperties;
import com.xjmz.dreamcar.gateway.constants.GatewayHeaderConstants;
import com.xjmz.dreamcar.gateway.utils.SignUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.util.Objects;

import static com.xjmz.dreamcar.gateway.constants.GatewayHeaderConstants.*;

/**
 * @Author: wulong
 * @Date: 2024/7/9 14:21
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
@Component
public class SignHelper {

    @Resource
    private GwProperties properties;

    public boolean checkSign(HttpServletRequest request) {
        String sign = request.getHeader(GatewayHeaderConstants.HEADER_SIGN);
        String appId = request.getHeader(GatewayHeaderConstants.HEADER_APP_ID);
        String nonce = request.getHeader(HEADER_NONCE);
        String timestamp = request.getHeader(HEADER_TIMESTAMP);
        String userId = request.getHeader(HEADER_USER_ID);
        String serviceAppId = properties.getAppId();
        String secret = properties.getSecret();
        assert serviceAppId != null;
        assert secret != null;
        if (!serviceAppId.equals(appId)) {
            log.error("[Sign] appId error: {}",appId);
            return false;
        }
        if (Strings.isNullOrEmpty(sign) || Strings.isNullOrEmpty(appId) || Strings.isNullOrEmpty(nonce) || Strings.isNullOrEmpty(timestamp) ||Strings.isNullOrEmpty(secret) ) {
            log.error("[Sign] Params Not Exists, appId: {}, nonce: {}, timestamp: {}, secret: {}, sign: {}", appId,
                    nonce, timestamp, secret, sign);
            return false;
        }
        String signature = SignUtils.signature(appId, secret, nonce, timestamp, Objects.isNull(userId) ?
                "" : userId);
        if (!sign.equals(signature)) {
            log.error("[Sign] error , client sign ={}, server sign = {}", sign, signature);
            return false;
        }
        return true;
    }
}
