package com.xjmz.dreamcar.gateway.constants;

/**
 * @Author: wulong
 * @Date: 2024/7/9 14:24
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
public class GatewayHeaderConstants {

    // 请求头
    public static final String BEARER = "Bearer ";
    public static final String HEADER_AUTH = "Authorization";
    public static final String HEADER_USER_ID = "xm-user-id";
    public static final String HEADER_USER_NAME = "xm-user-name";
    public static final String HEADER_DEVICE_ID = "xm-device-id";
    public static final String HEADER_DEVICE_MODEL = "xm-device-model";
    public static final String HEADER_CLIENT_TYPE = "xm-client-type";
    public static final String HEADER_APP_ID = "xm-app-id";
    public static final String HEADER_SYS_VER = "xm-system-ver";
    public static final String HEADER_APP_VER = "xm-app-ver";
    public static final String HEADER_NONCE = "xm-nonce";
    public static final String HEADER_TIMESTAMP = "xm-timestamp";
    public static final String HEADER_SIGN = "xm-sign";
}
