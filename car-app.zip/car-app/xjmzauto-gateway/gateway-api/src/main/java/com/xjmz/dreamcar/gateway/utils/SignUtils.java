package com.xjmz.dreamcar.gateway.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;

/**
 * @Author: wulong
 * @Date: 2024/6/24 17:02
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
public class SignUtils {

    public static String signature(String appId, String secret, String nonce, String timestamp) {
        String rawStr = secret + appId + nonce + timestamp + secret;
        log.info("[Sign] plain: {}", rawStr);
        return DigestUtils.md5DigestAsHex(rawStr.getBytes(StandardCharsets.UTF_8));
    }

    public static String signature(String appId, String secret, String nonce, String timestamp,String userId) {
        String rawStr = secret + appId + nonce + timestamp + userId + secret;
        log.info("[Sign] plain: {}", rawStr);
        return DigestUtils.md5DigestAsHex(rawStr.getBytes(StandardCharsets.UTF_8));
    }
}
