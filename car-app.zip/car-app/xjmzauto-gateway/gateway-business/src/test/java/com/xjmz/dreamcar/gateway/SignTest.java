package com.xjmz.dreamcar.gateway;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

/**
 * @Author: wulong
 * @Date: 2024/6/25 09:34
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Slf4j
public class SignTest {
    private static final String PARAM_APP_ID = "appId";

    private static final String PARAM_NONCE = "nonce";

    private static final String PARAM_TIMESTAMP = "timestamp";

    private static final String PARAM_SIGN = "sign";

    private static final String APP_ID = "123"; // 申请获取

    private static final String APP_SECRET = ""; // 申请获取

    /**
     * 计算签名
     * @param queryParams URL Query参数Map
     * @return 签名值
     */
    public static String sign(Map<String, String> queryParams) {
        // 1.排序并过滤空值
        TreeMap<String, String> treeMap = new TreeMap<>();
        queryParams.forEach((k, v) -> {
            if (!Strings.isNullOrEmpty(k) && !Strings.isNullOrEmpty(v)) {
                treeMap.put(k, v);
            }
        });

        // 2.拼接字符串
        String rawStr = Joiner.on("&")
                .withKeyValueSeparator("=")
                .join(treeMap);
        rawStr = APP_SECRET + rawStr + APP_SECRET;
        log.info("signature plain {}", rawStr);

        // 3.MD5计算签名
        return DigestUtils.md5DigestAsHex(rawStr.getBytes(StandardCharsets.UTF_8));
    }

    // sign:
    public static void main(String[] args) {

    }
}
