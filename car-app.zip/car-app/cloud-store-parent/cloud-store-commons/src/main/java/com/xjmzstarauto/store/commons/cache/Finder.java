package com.xjmzstarauto.store.commons.cache;

import java.util.Collection;
import java.util.List;

/**
 * 缓存更新接口
 *
 * @author wuchenghua
 * @date 2024/9/5
 */
public interface Finder<V extends Identified<Integer>> {

    /**
     * 根据 id(id必须是V的id) 集合查询
     *
     * @param ids
     * @return
     */
    List<V> find(Collection<Integer> ids);

    /**
     * 获取键值前缀
     *
     * @return
     */
    String getCacheKeyPrefix();


    /**
     * 过期时间
     *
     * @return
     */
    int getExpiration();
}