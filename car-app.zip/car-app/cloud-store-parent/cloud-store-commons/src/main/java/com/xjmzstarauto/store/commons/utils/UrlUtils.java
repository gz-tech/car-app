package com.xjmzstarauto.store.commons.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class UrlUtils {
    private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;

    @SneakyThrows
    public static String urlEncode(String s) {
        if (s == null) {
            return null;
        }
        return URLEncoder.encode(s, DEFAULT_CHARSET.name());
    }

    @SneakyThrows
    public static String urlDecode(String s) {
        if (s == null) {
            return null;
        }
        return URLDecoder.decode(s, DEFAULT_CHARSET.name());
    }
}
