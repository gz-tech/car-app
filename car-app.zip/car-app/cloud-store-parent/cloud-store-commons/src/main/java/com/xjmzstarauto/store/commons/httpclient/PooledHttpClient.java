package com.xjmzstarauto.store.commons.httpclient;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import com.xjmzstarauto.store.commons.utils.LogUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.hc.client5.http.HttpResponseException;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.classic.methods.HttpPut;
import org.apache.hc.client5.http.classic.methods.HttpUriRequest;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.TlsConfig;
import org.apache.hc.client5.http.entity.UrlEncodedFormEntity;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.message.BasicNameValuePair;
import org.apache.hc.core5.http.ssl.TLS;
import org.apache.hc.core5.net.URIBuilder;

/**
 * @version 3.0.0
 * <dependency>
 * <groupId>org.apache.httpcomponents.client5</groupId>
 * <artifactId>httpclient5</artifactId>
 * <version>5.2.1</version>
 * </dependency>
 */
@Slf4j
public class PooledHttpClient {
    private final CloseableHttpClient httpClient;

    private final int warnRunTime;

    PooledHttpClient(PooledHttpClientBuilder builder) {
        this.warnRunTime = builder.getWarnRunTime();

        ConnectionConfig connectionConfig = ConnectionConfig.custom()
                .setConnectTimeout(builder.getConnectTimeout(), TimeUnit.MILLISECONDS)
                .setSocketTimeout(builder.getSocketTimeout(), TimeUnit.MILLISECONDS)
                .setTimeToLive(59, TimeUnit.SECONDS)
                .setValidateAfterInactivity(15, TimeUnit.SECONDS)
                .build();

        PoolingHttpClientConnectionManager gcm = PoolingHttpClientConnectionManagerBuilder.create()
                .setDefaultConnectionConfig(connectionConfig)
                .setDefaultTlsConfig(TlsConfig.custom().setSupportedProtocols(TLS.V_1_0, TLS.V_1_1, TLS.V_1_2).build())
                .setMaxConnTotal(builder.getMaxConnTotal())
                .setMaxConnPerRoute(builder.getMaxConnPerRoute())
                .build();

        httpClient = HttpClientBuilder.create()
                .setConnectionManager(gcm)
                .setRetryStrategy(new CustomHttpRequestRetryStrategy(builder.getMaxRetries()))
                .build();
    }

    public String doGet(String url) throws IOException {
        return this.doGet(url, HttpClientRequest.EMPTY);
    }

    public String doGet(String url, Map<String, Object> query) throws IOException {
        return this.doGet(url, HttpClientRequest.builder().query(query).build());
    }

    public String doGet(String url, HttpClientRequest httpClientRequest) throws IOException {
        return this.doGet(url, httpClientRequest, new DefaultBasicHttpClientResponseHandler());
    }

    public <T> T doGet(String url, HttpClientRequest httpClientRequest, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        Objects.requireNonNull(httpClientRequest);
        HttpGet httpGet = new HttpGet(getUrlWithQuery(url, httpClientRequest.getQuery()));
        return this.doExecute(httpGet, httpClientRequest, httpClientResponseHandler);
    }

    public String doPost(String url, HttpClientRequest httpClientRequest) throws IOException {
        Objects.requireNonNull(httpClientRequest);
        HttpEntity entityReq = this.getUrlEncodedEntity(httpClientRequest.getUrlencoded());
        return this.doHttpPost(url, httpClientRequest, entityReq, new DefaultBasicHttpClientResponseHandler());
    }

    public String doPostJson(String url, String raw) throws IOException {
        return this.doPostJson(url, HttpClientRequest.builder().raw(raw).build());
    }

    public String doPostJson(String url, HttpClientRequest httpClientRequest) throws IOException {
        return this.doPostJson(url, httpClientRequest, new DefaultBasicHttpClientResponseHandler());
    }

    public <T> T doPostJson(String url, HttpClientRequest httpClientRequest, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        Objects.requireNonNull(httpClientRequest);
        log.debug("PooledHttpClient.POST json: url={},raw={}", url, httpClientRequest.getRaw());
        return this.doHttpPost(url, httpClientRequest, new StringEntity(httpClientRequest.getRaw(), ContentType.APPLICATION_JSON), httpClientResponseHandler);
    }

    public <T> T doHttpPost(String url, HttpClientRequest httpClientRequest, HttpEntity entityReq, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        HttpPost httpPost = new HttpPost(getUrlWithQuery(url, httpClientRequest.getQuery()));
        if (entityReq != null) {
            httpPost.setEntity(entityReq);
        }
        return this.doExecute(httpPost, httpClientRequest, httpClientResponseHandler);
    }

    public String doPutJson(String url, String raw) throws IOException {
        return this.doPutJson(url, HttpClientRequest.builder().raw(raw).build());
    }

    public String doPutJson(String url, HttpClientRequest httpClientRequest) throws IOException {
        return this.doPutJson(url, httpClientRequest, new DefaultBasicHttpClientResponseHandler());
    }


    public <T> T doPutJson(String url, HttpClientRequest httpClientRequest, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        Objects.requireNonNull(httpClientRequest);
        log.debug("PooledHttpClient.POST json: url={},raw={}", url, httpClientRequest.getRaw());
        return this.doHttpPut(url, httpClientRequest, new StringEntity(httpClientRequest.getRaw(), ContentType.APPLICATION_JSON), httpClientResponseHandler);
    }

    public <T> T doHttpPut(String url, HttpClientRequest httpClientRequest, HttpEntity entityReq, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        HttpPut httpPut = new HttpPut(getUrlWithQuery(url, httpClientRequest.getQuery()));
        if (entityReq != null) {
            httpPut.setEntity(entityReq);
        }
        return this.doExecute(httpPut, httpClientRequest, httpClientResponseHandler);
    }

    private String getUrlWithQuery(String url, Map<String, Object> query) {
        if (MapUtils.isEmpty(query)) {
            return url;
        }
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (entry.getValue() != null) {
                    uriBuilder.setParameter(entry.getKey(), entry.getValue().toString());
                }
            }
            return uriBuilder.build().toString();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(e);
        }
    }

    private HttpEntity getUrlEncodedEntity(Map<String, Object> urlencoded) {
        if (MapUtils.isEmpty(urlencoded)) {
            return null;
        }
        List<NameValuePair> pairList = new ArrayList<>(urlencoded.size());
        for (Map.Entry<String, Object> entry : urlencoded.entrySet()) {
            if (entry.getValue() != null) {
                pairList.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }
        }
        return new UrlEncodedFormEntity(pairList, StandardCharsets.UTF_8);
    }

    public <T> T doExecute(HttpUriRequest request, HttpClientRequest httpClientRequest, HttpClientResponseHandler<? extends T> httpClientResponseHandler) throws IOException {
        if (MapUtils.isNotEmpty(httpClientRequest.getHeaders())) {
            for (Map.Entry<String, String> entry : httpClientRequest.getHeaders().entrySet()) {
                if (entry.getValue() != null) {
                    request.addHeader(entry.getKey(), entry.getValue());
                }
            }
        }
        HttpClientContext localContext = HttpClientContext.create();
        if (httpClientRequest.isRetryAble()) {
            localContext.setAttribute(CustomHttpRequestRetryStrategy.RETRY_ABLE, Boolean.TRUE);
        }
        StopWatch stopWatch = StopWatch.createStarted();
        T result;
        try {
            log.debug("PooledHttpClient.{} req: {}", request.getMethod(), request);
            result = httpClient.execute(request, localContext, httpClientResponseHandler);
            log.debug("PooledHttpClient.{} res: {}", request.getMethod(), LogUtils.wrapJson(result));
            if (result == null) {
                log.error("PooledHttpClient.{} result==null", request.getMethod());
                return null;
            }
            return result;
        } catch (HttpResponseException e) {
            log.error("PooledHttpClient.{} statusCode!=200 req: {},res: {}", request.getMethod(), request, e.getMessage());
            return null;
        } finally {
            stopWatch.stop();
            if (stopWatch.getTime() > this.warnRunTime) {
                log.warn("PooledHttpClient.{} run time: {}ms. url={}", request.getMethod(), stopWatch.getTime(), request.getRequestUri());
            }
        }
    }

    public static PooledHttpClientBuilder builder() {
        return new PooledHttpClientBuilder();
    }
}
