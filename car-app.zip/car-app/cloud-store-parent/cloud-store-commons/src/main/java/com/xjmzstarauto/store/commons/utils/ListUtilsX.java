package com.xjmzstarauto.store.commons.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ListUtilsX {

    public static <T> List<T> subList(List<T> list, int fromIndex) {
        int toIndex = list.size();
        return subList(list, fromIndex, toIndex);
    }

    public static <T> List<T> subList(List<T> list, int fromIndex, int toIndex) {
        if (CollectionUtils.isEmpty(list)) {
            return list;
        }
        if (fromIndex < 0) {
            fromIndex = 0;
        } else if (fromIndex > list.size()) {
            fromIndex = list.size();
        }
        if (toIndex < fromIndex) {
            toIndex = fromIndex;
        } else if (toIndex > list.size()) {
            toIndex = list.size();
        }
        return list.subList(fromIndex, toIndex);
    }

    public static <T> T getSafety(List<T> list, int index) {
        if (list == null) {
            return null;
        }
        if (list.size() > index) {
            return list.get(index);
        } else {
            return null;
        }
    }

    public static <T> T getLast(List<T> list) {
        if (list == null) {
            return null;
        }
        return list.get(list.size() - 1);
    }

    @Nullable
    public static List<String> toList(@Nullable String value) {
        final String DEFAULT_SEPARATOR = ",";
        return toList(value, DEFAULT_SEPARATOR);
    }

    @Nullable
    public static List<String> toList(@Nullable String value, String separator) {
        String[] array = StringUtils.split(value, separator);
        if (array == null) {
            return null;
        }
        List<String> values = new ArrayList<>(array.length);
        values.addAll(Arrays.asList(array));
        return values;
    }

    @Nullable
    public static List<Long> toLongList(@Nullable String value) {
        List<String> values = toList(value);
        if (values == null) {
            return null;
        }
        return values.stream().map(Long::valueOf).collect(Collectors.toList());
    }

    @Nullable
    public static List<Integer> toIntList(@Nullable String value) {
        List<String> values = toList(value);
        if (values == null) {
            return null;
        }
        return values.stream().map(Integer::valueOf).collect(Collectors.toList());
    }
}
