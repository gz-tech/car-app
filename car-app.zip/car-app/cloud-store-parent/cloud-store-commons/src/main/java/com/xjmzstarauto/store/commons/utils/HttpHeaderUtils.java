package com.xjmzstarauto.store.commons.utils;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class HttpHeaderUtils {

    public static String BEARER = "Bearer ";

    public static String addAuthorizationHeadPrefix(String token) {
        return token.startsWith(BEARER) ? token : BEARER + token;
    }

    public static Map<String, String> headerToMap(HttpServletRequest request) {
        Enumeration<String> headerNames = request.getHeaderNames();
        Map<String, String> map = new HashMap<>();
        while (true) {
            if (headerNames.hasMoreElements()) {
                String name = headerNames.nextElement();
                map.put(name, request.getHeader(name));
            } else {
                break;
            }
        }
        return map;
    }

}
