package com.xjmzstarauto.store.commons.advice;

import com.xjmzstarauto.store.base.entity.ApiCommonPARAM;
import com.xjmzstarauto.store.base.entity.ApiUserCommonPARAM;
import com.xjmzstarauto.store.commons.entity.UserInfoDTO;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.ModelAttribute;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;

/**
 * 设置公共参数
 *
 * @author wuchenghua
 * @date 2024/9/5
 */
public class CommonApiParamControllerAdvice {
    /**
     * 绑定参数
     *
     * @param request
     * @return
     */
    @ModelAttribute(value = "apiCommonPARAM", binding = false)
    public ApiCommonPARAM bindApiCommonParam(HttpServletRequest request) {
        return buildApiCommonParam(request);
    }


    @ModelAttribute(value = "apiUserCommonPARAM", binding = false)
    public ApiUserCommonPARAM bindApiCommonUserParam(HttpServletRequest request) {
        ApiCommonPARAM apiCommonParam = buildApiCommonParam(request);
        ApiUserCommonPARAM param = new ApiUserCommonPARAM();
        BeanUtils.copyProperties(apiCommonParam, param);
        if (StringUtils.isNotBlank(param.getUid())) {
            UserInfoDTO userInfo = getUserInfo(param.getUid());
            if (userInfo != null) {
                param.setAvatar(userInfo.getLogo());
                param.setUserName(userInfo.getName());
                param.setNickname(userInfo.getNick());
            }
        }
        return param;
    }

    /**
     * 用户信息需要接入用户中心的服务获取 重写此方法获取 具体可以参考订单服务
     *
     * @param uid
     * @return
     */
    public UserInfoDTO getUserInfo(String uid) {
        return null;
    }


    @NotNull
    private static ApiCommonPARAM buildApiCommonParam(HttpServletRequest request) {
        ApiCommonPARAM param = new ApiCommonPARAM();
        param.setAuthorization(request.getHeader(CommonApiConstant.AUTHORIZATION_HEADER_KEY));
        param.setAppId(request.getHeader(CommonApiConstant.APP_ID_HEADER_KEY));
        String timestamp = request.getHeader(CommonApiConstant.TIMESTAMP_QUERY_KEY);
        param.setTimestamp(StringUtils.isNoneBlank(timestamp) ? Long.parseLong(timestamp) : null);
        param.setNonce(request.getHeader(CommonApiConstant.NONCE_QUERY_KEY));
        param.setDeviceId(request.getHeader(CommonApiConstant.DEVICE_ID_HEADER_KEY));
        param.setDeviceModel(request.getHeader(CommonApiConstant.DEVICE_MODEL_HEADER_KEY));
        param.setClientType(request.getHeader(CommonApiConstant.DEVICE_TYPE_HEADER_KEY));
        param.setAppVer(request.getHeader(CommonApiConstant.APP_VER_HEADER_KEY));
        param.setSysVer(request.getHeader(CommonApiConstant.SYS_VER_HEADER_KEY));
        param.setUid(request.getHeader(CommonApiConstant.UID_HEADER_KEY));
        param.setUserName(getUserName(request.getHeader(CommonApiConstant.UNAME_HEADER_KEY)));
        param.setRealIp(request.getHeader(CommonApiConstant.X_Real_IP));
        return param;
    }

    private static String getUserName(String userName) {
        if (StringUtils.isBlank(userName)) {
            return "";
        }
        try {
            return new String(Base64.getDecoder().decode(userName));
        } catch (Exception e) {
            return userName;
        }
    }

}
