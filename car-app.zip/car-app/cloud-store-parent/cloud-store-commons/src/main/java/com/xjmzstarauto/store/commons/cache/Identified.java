package com.xjmzstarauto.store.commons.cache;

/**
 * 标识组件接口
 *
 * @author wuchenghua
 * @date 2024/9/5
 */
public interface Identified<E> {

    /**
     * ID
     *
     * @return
     */
    E getId();
}