package com.xjmzstarauto.store.commons.httpclient;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EntityUtilsX {

    @SneakyThrows
    public static String toString(HttpEntity entity, Charset defaultCharset) throws IOException {
        return EntityUtils.toString(entity, defaultCharset);
    }
}
