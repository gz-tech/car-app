package com.xjmzstarauto.store.commons.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Builder
public class PageCommon<T> {
    private List<T> rows;

    private Long totalCount;

    private Boolean hasMore;
}
