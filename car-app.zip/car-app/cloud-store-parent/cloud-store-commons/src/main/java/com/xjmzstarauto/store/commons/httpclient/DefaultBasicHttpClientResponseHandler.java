package com.xjmzstarauto.store.commons.httpclient;

import org.apache.hc.client5.http.impl.classic.BasicHttpClientResponseHandler;
import org.apache.hc.core5.http.HttpEntity;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class DefaultBasicHttpClientResponseHandler extends BasicHttpClientResponseHandler {
    private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;

    @Override
    public String handleEntity(HttpEntity entity) throws IOException {
        return EntityUtilsX.toString(entity, DEFAULT_CHARSET);
    }
}
