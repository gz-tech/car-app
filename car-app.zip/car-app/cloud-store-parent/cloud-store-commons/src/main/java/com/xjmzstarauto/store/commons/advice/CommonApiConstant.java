package com.xjmzstarauto.store.commons.advice;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author wuchenghua
 * @date 2024/9/5
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CommonApiConstant {



    /**
     * 存放Access Token
     */
    public static final String AUTHORIZATION_HEADER_KEY = "Authorization";

    /**
     * 用户ID
     */
    public static final String UID_HEADER_KEY = "Xm-User-Id";
    /**
     * 用户名
     */
    public static final String UNAME_HEADER_KEY = "Xm-User-Name";

    /**
     * 设备ID
     */
    public static final String DEVICE_ID_HEADER_KEY = "Xm-Device-Id";

    /**
     * 设备型号
     */
    public static final String DEVICE_MODEL_HEADER_KEY = "Xm-Device-Model";

    /**
     * 端类型
     */
    public static final String DEVICE_TYPE_HEADER_KEY = "Xm-Client-Type";

    /**
     * APP ID
     */
    public static final String APP_ID_HEADER_KEY = "Xm-App-Id";

    /**
     * app版本
     */
    public static final String APP_VER_HEADER_KEY = "Xm-App-Ver";

    /**
     * 系统版本号
     */
    public static final String SYS_VER_HEADER_KEY = "Xm-System-Ver";


    /**
     * 请求时间戳
     */
    public static final String TIMESTAMP_QUERY_KEY = "Xm-Timestamp";

    /**
     * 随机数，请求的唯一标识 推荐UUID，每一次请求不一样
     */
    public static final String NONCE_QUERY_KEY = "Xm-Nonce";

    /**
     * 源ip（Mlb网关赋值）
     */
    public static final String X_Real_IP = "X-Real-IP";


}
