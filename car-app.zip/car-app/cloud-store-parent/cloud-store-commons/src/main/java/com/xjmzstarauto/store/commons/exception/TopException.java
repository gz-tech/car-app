package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;
import com.xjmzstarauto.store.base.code.MsgCode;

/**
 * 父级异常.<br>
 **/
public class TopException extends RuntimeException {

    private final MsgCode code;

    private Object msgData;

    public TopException(MsgCode code) {
        super(code.message(), null, false, false);
        this.code = code;
    }

    public TopException(MsgCode code, Object msgData) {
        super(code.message(), null, false, false);
        this.code = code;
        this.msgData = msgData;
    }

    public TopException(String message, Object msgData) {
        super(message);
        this.code = BasicsTopMsgCode.OTHER_ERROR;
        this.msgData = msgData;
    }

    public TopException(String message) {
        super(message);
        this.code = BasicsTopMsgCode.OTHER_ERROR;
    }

    public TopException(MsgCode code, String message) {
        super(message, null, false, false);
        this.code = code;
    }


    public TopException(MsgCode code, String message, Object msgData) {
        super(message, null, false, false);
        this.code = code;
        this.msgData = msgData;
    }

    public TopException(MsgCode code, String message, Throwable cause) {
        super(message, cause, cause != null, cause != null);
        this.code = code;
    }

    public TopException(MsgCode code, Throwable cause) {
        super(cause);
        this.code = code;
    }

    public MsgCode getCode() {
        return code;
    }

    public Object getMsgData() {
        return msgData;
    }

    @Override
    public String getMessage() {
        String msg = super.getMessage();
        if (msg == null || msg.trim().length() == 0) {
            msg = code.message();
        }
        return msg;
    }
}