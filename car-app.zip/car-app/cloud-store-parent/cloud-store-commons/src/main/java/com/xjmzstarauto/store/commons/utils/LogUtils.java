package com.xjmzstarauto.store.commons.utils;

import com.alibaba.fastjson2.JSON;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class LogUtils {

    public static Object wrapJson(final Object obj) {
        return Optional.ofNullable(obj).map(o -> new Object() {
            @Override
            public String toString() {
                try {
                    if (o instanceof CharSequence) {
                        return doInline((CharSequence) o);
                    }
                    return JSON.toJSONString(o);
                } catch (Exception e) {
                    return String.valueOf(o);
                }
            }
        }).orElse(null);
    }

    public static Object inline(final CharSequence charSequence) {
        return Optional.ofNullable(charSequence).map(o -> new Object() {
            @Override
            public String toString() {
                return doInline(o);
            }
        }).orElse(null);
    }

    public static Object wrapExcp(final Throwable e) {
        return Optional.ofNullable(e).map(o -> new Object() {
            @Override
            public String toString() {
                return o.toString();
            }
        }).orElse(null);
    }

    private static String doInline(CharSequence charSequence) {
        String s = charSequence.toString();
        if (StringUtils.startsWithAny(s.trim(), "{", "[")) {
            return JSON.parse(s).toString();
        } else {
            return s.replace(StringUtils.LF, "\\n").replace(StringUtils.CR, "\\r");
        }
    }
}
