package com.xjmzstarauto.store.commons.httpclient;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class HttpClientRequest {
    public static final HttpClientRequest EMPTY = HttpClientRequest.builder().build();
    private Map<String, Object> query;
    private Map<String, String> headers;
    private String raw;
    private Map<String, Object> urlencoded;
    private boolean retryAble;
}
