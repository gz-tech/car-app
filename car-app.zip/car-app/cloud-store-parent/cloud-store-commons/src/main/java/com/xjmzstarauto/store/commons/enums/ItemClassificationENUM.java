package com.xjmzstarauto.store.commons.enums;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;

/**
 * 商品分类   精品or附件
 *
 * @author wuchenghua
 * @date 2024/9/5
 */
@Getter
public enum ItemClassificationENUM {

    /**
     * 精品
     */
    ADDITIONALS(1, "精品"),

    /**
     * 附件
     */
    EXTRA(2, "附件");

    public final int key;

    public final String name;

    private static Map<String, ItemClassificationENUM> cache = new HashMap<>();

    static {
        for (ItemClassificationENUM itemClassificationENUM : ItemClassificationENUM.values()) {
            cache.put(itemClassificationENUM.name, itemClassificationENUM);
        }
    }

    ItemClassificationENUM(int key, String name) {
        this.key = key;
        this.name = name;
    }

    public Integer getKey() {
        return this.key;
    }

    public String getName() {
        return this.name;
    }

    public static ItemClassificationENUM getItemClassificationByName(String name){
        return cache.get(name);
    }

}
