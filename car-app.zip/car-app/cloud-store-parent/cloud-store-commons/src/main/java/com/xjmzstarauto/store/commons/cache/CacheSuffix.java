package com.xjmzstarauto.store.commons.cache;

/**
 * 缓存KEY后缀
 *
 * @author wuchenghua
 * @date 2024/9/5
 */
public interface CacheSuffix<K> {

    /**
     * 缓存KEY后缀
     *
     * @return
     */
    K getCacheKeySuffix();
}
