package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;

/**
 * redis异常处理类
 */
public class RedisException extends TopException {

    public RedisException() {
        this(BasicsTopMsgCode.REDIS_ERROR);
    }

    public RedisException(String message) {
        this(BasicsTopMsgCode.REDIS_ERROR, message);
    }

    public RedisException(Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, cause);
    }

    public RedisException(MsgCode code, String message, Object msgData) {
        super(code, message, msgData);
    }

    public RedisException(String message, Object msgData) {
        this(BasicsTopMsgCode.REDIS_ERROR, message, msgData);
    }

    public RedisException(MsgCode code, String message) {
        super(code, message);
    }

    public RedisException(String message, Throwable cause) {
        this(BasicsTopMsgCode.REDIS_ERROR, message, cause);
    }

    public RedisException(MsgCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public RedisException(MsgCode code) {
        super(code);
    }

    public RedisException(MsgCode code, Throwable cause) {
        super(code, cause);
    }
}
