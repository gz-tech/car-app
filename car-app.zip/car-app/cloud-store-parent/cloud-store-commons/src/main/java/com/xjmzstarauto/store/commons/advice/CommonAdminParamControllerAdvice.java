package com.xjmzstarauto.store.commons.advice;

import com.xjmzauto.portal.sdk.util.LoginUserHolder;
import com.xjmzauto.portal.sdk.vo.LoginUser;
import com.xjmzstarauto.store.base.entity.AdminCommonPARAM;
import com.xjmzstarauto.store.commons.utils.GsonUtils;
import com.xjmzstarauto.store.commons.utils.UrlUtils;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ModelAttribute;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;
import java.util.Optional;

/**
 * 设置公共参数
 *
 * @author wuchenghua
 * @since 2024/9/5
 */
public class CommonAdminParamControllerAdvice {

    private static Logger logger = LoggerFactory.getLogger(CommonAdminParamControllerAdvice.class);

    @Value("${spring.profiles.active:}")
    private String env;

    @ModelAttribute(value = "adminCommonPARAM", binding = false)
    public AdminCommonPARAM bindAdminCommonParam(HttpServletRequest request) {
        return buildAdminCommonParam(request, env);
    }

    @NotNull
    private static AdminCommonPARAM buildAdminCommonParam(HttpServletRequest request, String env) {
        //被portalAuthCheckInterceptor拦截器拦截处理过的请求，才能在业务方法内使用以下方法获取
        LoginUser loginUser = LoginUserHolder.getLoginUser();
        logger.info("loginUser:" + GsonUtils.toJson(loginUser) + " env:" + env);
        if (Objects.isNull(loginUser) && (Objects.equals("test", env) || Objects.equals("dev", env))) {
            AdminCommonPARAM param = new AdminCommonPARAM();
            param.setAdminAccount(Optional.ofNullable(request.getHeader("Operator-Admin-Account")).orElse("test_default"));
            param.setAdminName(Optional.ofNullable(UrlUtils.urlDecode(request.getHeader("Operator-Admin-Name"))).orElse("test_default"));
            return param;
        }
        AdminCommonPARAM param = new AdminCommonPARAM();
        param.setAdminAccount(request.getHeader(loginUser.getAccount()));
        param.setAdminName(UrlUtils.urlDecode(request.getHeader(loginUser.getNickname())));
        return param;
    }
}
