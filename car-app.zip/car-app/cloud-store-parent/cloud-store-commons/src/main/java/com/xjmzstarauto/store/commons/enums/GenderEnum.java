package com.xjmzstarauto.store.commons.enums;

import lombok.Getter;

@Getter
public enum GenderEnum {

    UNKNOWN(0),
    MAN(1),
    WOMAN(2);

    private int index;

    GenderEnum(int index) {
        this.index = index;
    }
}
