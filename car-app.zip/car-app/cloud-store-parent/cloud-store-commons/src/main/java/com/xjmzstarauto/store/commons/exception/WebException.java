package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;

/**
 * web api错误
 **/
public class WebException extends TopException {

    public WebException() {
        this(BasicsTopMsgCode.WEB_ERROR);
    }

    public WebException(String message) {
        this(BasicsTopMsgCode.WEB_ERROR, message);
    }

    public WebException(Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, cause);
    }

    public WebException(MsgCode code, String message) {
        super(code, message);
    }

    public WebException(String message, Object msgData) {
        this(BasicsTopMsgCode.WEB_ERROR, message, msgData);
    }

    public WebException(MsgCode code, String message, Object msgData) {
        super(code, message, msgData);
    }

    public WebException(String message, Throwable cause) {
        this(BasicsTopMsgCode.WEB_ERROR, message, cause);
    }

    public WebException(MsgCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public WebException(MsgCode code) {
        super(code);
    }

    public WebException(MsgCode code, Throwable cause) {
        super(code, cause);
    }
}
