package com.xjmzstarauto.store.commons.httpclient;

import org.apache.hc.client5.http.impl.DefaultHttpRequestRetryStrategy;
import org.apache.hc.core5.http.HttpRequest;
import org.apache.hc.core5.http.protocol.HttpContext;
import org.apache.hc.core5.util.TimeValue;

import java.io.IOException;

public class CustomHttpRequestRetryStrategy extends DefaultHttpRequestRetryStrategy {
    public static final String RETRY_ABLE = "RETRY_ABLE";

    public CustomHttpRequestRetryStrategy(final int maxRetries) {
        super(maxRetries, TimeValue.ZERO_MILLISECONDS);
    }

    @Override
    public boolean retryRequest(HttpRequest request, IOException exception, int execCount, HttpContext context) {
        if (super.retryRequest(request, exception, execCount, context)) {
            return context.getAttribute(RETRY_ABLE) != null;
        }
        return false;
    }

    @Override
    protected boolean handleAsIdempotent(HttpRequest request) {
        return true;
    }
}
