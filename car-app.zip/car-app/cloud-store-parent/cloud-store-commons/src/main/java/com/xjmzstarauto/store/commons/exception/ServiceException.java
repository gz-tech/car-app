package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;

/**
 * 服务层异常
 **/
public class ServiceException extends TopException {

    public ServiceException() {
        this(BasicsTopMsgCode.SERVICE_ERROR);
    }

    public ServiceException(String message) {
        this(BasicsTopMsgCode.SERVICE_ERROR, message);
    }

    public ServiceException(Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, cause);
    }

    public ServiceException(MsgCode code, String message) {
        super(code, message);
    }

    public ServiceException(String message, Object msgData) {
        this(BasicsTopMsgCode.SERVICE_ERROR, message, msgData);
    }

    public ServiceException(MsgCode code, String message, Object msgData) {
        super(code, message, msgData);
    }

    public ServiceException(String message, Throwable cause) {
        this(BasicsTopMsgCode.SERVICE_ERROR, message, cause);
    }

    public ServiceException(MsgCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public ServiceException(MsgCode code) {
        super(code);
    }

    public ServiceException(MsgCode code, Throwable cause) {
        super(code, cause);
    }
}
