package com.xjmzstarauto.store.commons.httpclient;

import lombok.Getter;

@Getter
public class PooledHttpClientBuilder {
    /**
     * 连接池的最大连接数
     */
    private int maxConnTotal = 0;
    /**
     * 每个域名的最大连接数
     */
    private int maxConnPerRoute = 0;
    /**
     * tcp连接超时
     */
    private int connectTimeout = 1000;
    /**
     * tcp读写超时
     */
    private int socketTimeout = 15000;
    /**
     * 慢响应时长阈值
     */
    private int warnRunTime = 1000;
    /**
     * 最大重试次数
     */
    private int maxRetries = 1;

    public PooledHttpClientBuilder maxConnTotal(int maxConnTotal) {
        this.maxConnTotal = maxConnTotal;
        return this;
    }

    public PooledHttpClientBuilder maxConnPerRoute(int maxConnPerRoute) {
        this.maxConnPerRoute = maxConnPerRoute;
        return this;
    }

    public PooledHttpClientBuilder connectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
        return this;
    }

    public PooledHttpClientBuilder socketTimeout(int socketTimeout) {
        this.socketTimeout = socketTimeout;
        return this;
    }

    public PooledHttpClientBuilder warnRunTime(int warnRunTime) {
        this.warnRunTime = warnRunTime;
        return this;
    }

    public PooledHttpClientBuilder maxRetries(int maxRetries) {
        this.maxRetries = maxRetries;
        return this;
    }

    public PooledHttpClient build() {
        return new PooledHttpClient(this);
    }
}
