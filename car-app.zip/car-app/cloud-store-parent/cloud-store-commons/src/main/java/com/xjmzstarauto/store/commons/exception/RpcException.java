package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;

/**
 * Rpc层异常
 **/
public class RpcException extends TopException {

    public RpcException() {
        this(BasicsTopMsgCode.FEIGN_ERROR);
    }

    public RpcException(String message) {
        this(BasicsTopMsgCode.FEIGN_ERROR, message);
    }

    public RpcException(Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, cause);
    }

    public RpcException(MsgCode code, String message) {
        super(code, message);
    }

    public RpcException(String message, Object msgData) {
        this(BasicsTopMsgCode.FEIGN_ERROR, message, msgData);
    }

    public RpcException(MsgCode code, String message, Object msgData) {
        super(code, message, msgData);
    }

    public RpcException(String message, Throwable cause) {
        this(BasicsTopMsgCode.FEIGN_ERROR, message, cause);
    }

    public RpcException(MsgCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public RpcException(MsgCode code) {
        super(code);
    }

    public RpcException(MsgCode code, Throwable cause) {
        super(code, cause);
    }
}
