package com.xjmzstarauto.store.commons.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class DateTimeUtil {

    private DateTimeUtil() {
    }

    public final static String PATTERN_LONG = "yyyy-MM-dd HH:mm:ss";

    public final static String PATTERN_A = "yyyyMM";

    public final static String PATTERN_B = "yyyyMMdd";

    public final static String PATTERN_C = "yyyy-MM-dd";

    public static final String PATTERN_D = "yyMMdd";

    public static final String PATTERN_E = "yyyyMMddHHmmss";

    public static final String PATTERN_F = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public final static String PATTERN_ZH = "yyyy年MM月dd日";

    public final static String PATTERN_TIME = "HH:mm:ss";

    public final static String PATTERN_LONG_MINUTE = "yyyy-MM-dd HH:mm";

    /**
     * 格式化日期
     *
     * @param date    需要格式化的 日期对象
     * @param pattern 日期样式
     */
    public static String formatDate(Date date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);
    }

    /**
     * 格式化日期。
     * 完整格式：yyyy-MM-dd HH:mm:ss。
     *
     * @param date 需要格式化的 日期对象
     */
    public static String formatLong(Date date) {
        return formatDate(date, PATTERN_LONG);
    }

    /**
     * 格式化日期。
     * 短格式：yyyy-MM-dd。
     *
     * @param date 需要格式化的 日期对象
     */
    public static String formatShort(Date date) {
        return formatDate(date, PATTERN_C);
    }

    /**
     * 昨天的日期。
     * 短格式：yyyy-MM-dd。
     */
    public static String formatByDays(int days) {
        final Calendar date = Calendar.getInstance();
        date.add(Calendar.DAY_OF_YEAR, days);
        return formatDate(date.getTime(), PATTERN_C);
    }

    /**
     * 昨天的日期。
     * 短格式：yyyy-MM-dd。
     */
    public static String formatYesterday() {
        return formatByDays(-1);
    }

    /**
     * 今天的日期。
     * 短格式：yyyy-MM-dd。
     */
    public static String formatToday() {
        return formatByDays(0);
    }

    /**
     * 明天的日期。
     * 短格式：yyyy-MM-dd。
     */
    public static String formatTomorrow() {
        return formatByDays(1);
    }

    /**
     * 把字符串按格式转换成Date对象
     *
     * @param text
     * @param pattern
     * @return
     */
    public static Date parse(String text, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            return format.parse(text);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * 默认用yyyy-MM-dd HH:mm:ss的格式进行转换
     *
     * @param text
     * @return
     */
    public static Date parse(String text) {
        SimpleDateFormat format = new SimpleDateFormat(PATTERN_LONG);
        try {
            return format.parse(text);
        } catch (ParseException e) {
            throw new IllegalArgumentException("非法日期格式,text=" + text);
        }
    }

    /**
     * 将yyyy-MM-dd'T'HH:mm:ss.SSS'Z'格式日期转为 yyyy-MM-dd HH:mm:ss格式
     *
     * @param date
     * @return
     */
    public static Date parseLong(String date) {
        try {
            ZonedDateTime zdt = ZonedDateTime.parse(date, DateTimeFormatter.ISO_ZONED_DATE_TIME);
            return Date.from(zdt.toInstant());
        } catch (Exception e) {
            throw new IllegalArgumentException("非法日期格式,text= " + date);
        }
    }

    public static Date parseShort(String text) {
        SimpleDateFormat format = new SimpleDateFormat(PATTERN_C);
        try {
            return format.parse(text);
        } catch (ParseException e) {
            throw new IllegalArgumentException("非法日期格式,text=" + text);
        }
    }

    public static long parseSDate(String sdate) {
        if (StringUtils.isEmpty(sdate)) {
            return 0;
        } else {
            return parseShort(sdate).getTime();
        }
    }

    public static long parseEDate(String edate) {
        if (StringUtils.isEmpty(edate)) {
            return System.currentTimeMillis();
        } else {
            return addDay(DateTimeUtil.parseShort(edate), 1).getTime();
        }
    }

    /**
     * 计算两个日期之间相差日期天数(如:2014-10-09与2014-10-10相差一天)
     *
     * @param sd
     * @param ed
     */
    public static int diffDateDay(Date sd, Date ed) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(sd);
        int sDay = calendar.get(Calendar.DAY_OF_YEAR);
        int sYear = calendar.get(Calendar.YEAR);

        calendar.setTime(ed);
        int eDay = calendar.get(Calendar.DAY_OF_YEAR);
        int eYear = calendar.get(Calendar.YEAR);

        // 每年的天数
        int oneYearDays = 365;
        boolean flag = (sYear % 4 == 0 && sYear % 100 != 0) || sYear % 400 == 0;
        if (flag) {
            // 润年366天
            oneYearDays = 366;
        }

        return (eYear - sYear) * oneYearDays + eDay - sDay;
    }

    public static int absDiffDay(Date sdate, Date edate) {
        return Math.abs(diffDateDay(sdate, edate));
    }

    public static long diffDateMinute(Date sd, Date ed) {
        return Math.abs(ed.getTime() - sd.getTime()) / 1000 / 60;
    }

    public static long diffDateSecond(Date sd, Date ed) {
        return Math.abs(ed.getTime() - sd.getTime()) / 1000;
    }

    public static String getDateStr(Date date, String datePattern) {
        SimpleDateFormat format = new SimpleDateFormat(datePattern);
        return format.format(date);
    }

    /**
     * 增加日期的天数
     *
     * @param date      日期
     * @param dayAmount 增加数量。可为负数
     * @return 增加天数后的日期
     */
    public static Date addDay(Date date, int dayAmount) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, dayAmount);
        return calendar.getTime();
    }

    public static Date getFromDate(Date date) {
        final Calendar c = Calendar.getInstance();
        c.setTime(date);
        clearByDate(c);
        return c.getTime();
    }

    private static void clearByDate(Calendar c) {
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }

    public static Date getToDate(Date date) {
        date = addDay(date, 1);
        final Calendar c = Calendar.getInstance();
        c.setTime(date);
        clearByDate(c);
        return c.getTime();
    }

    public static Date getYesterday() {
        final Calendar now = Calendar.getInstance();
        now.add(Calendar.DAY_OF_YEAR, -1);
        return now.getTime();
    }

    public static long date2Long(String dateString) {
        long l = 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(PATTERN_C);
            Date date = sdf.parse(dateString);
            l = date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return l;
    }

    public static boolean isSameDay(Date date1, Date date2) {
        if (null != date2String(date1, PATTERN_LONG) && null != date2String(date2, PATTERN_LONG)) {
            return date2String(date1, PATTERN_LONG).equals(date2String(date2, PATTERN_LONG));
        }
        return false;
    }

    /**
     * Date转字符串，格式为yyyy-MM-dd
     *
     * @param date 日期
     * @return 字符串
     */
    public static String date2String(Date date) {
        if (null == date) {
            return null;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PATTERN_C);
        return simpleDateFormat.format(date);
    }

    /**
     * Date转字符串
     *
     * @param date
     * @param pattern 日期格式
     */
    public static String date2String(Date date, String pattern) {
        if (null == date) {
            return null;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        return simpleDateFormat.format(date);
    }

    public static Date timestampToDate(Long timestamp) {
        Date date = new Date(timestamp);
        return date;
    }


    /**
     * 把utc时间转为本地时间
     *
     * @param timestamp
     * @return 2023-08-31T09:07:10Z  转为 2023-08-31 17:07:10
     */
    public static Date utcToDate(String timestamp) {

        Date date = null;
        if (timestamp.endsWith("Z")) {
            // 如果时间戳以Z结尾，说明是UTC时间
            // 将UTC时间字符串解析为Instant
            Instant instant = Instant.parse(timestamp);

            // 将Instant转换为LocalDateTime并设置时区为东八区
            LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.of("Asia/Shanghai"));

            // 将LocalDateTime转换为Date
             date = Date.from(localDateTime.atZone(ZoneId.of("Asia/Shanghai")).toInstant());


        } else {
            // 如果不以Z结尾，说明是本地时间或其他格式
            date = parse(timestamp);
        }
        return date;
    }

    public static void main(String[] args) {
        System.out.println(utcToDate("2023-12-08T09:39:21.14Z"));
        System.out.println(new Date());
        System.out.println(utcToDate("2023-12-05 17:35:12"));
        System.out.println(DateTimeUtil.formatLong(new Date()));
    }


}
