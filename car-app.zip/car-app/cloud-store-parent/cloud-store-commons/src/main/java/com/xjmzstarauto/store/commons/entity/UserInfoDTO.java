package com.xjmzstarauto.store.commons.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wuchenghua
 * @date 2024/9/5
 */
@Data
public class UserInfoDTO implements Serializable {

    private static final long serialVersionUID = 1695954533443L;

    private Long id;

    private String uid;

    private String name;

    private String phone;

    private String plainPhone;

    private String email;

    private String nick;

    private String logo;

    private String memo;

    private String state;

    private String source;

    private String createDate;

    private String gender;

    private String birthday;

    private Integer birthdayModifyCount;

    private String focusModel;

    private String hobbies;

    private String firstLoginDevice;

    private String lastLoginDevice;

    private String registrationId;

    private String loginDevices;
}
