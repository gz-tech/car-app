package com.xjmzstarauto.store.commons.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import com.xjmzstarauto.store.commons.exception.ServiceException;
import org.apache.commons.lang3.StringUtils;

public final class MD5Utils {

	private MD5Utils(){}

	private final static String[] DIGITS_LOWER = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

	private static ThreadLocal<MessageDigest> digestHolder = new ThreadLocal<MessageDigest>() {

		@Override
		protected MessageDigest initialValue() {
			try {
				return MessageDigest.getInstance( "MD5" );
			} catch( NoSuchAlgorithmException ex ) {
				throw new IllegalStateException( "no algorithm" );
			}
		}
	};

	public void removeThreadLocal(){
		digestHolder.remove();
	}

	public static String encodeHexString( byte[] data ) {
		StringBuilder c = new StringBuilder();
		for( int idx = 0; idx < data.length; idx++ ) {
			c.append( encodeHexString( data[ idx ], true ) );
		}
		return c.toString();
	}

	public static String encodeHexStringLittleEndian( byte[] data ) {
		StringBuilder c = new StringBuilder();
		for( int i = 0; i < data.length; i++ ) {
			c.append( encodeHexString( data[ i ], false ) );
		}
		return c.toString();
	}

	private static String encodeHexString( byte data, boolean bigEndian ) {
		int n = data;
		if( n < 0 ) {
			n = 256 + n;
		}
		int d1 = n / 16;
		int d2 = n % 16;
		return ( bigEndian ) ? ( DIGITS_LOWER[ d1 ] + DIGITS_LOWER[ d2 ] ) : ( DIGITS_LOWER[ d2 ] + DIGITS_LOWER[ d1 ] );
	}

	public static byte[] decodeHexString( String data ) {
		if( 0 != data.length() % 2 ) {
			throw new ServiceException( "error hex data" );
		}
		byte[] r = new byte[ data.length() / 2 ];
		for( int i = 0; i < data.length(); i=i+2 ) {
			int j = i+1;
			int pos = i / 2;
			char c = data.charAt( i );
			char c2 = data.charAt( j );
			r[ pos ] = Integer.decode( "0x" + c + c2 ).byteValue();
		}
		return r;
	}

	public static String digest( String plain ) {
		return digest( plain, null );
	}

	public static String digest( String plain, String encoding ) {
		String target = null;
		try {
			target = plain;
			MessageDigest md = digestHolder.get();
			if( null == encoding ) {
				target = encodeHexString( md.digest( target.getBytes() ) );
			} else {
				target = encodeHexString( md.digest( target.getBytes( encoding ) ) );
			}
		} catch( Exception ex ) {
			throw new ServiceException( ex );
		}
		return target;
	}

	public static String digestBytes( byte plain[] ) {
		String target = null;
		try {
			MessageDigest md = digestHolder.get();
			target = encodeHexString( md.digest( plain ) );
		} catch( Exception ex ) {
			throw new ServiceException( ex );
		}
		return target;
	}

	public static byte[] digest( byte plain[] ) {
		try {
			MessageDigest messageDigest = digestHolder.get();
			return messageDigest.digest( plain );
		} catch( Exception ex ) {
			throw new ServiceException( ex );
		}
	}

	public static MessageDigest getDigest() {
		return digestHolder.get();
	}
	
	public static Map<String, Object> calculateDigest(File file) throws IOException {
		Map<String, Object> map = new HashMap<String, Object>();
		FileInputStream is = new FileInputStream(file);
		long size = 0;
		String digest = StringUtils.EMPTY;
		try {
			MessageDigest md = MD5Utils.getDigest();
			byte[] buffer = new byte[1024];
			while (true) {
				int len = is.read(buffer);
				if (len < 0) {
					break;
				}
				size += len;
				md.update(buffer, 0, len);
			}
			byte[] digests = md.digest();
			digest = MD5Utils.encodeHexString( digests );
			map.put( "size", size );
			map.put( "digest", digest );
		} finally {
			is.close();
		}
		return map;
	}

	/**
	 * MD5加码。32位
	 * @param inStr
	 * @return
	 */
	public static String encripy( String inStr ) {
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance( "MD5" );
		} catch( Exception e ) {
			e.printStackTrace();
			return "";
		}
		char[] charArray = inStr.toCharArray();
		byte[] byteArray = new byte[ charArray.length ];

		for( int i = 0; i < charArray.length; i++ ) {
            byteArray[ i ] = ( byte )charArray[ i ];
        }

		byte[] md5Bytes = md5.digest( byteArray );

		StringBuilder hexValue = new StringBuilder();

		for( int i = 0; i < md5Bytes.length; i++ ) {
			int val = ( ( int )md5Bytes[ i ] ) & 0xff;
			if( val < 16 ) {
                hexValue.append( "0" );
            }
			hexValue.append( Integer.toHexString( val ) );
		}

		return hexValue.toString();
	}
}
