package com.xjmzstarauto.store.commons.exception;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;

/**
 * Dao层异常
 **/
public class DaoException extends TopException {

    public DaoException() {
        this(BasicsTopMsgCode.DAO_ERROR);
    }

    public DaoException(String message) {
        this(BasicsTopMsgCode.DAO_ERROR, message);
    }

    public DaoException(Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, cause);
    }

    public DaoException(MsgCode code, String message) {
        super(code, message);
    }


    public DaoException(String message, Object msgData) {
        this(BasicsTopMsgCode.DAO_ERROR, message, msgData);
    }

    public DaoException(MsgCode code, String message, Object msgData) {
        super(code, message, msgData);
    }

    public DaoException(String message, Throwable cause) {
        this(BasicsTopMsgCode.DAO_ERROR, message, cause);
    }

    public DaoException(MsgCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public DaoException(MsgCode code) {
        super(code);
    }

    public DaoException(MsgCode code, Throwable cause) {
        super(code, cause);
    }
}
