package com.xjmzstarauto.store.base.entity;

import java.util.List;

public interface ILoadMoreInfo<T extends ISeq> {
    /**
     * 获取数据行
     */
    List<T> getRows();

    /**
     * 设置数据行
     */
    void setRows(List<T> rows);

    /**
     * 获取是否还有更多
     */
    Boolean getHasMore();

    /**
     * 设置是否还有更多
     */
    void setHasMore(Boolean hasMore);

    /**
     * 获取跟踪标记
     */
    default String getTraceCode() {
        return null;
    }

    /**
     * 设置跟踪标记
     */
    default void setTraceCode(String traceCode) {

    }
}
