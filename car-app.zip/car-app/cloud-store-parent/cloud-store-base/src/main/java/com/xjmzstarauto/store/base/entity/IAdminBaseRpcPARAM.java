package com.xjmzstarauto.store.base.entity;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
public interface IAdminBaseRpcPARAM extends IBasePARAM {

    default AdminCommonPARAM getAdminCommonParam() {
        return null;
    }

    default void setAdminCommonParam(AdminCommonPARAM adminCommonParam) {

    }
}
