package com.xjmzstarauto.store.base.entity;

import com.google.gson.annotations.SerializedName;
import com.xjmzstarauto.store.base.enums.OperatorTypeENUM;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
@Data
public class ApiUserCommonPARAM extends ApiCommonPARAM implements ApiBaseCommonPARAM {

    @SerializedName("userNameU")
    @ApiModelProperty(value = "userName", hidden = true)
    private String userName;

    @ApiModelProperty(value = "nickname", hidden = true)
    private String nickname;

    @ApiModelProperty(value = "avatar", hidden = true)
    private String avatar;

    @Override
    public String getOperatorId() {
        return getUid();
    }

    @Override
    public String getOperatorName() {
        return userName;
    }

    @Override
    public OperatorTypeENUM getOperatorType() {
        return OperatorTypeENUM.USER;
    }
}
