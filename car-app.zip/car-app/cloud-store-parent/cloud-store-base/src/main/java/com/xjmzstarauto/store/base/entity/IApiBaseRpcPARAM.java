package com.xjmzstarauto.store.base.entity;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
public interface IApiBaseRpcPARAM extends IBasePARAM {

    default ApiCommonPARAM getApiCommonParam() {
        return null;
    }

    default void setApiCommonParam(ApiCommonPARAM apiCommonParam) {

    }
}
