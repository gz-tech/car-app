package com.xjmzstarauto.store.base.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class PagePARAM implements IPagePARAM, Serializable {

    @ApiModelProperty(value = "页数，1开始")
    private Integer pageNum;

    @ApiModelProperty(value = "每页数量")
    private Integer pageSize;

    @ApiModelProperty(value = "按字段哪些字段排序", hidden = true)
    private String sortParamStr;

    @ApiModelProperty(value = "是否获取总数量, true 查询列表总数 false 不查询列表总数")
    private Boolean statTotal;

}
