package com.xjmzstarauto.store.base.entity;

import com.xjmzstarauto.store.base.utils.StringBlankUtil;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
@Data
public class ApiCommonPARAM implements Serializable {
    /**
     * 传递方式: Header 值存放Access Token
     */
    @ApiModelProperty(hidden = true)
    private String authorization;

    /**
     * 应用ID 传递方式: Query
     */
    @ApiModelProperty(value = "应用ID", hidden = true)
    private String appId;

    /**
     * Unix时间戳（毫秒） 传递方式: Query
     */
    @ApiModelProperty(value = "Unix时间戳（毫秒）", hidden = true)
    private Long timestamp;

    /**
     * 随机数，请求的唯一标识 推荐UUID，每一次请求不一样  传递方式: Query
     */
    @ApiModelProperty(value = "随机数，请求的唯一标识 推荐UUID，每一次请求不一样", hidden = true)
    private String nonce;


    /**
     * 设备ID 传递方式: Query
     */
    @ApiModelProperty(value = "设备ID", hidden = true)
    private String deviceId;

    /**
     * 设备型号 传递方式: Query
     */
    @ApiModelProperty(value = "设备型号", hidden = true)
    private String deviceModel;

    /**
     * 端类型  WEB网页 PHONE手机 VEHICLE车机 WECHAT微信 传递方式: Query
     */
    @ApiModelProperty(value = "端类型 WEB网页 PHONE手机 VEHICLE车机 WECHAT微信", allowableValues = "WEB,PHONE,VEHICLE,WECHAT", hidden = true)
    private String clientType;

    /**
     * 应用版本 传递方式: Query
     */
    @ApiModelProperty(value = "应用版本", hidden = true)
    private String appVer;

    @ApiModelProperty(value = "系统版本", hidden = true)
    private String sysVer;

    /**
     * 从header获得
     */
    @ApiModelProperty(value = "uid", hidden = true)
    private String uid;

    @ApiModelProperty(value = "userName", hidden = true)
    private String userName;

    @ApiModelProperty(value = "源ip", hidden = true)
    private String realIp;

    /**
     * 判断用户是否登录
     *
     * @return
     */
    @ApiModelProperty(value = "是否登录", hidden = true)
    public boolean isUserLogin() {
        return StringBlankUtil.isNotBlank(uid);
    }



}
