package com.xjmzstarauto.store.base.enums;

import java.util.HashMap;
import java.util.Map;

/**
* 操作人类型 0:系统 1:用户 2:运营人员
*
* @author lin
* @since 2024-09-09
*/
public enum OperatorTypeENUM {

    /**
     * 系统 value=0
     */
    SYSTEM(0, "系统"),
    /**
    * 用户 value=1
    */
    USER(1, "用户"),
    /**
    * 运营人员 value=2
    */
    ADMIN(2, "运营人员");

    private final int code;
    private final String name;
    private static Map<Integer, OperatorTypeENUM> codeLookUp = new HashMap<>();

    static {
        for (OperatorTypeENUM orderStatus : OperatorTypeENUM.values()) {
            codeLookUp.put(orderStatus.code, orderStatus);
        }
    }

    private OperatorTypeENUM(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static OperatorTypeENUM findByValue(int value) {
        return codeLookUp.get(value);
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

}
