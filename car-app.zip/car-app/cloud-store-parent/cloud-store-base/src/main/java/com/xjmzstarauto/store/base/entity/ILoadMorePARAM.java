package com.xjmzstarauto.store.base.entity;

public interface ILoadMorePARAM {
    Long getSeqStart();

    void setSeqStart(Long seqStart);

    default String getTraceCode() {
        return null;
    }

    default void setTraceCode(String traceCode) {

    }
}
