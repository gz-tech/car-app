package com.xjmzstarauto.store.base.code;

public interface MsgCode {
    int code();

    String message();

    boolean isCommonCode();

}
