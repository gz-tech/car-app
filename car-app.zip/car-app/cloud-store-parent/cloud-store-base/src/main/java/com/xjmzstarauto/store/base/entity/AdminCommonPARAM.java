package com.xjmzstarauto.store.base.entity;

import com.xjmzstarauto.store.base.enums.OperatorTypeENUM;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
@Data
public class AdminCommonPARAM implements ApiBaseCommonPARAM {
    @ApiModelProperty(hidden = true)
    private String adminAccount;
    @ApiModelProperty(hidden = true)
    private String adminName;

    @Override
    public String getOperatorId() {
        return adminAccount;
    }

    @Override
    public String getOperatorName() {
        return adminName;
    }

    @Override
    public OperatorTypeENUM getOperatorType() {
        return OperatorTypeENUM.ADMIN;
    }

}
