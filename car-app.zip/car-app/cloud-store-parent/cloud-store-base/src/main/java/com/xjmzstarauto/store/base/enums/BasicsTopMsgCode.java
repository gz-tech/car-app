package com.xjmzstarauto.store.base.enums;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.code.MsgCodeSupport;

/**
 * @author wuchenghua
 * @create 2018-12-25 8:04 PM
 * @desc
 **/
public enum BasicsTopMsgCode implements MsgCode {

    /**
     * http级返回码
     */
    HTTP_STATUS_BIZ_ERROR(400, "Bad Request", true),
    HTTP_STATUS_SYS_ERROR(500, "网络错误，请重试", true),


    /**
     * 协议级返回码
     */
    UPGRADE(100, "您当前版本需要升级", true),
    UPGRADE_DATA(101, "需更新配置或数据", true),
    SUCCESS(200, "操作成功", true),
    REDIRECT(300, "重定向", true),
    LOGIN_FAIL(401, "请登录后再操作", true),
    FORBIDDEN(403, "权限不足", true),
    NOT_FOUND(404, "Not Found", true),
    NO_REGISTER(405, "未注册", true),

    /**
     * 系统级错误码
     */
    SYSTEM_ERROR(1001, "系统错误"),
    SERVICE_PAUSE(1002, "服务暂停"),
    SERVICE_BUSY(1003, "服务繁忙"),

    /**
     * 业务级错误码
     */
    WEB_ERROR(10000, "服务端web异常"),
    SERVICE_ERROR(20000, "服务端service异常"),
    DAO_ERROR(30000, "服务端dao异常"),
    FEIGN_ERROR(40000, "服务间调用异常"),
    REDIS_ERROR(50000, "缓存异常"),


    /**
     * 其它错误码
     */
    OTHER_ERROR(900000, "其它错误"),
    /**
     * 积分商城 商品不存在或下架 统一码
     */
    GOODS_DISABLE(30200404, "该商品不存在或已下架", true);

    private final MsgCodeSupport support;


    BasicsTopMsgCode(int code, String message) {
        support = new MsgCodeSupport(code, message);
    }

    BasicsTopMsgCode(int code, String message, boolean commonCode) {
        support = new MsgCodeSupport(code, message, commonCode);
    }

    @Override
    public int code() {
        return support.code();
    }

    @Override
    public String message() {
        return support.message();
    }

    @Override
    public boolean isCommonCode() {
        return support.isCommonCode();
    }


}
