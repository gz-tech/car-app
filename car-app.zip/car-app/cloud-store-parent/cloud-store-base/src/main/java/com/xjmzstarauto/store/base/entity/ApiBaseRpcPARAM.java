package com.xjmzstarauto.store.base.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wuchenghua
 * @since 2024/9/5
 */
@Data
public class ApiBaseRpcPARAM implements IApiBaseRpcPARAM, Serializable {
    private ApiCommonPARAM apiCommonParam;
}
