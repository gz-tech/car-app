package com.xjmzstarauto.store.base.entity;

import java.io.Serializable;

public interface IPagePARAM extends Serializable {

    Integer getPageNum();

    void setPageNum(Integer pageNum);

    Integer getPageSize();

    void setPageSize(Integer pageSize);

    default String getSortParamStr() {
        return null;
    }

    default void setSortParamStr(String sortParamStr) {

    }

    default Boolean getStatTotal() {
        return true;
    }

    default void setStatTotal(Boolean statCount) {

    }
}
