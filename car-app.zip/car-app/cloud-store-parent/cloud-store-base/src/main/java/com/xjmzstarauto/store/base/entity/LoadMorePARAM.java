package com.xjmzstarauto.store.base.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class LoadMorePARAM implements ILoadMorePARAM, Serializable {
    private Long seqStart;
    private String traceCode;
}
