package com.xjmzstarauto.store.base.code;


import lombok.extern.slf4j.Slf4j;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MsgCodeSupport implements MsgCode {

    private final static Map<Integer, MsgCode> MSG_CODE_REGISTRY = new ConcurrentHashMap<>();
    private final int code;
    private final String message;
    private final boolean commonCode;


    public MsgCodeSupport(int code) {
        this(code, null);
    }


    public MsgCodeSupport(int code, String message) {
        this.code = code;
        this.message = message;
        this.commonCode = false;
        MsgCode msgCode = MSG_CODE_REGISTRY.get(code);
        if (msgCode != null) {
            log.error("错误码已经被定义了. code= {} ", code);
            //throw new IllegalArgumentException("错误码已经被定义了. code=" + code);
            return;
        }
        MSG_CODE_REGISTRY.put(code, this);
    }


    public MsgCodeSupport(int code, String message, boolean commonCode) {
        this.code = code;
        this.message = message;
        this.commonCode = commonCode;
        MsgCode msgCode = MSG_CODE_REGISTRY.get(code);
        if (msgCode != null) {
            log.error("错误码已经被定义了. code= {} ", code);
            return;
        }
        MSG_CODE_REGISTRY.put(code, this);
    }


    @Override
    public int code() {
        return code;
    }

    @Override
    public String message() {
        return message;
    }

    @Override
    public boolean isCommonCode() {
        return commonCode;
    }
}
