package com.xjmzstarauto.store.base.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Builder(builderMethodName = "bu")
public class PageInfoExpand<T,D> extends PageInfo<T> implements Serializable {

    @ApiModelProperty(value = "拓展数据")
    private D data;

}
