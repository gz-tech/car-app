package com.xjmzstarauto.store.base.entity;

import java.util.List;

public interface IPageInfo<T> {

    /**
     * 数据行
     */
    List<T> getRows();

    /**
     * 数据行
     */
    void setRows(List<T> rows);

    /**
     * 总记录数
     */
    Long getTotal();

    /**
     * 总记录数
     */
    void setTotal(Long total);

    /**
     * 是否有下一页
     *
     * @return
     */
    Boolean getHasMore();

}
