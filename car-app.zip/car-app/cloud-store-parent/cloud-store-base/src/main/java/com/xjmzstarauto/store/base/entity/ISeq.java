package com.xjmzstarauto.store.base.entity;

import java.io.Serializable;

public interface ISeq extends Serializable {

    /**
     * 获取序号
     */
    Long getSeq();

    /**
     * 设置序号
     */
    void setSeq(Long seq);
}
