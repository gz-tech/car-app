package com.xjmzstarauto.store.base.entity;

import com.xjmzstarauto.store.base.code.MsgCode;
import com.xjmzstarauto.store.base.enums.BasicsTopMsgCode;
import lombok.Data;

import java.io.Serializable;

/**
 * 统一结果返回格式
 *
 * @param <T>
 */
@Data
public class Result<T> implements Serializable {
    private int code = 200;
    private String msg = "成功";
    private long timestamp = System.currentTimeMillis();

    private T data;

    public static int codeServiceIdentification = 3000000;

    public Result() {

    }

    public Result(T data) {
        this.data = data;
    }

    public Result(int code, String message) {
        this.code = code;
        this.msg = message;
    }

    public Result(int code, String message, T data) {
        this.code = code;
        this.msg = message;
        this.data = data;
    }

    public static <T> Result<T> success() {
        return success(null);
    }

    public static <T> Result<T> success(T data) {
        return new Result<>(data);
    }

    public static <T> Result<T> error(MsgCode msgCode) {
        final int unionCode = getUnionCode(msgCode);

        return new Result<>(unionCode, msgCode.message());
    }

    public static <T> Result<T> error(MsgCode msgCode, String message) {
        final int unionCode = getUnionCode(msgCode);
        return new Result<>(unionCode, message);
    }

    private static int getUnionCode(MsgCode msgCode) {
        final int unionCode;

        if (msgCode.isCommonCode()) {
            return msgCode.code();
        }

        if (msgCode.code() >= BasicsTopMsgCode.WEB_ERROR.code()) {
            unionCode = codeServiceIdentification + msgCode.code();
        } else {
            unionCode = codeServiceIdentification + BasicsTopMsgCode.WEB_ERROR.code() + msgCode.code();
        }
        return unionCode;
    }

    public static <T> Result<T> error(int code, String message) {
        return new Result<>(code, message);
    }

    public boolean ok() {
        return this.code == 200;
    }
}
