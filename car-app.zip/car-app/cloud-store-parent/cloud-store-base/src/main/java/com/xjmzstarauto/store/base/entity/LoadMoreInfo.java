package com.xjmzstarauto.store.base.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Builder
public class LoadMoreInfo<T extends ISeq> implements ILoadMoreInfo<T> {
    /**
     * 数据行
     */
    private List<T> rows;
    /**
     * 总记录数
     */
    private Boolean hasMore;
    /**
     * 跟踪标记
     */
    private String traceCode;
}
