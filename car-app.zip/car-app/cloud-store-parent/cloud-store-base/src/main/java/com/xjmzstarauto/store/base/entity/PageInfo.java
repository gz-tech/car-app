package com.xjmzstarauto.store.base.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Builder
public class PageInfo<T> implements IPageInfo<T>, Serializable {

    /**
     * 页数
     */
    @ApiModelProperty(value = "页数，1开始")
    private Integer pageNum;
    /**
     * 每页数量
     */
    @ApiModelProperty(value = "每页数量")
    private Integer pageSize;
    /**
     * 数据行
     */
    @ApiModelProperty(value = "数据行")
    private List<T> rows;
    /**
     * 总记录数
     */
    @ApiModelProperty(value = "总记录数")
    private Long total;
    /**
     * 是否有下一页
     */
    @ApiModelProperty(value = "是否有下一页")
    private Boolean hasMore;

    /**
     * 是否有下一页
     *
     * @return
     */
    public Boolean getHasMore() {
        if (Objects.nonNull(hasMore)) {
            return hasMore;
        }
        if (Objects.nonNull(total) && total > 0 && Objects.nonNull(pageNum) && Objects.nonNull(pageSize)) {
            return total > ((pageNum < 1 ? 1 : pageNum) * pageSize);
        }
        return null;
    }

}
