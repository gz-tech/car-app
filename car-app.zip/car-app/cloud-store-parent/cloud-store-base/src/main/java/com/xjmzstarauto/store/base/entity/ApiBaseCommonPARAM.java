package com.xjmzstarauto.store.base.entity;

import com.xjmzstarauto.store.base.enums.OperatorTypeENUM;

import java.io.Serializable;

public interface ApiBaseCommonPARAM extends Serializable {

    /**
     * 操作人用户id
     * @return
     */
    String getOperatorId();

    /**
     * 操作人昵称
     * @return
     */
    String getOperatorName();

    /**
     * 操作人类型
     * @return
     */
    OperatorTypeENUM getOperatorType();
}
