package com.xjmzstarauto.store.support.client;

import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.support.client.model.param.NoticeEmailRpcPARAM;
import com.xjmzstarauto.store.support.client.model.param.NoticeSmsRpcPARAM;

public interface NoticeStub {
    
    Result sendEmail(NoticeEmailRpcPARAM noticeEmailRpcPARAM);
    
    Result sendSms(NoticeSmsRpcPARAM noticeSmsRpcPARAM);
    
}
