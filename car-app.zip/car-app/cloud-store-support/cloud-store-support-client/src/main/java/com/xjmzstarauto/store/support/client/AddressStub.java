package com.xjmzstarauto.store.support.client;


import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.support.client.model.dto.AddressRpcDTO;
import com.xjmzstarauto.store.support.client.model.param.AddressRpcPARAM;

public interface AddressStub {

    Result<AddressRpcDTO> getUserAddress(AddressRpcPARAM param);
}
