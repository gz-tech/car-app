package com.xjmzstarauto.store.support.client;

import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.support.client.model.dto.SysParameterRpcDTO;
import com.xjmzstarauto.store.support.client.model.dto.SysParameterUpdateByKeyAdminRpcDTO;
import com.xjmzstarauto.store.support.client.model.param.SysParameterGetByKeyAdminRpcPARAM;
import com.xjmzstarauto.store.support.client.model.param.SysParameterUpdateByKeyAdminRpcPARAM;

/**
 * 系统参数 rpc服务
 *
 * @author zhongwanlin
 * @since 2023-10-23
 */
public interface SysParameterAdminStub {

    Result<SysParameterRpcDTO> getByKey(SysParameterGetByKeyAdminRpcPARAM param);

    Result<SysParameterUpdateByKeyAdminRpcDTO> updateByKey(SysParameterUpdateByKeyAdminRpcPARAM param);
}
