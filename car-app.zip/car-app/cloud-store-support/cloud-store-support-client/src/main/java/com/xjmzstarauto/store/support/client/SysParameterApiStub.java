package com.xjmzstarauto.store.support.client;


import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.support.client.model.dto.SysParameterListRpcDTO;
import com.xjmzstarauto.store.support.client.model.dto.SysParameterRpcDTO;
import com.xjmzstarauto.store.support.client.model.param.SysParameterGetByKeyRpcPARAM;
import com.xjmzstarauto.store.support.client.model.param.SysParameterGetByKeysRpcPARAM;

/**
 * 系统参数 rpc服务
 *
 * @author zhongwanlin
 * @since 2023-10-07
 */
public interface SysParameterApiStub {

    Result<SysParameterRpcDTO> getByKey(SysParameterGetByKeyRpcPARAM param);

    Result<SysParameterListRpcDTO> getByKeys(SysParameterGetByKeysRpcPARAM param);
}
