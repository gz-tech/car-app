package com.xjmz.order.center.application;

import com.xjmz.order.center.util.AESUtils;
import org.junit.Test;

public class AESUtilsTest extends JunitBaseTest{

    @Test
    public void test(){
        String content = "test";
        String encrypt = AESUtils.encrypt(content);
        System.out.println("###### encrypt="+encrypt);
        System.out.println("#### 解密："+AESUtils.decrypt(encrypt));
    }

}
