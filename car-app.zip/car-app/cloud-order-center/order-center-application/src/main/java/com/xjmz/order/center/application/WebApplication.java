package com.xjmz.order.center.application;

import com.alibaba.fastjson2.JSON;
import com.meizu.xjsd.platform.rocketmq.anno.EnableUnionRocketMQCluster;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * 启动类
 */

@SpringBootApplication(scanBasePackages = {"com.xjmz.order.center","com.xjmz.dreamcar","com.meizu","com.flyme"})
@MapperScan(basePackages = "com.xjmz.order.center.dao.mapper")
@EnableTransactionManagement
@EnableFeignClients("com.xjmz.order.center")
@EnableDiscoveryClient
@ImportResource(value={"classpath:baseservice-properties.xml"})
@EnableUnionRocketMQCluster
public class WebApplication {

    public static void main(String[] args) {
        JSON.configWriterDateFormat("millis");
        SpringApplication.run(WebApplication.class, args);
    }

}
