package com.xjmz.order.center.service;


import com.xjmz.order.center.dao.entity.OrderSyncDO;
import com.xjmz.order.center.model.bo.OrderSyncQueryBO;
import com.xjmz.order.center.model.bo.OrderSyncUpdateBO;

import java.util.List;

public interface OrderSyncService {

    Long create(OrderSyncDO orderSyncDO);

    /**
     * 定时任务捞取的记录
     * @param orderSyncQueryBO
     * @return
     */
     List<OrderSyncDO> queryListForJob(OrderSyncQueryBO orderSyncQueryBO);



    /**
     * 根据id更新
     * @param orderUpdateBO
     * @return
     */

    void updateSelectById( OrderSyncUpdateBO orderUpdateBO );


    /**
     * 根据orderSN,identifi_key,targetSys、operate_type更新
     * @param orderUpdateBO
     * @return
     */

    void updateByOrderSnIdentifi( OrderSyncUpdateBO orderUpdateBO );



}
