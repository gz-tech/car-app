package com.xjmz.order.center.business;

import java.util.Date;

public interface VinScheduleRecordJobBusiness {

    /**
     * 排产支付后，更新订单状态
     *
     * @param date
     * @param fetchNum
     */

     void vinScheduleJob(Date date, Integer fetchNum);
}
