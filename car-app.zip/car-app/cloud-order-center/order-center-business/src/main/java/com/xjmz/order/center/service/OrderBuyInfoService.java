package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderBuyInfoDO;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.order.center.model.bo.OrderBuyInfoUpdateBO;

/**
 *
 * 订单表购买信息 服务
 *
 * @author haitao.liu
 * @date 2023-09-27
 */
public interface OrderBuyInfoService extends IService<OrderBuyInfoDO> {

    /**
     * 插入一条记录
     *
     * @param order 实体对象
     */
    Long create(OrderBuyInfoDO order);
    



    /**
     * 根据 ID 查询
     *
     * @param id 主键ID
     */
    OrderBuyInfoDO findOneById(Long id);

    /**
     * 根据订单号修改订单信息
     * @param updateBO
     * @return
     */
     boolean updateByOrderSn( OrderBuyInfoUpdateBO updateBO );


}
