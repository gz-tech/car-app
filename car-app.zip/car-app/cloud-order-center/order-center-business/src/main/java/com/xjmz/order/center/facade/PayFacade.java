package com.xjmz.order.center.facade;


import com.xjmz.order.center.business.PayBusiness;
import com.xjmz.order.center.business.RefundPayBusiness;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import com.xjmz.order.center.dto.request.*;
import com.xjmz.order.center.dto.response.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 支付门面
 */
@Slf4j
@Service
public class PayFacade {

    @Autowired
    private PayBusiness payBusiness;

    @Autowired
    private RefundPayBusiness refundPayBusiness;


    /**
     * 创建支付流程
     * @param payCreateRequest
     * @param apiCommonParam
     * @return
     */
    public PayCreateResponse payRecordCreate(PayCreateRequest payCreateRequest, ApiUserParam apiCommonParam) {
         return payBusiness.payRecordCreate(payCreateRequest,apiCommonParam);
    }

    /**
     * 支付回调流程
     *
     * @param request
     * @return
     */
    public PayCallbackResponse payCallBack(PayCallbackRequest request){
        return payBusiness.payCallBack(request);
    }

    /**
     * 支付查询接口
     *
     * @param payQueryRequest
     * @param apiCommonParam
     * @return
     */
    public PayQueryResponse payQuery(PayQueryRequest payQueryRequest, ApiUserParam apiCommonParam){
        return payBusiness.payQuery(payQueryRequest,apiCommonParam);
    }


    /**
     * 创建退款支付
     * @param request
     * @param apiCommonParam
     * @return
     */
    public PayRefundCreateResponse refundPayRecordCreate(OrderRefundRequest request, ApiUserParam apiCommonParam) {
        return refundPayBusiness.refundPayRecordCreate(request,apiCommonParam);
    }


    /**
     * 退款回调
     * @param request
     * @return
     */
    public RefundPayCallbackResponse refundPayCallBack(RefundPayCallbackRequest request){
        return refundPayBusiness.refundPayCallBack(request);
    }

    /**
     * 退款结果查询
     *
     * @param request
     * @param apiCommonParam
     * @return
     */
    public RefundPayQueryResponse refundPayQuery(RefundPayQueryRequest request, ApiUserParam apiCommonParam){
        return refundPayBusiness.refundPayQuery(request,apiCommonParam);
    }
}
