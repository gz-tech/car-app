package com.xjmz.order.center.business;

import com.xjmz.order.center.dao.entity.OrderChildDO;
import com.xjmz.order.center.dto.request.OrderRefundRequest;
import com.xjmz.order.center.dto.request.RefundPayCallbackRequest;
import com.xjmz.order.center.dto.request.RefundPayQueryRequest;
import com.xjmz.order.center.dto.response.PayRefundCreateResponse;
import com.xjmz.order.center.dto.response.RefundPayCallbackResponse;
import com.xjmz.order.center.dto.response.RefundPayQueryResponse;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import com.xjmz.order.center.model.dto.PayRefundQueryRemoteDTO;
import org.springframework.stereotype.Service;

/**
 *
 * 退款支付流水表 服务
 *
 * @Author haitao.liu
 * @date 2023-09-29
 */
@Service
public interface RefundPayBusiness {



    /**
     * 创建支付流程
     *
     * @return
     */
    PayRefundCreateResponse refundPayRecordCreate(OrderRefundRequest request, ApiUserParam apiCommonParam);



    /**
     * 退款回调
     *
     * @param request
     * @return
     */
    RefundPayCallbackResponse refundPayCallBack(RefundPayCallbackRequest request);

    /**
     * 退款结果查询
     *
     * @param request
     * @param apiCommonParam
     * @return
     */
     RefundPayQueryResponse refundPayQuery(RefundPayQueryRequest request, ApiUserParam apiCommonParam);


    /**
     * 调用支付服务退款查询接口
     * @return
     */
     PayRefundQueryRemoteDTO getRefundPayQueryData(OrderChildDO orderChildDO);
}

