package com.xjmz.order.center.http;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.meizu.xjsd.platform.common.Result;
import com.xjmz.order.center.exception.CommonCodeEnum;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Objects;

/**
 * @author
 * @since 2022-10-08
 */
@Slf4j
@Component
public class OkHttpService {

    //创建okHttpClient
    @Autowired
    private OkHttpClient okHttpClient;


    private  int SUCCESS_CODE=200;



    public String postJson(String hostName, String url, String json, Map<String, String> headParam) {
        log.info("httpUtil 发送 post json 请求，url:{}, json:{}", hostName + url, json);
        Response response = null;
        try {
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json);
            // post json提交
            Request request =null;
            if(headParam!=null && !headParam.isEmpty()) {//带header
                Headers.Builder headBuilder = new Headers.Builder();
                headParam.forEach(headBuilder::add);
                Headers headers = headBuilder.build();
                request = new Request.Builder().url(hostName + url).post(body).headers(headers).build();
            }else{
                request = new Request.Builder().url(hostName + url).post(body).build();
            }
            long start = System.currentTimeMillis();
            response = okHttpClient.newCall(request).execute();
            String result = null;
            if (response != null) {
                result = response.body().string();
            }
            long end = System.currentTimeMillis();
            long duration = end - start;
            log.info("OkHttpService 响应  duration={} 毫秒 url={} , result : {}",duration, hostName + url, result);
            return result;
        } catch (Exception e) {
            log.error("httpUtil 发送 post json 请求异常，url={}", url, e);
            e.printStackTrace();
            throw new BusinessException(CommonCodeEnum.THIRD_SYSTEM_ERROR);
        } finally {
            closeResponse(response);
        }
    }


    public <T> T postJson2Object(String hostName,String url, Object reqObject, Class<T> clazz) {
            String response = postJson(hostName,url,JSONObject.toJSONString(reqObject),null);
            if (StringUtils.isNotEmpty(response)) {
                Result result =JSONObject.parseObject(response,Result.class);
                if (result != null) {
                    doCheckResponse(result);//检验结果
                    return JSON.parseObject(JSON.toJSONString(result.getData()),clazz);
                }
            }
            return null;
    }

    public <T> T postJsonStr2Object(String hostName,String url, String reqObjectJson, Class<T> clazz) {
        String response = postJson(hostName,url,reqObjectJson,null);
        if (StringUtils.isNotEmpty(response)) {
            Result result =JSONObject.parseObject(response,Result.class);
            if (result != null) {
                doCheckResponse(result);//检验结果
                return JSON.parseObject(JSON.toJSONString(result.getData()),clazz);
            }
        }
        return null;
    }

    public <T> T postJson2ObjectWithHeader(String hostName,String url, Object reqObject, Class<T> clazz,Map<String, String> headParam) {
        String response = postJson(hostName,url,JSONObject.toJSONString(reqObject),headParam);
        if (StringUtils.isNotEmpty(response)) {
            Result result =JSONObject.parseObject(response,Result.class);
            if (result != null) {
                doCheckResponse(result);//检验结果
                return JSON.parseObject(JSON.toJSONString(result.getData()),clazz);
            }
        }
        return null;
    }


    public  String getJson( String url, Map<String, String> params,
                            Map<String, String> headParam) {
        log.info("httpUtil 发送 getJson 请求，url:{}, params:{},headParam:{}",url, JSONObject.toJSONString(params), JSONObject.toJSONString(headParam));
        Response response = null;
        try {
            String query = query(params);
            String target = url + query;
            Headers.Builder headBuilder = new Headers.Builder();
            Headers headers = null;
            if (headParam != null) {
                headParam.forEach(headBuilder::add);
                headers = headBuilder.build();
            } else {
                headers = headBuilder.build();
            }
            Request req = new Request.Builder().url(target).headers(headers).get().build();
            long start = System.currentTimeMillis();
            response = okHttpClient.newCall(req).execute();
            String result = null;
            if (response != null) {
                result = response.body().string();
            }
            long end = System.currentTimeMillis();
            long duration = end - start;
            log.info("OkHttpService getJson 响应  duration={} 毫秒 url={} , result : {}",duration,  url, result);
            return result;
        } catch (Exception e) {
            log.error("OkHttp getJson invoke error ，url = {}", url, e);
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (Exception e) {
                    log.error("连接池okHttp关闭异常", e);
                }
            }
        }
        return null;
    }

    private static String query(Map<String, String> query) throws IOException {
        StringBuilder sb = new StringBuilder();
        boolean begin = true;
        for (String name : query.keySet()) {
            if (begin) {
                sb.append("?");
            } else {
                sb.append("&");
            }
            sb.append(name).append("=").append(URLEncoder.encode(query.get(name), "UTF-8"));
            begin = false;
        }
        return sb.toString();
    }

    public <T> T getJson2Object(String hostName, String url, Map<String, String> params, Map<String, String> headParam, Class<T> clazz) {
        String response = getJson(hostName + url, params, headParam);
        if (StringUtils.isNotEmpty(response)) {
            Result result =JSONObject.parseObject(response,Result.class);
            if (result != null) {
                doCheckResponse(result);//检验结果
                return JSON.parseObject(JSON.toJSONString(result.getData()),clazz);
            }
        }
        return null;
    }

    private void doCheckResponse(Result result) {
        if (Objects.isNull(result)) {
            throw new BusinessException(CommonCodeEnum.THIRD_SYSTEM_ERROR);
        }
        if (result.getCode()!=SUCCESS_CODE) {
            throw new BusinessException(CommonCodeEnum.THIRD_SYSTEM_ERROR,result.getMsg());
        }
    }

    public void closeResponse(Response response) {
        if (null == response) {
            return;
        }
        try {
            response.close();
        } catch (Exception e) {
            log.error("连接池okHttp关闭异常", e);
        }
    }


}
