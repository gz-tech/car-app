package com.xjmz.order.center.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @author haitao.liu
 */
@Slf4j
@Component
public class RedisUtils {


    @Resource
    private RedisTemplate<String, Object> redisTemplateR;

    private static RedisTemplate<String, Object> redisTemplate;

    @PostConstruct
    public void init() {
        setRedisTemplate(redisTemplateR);
    }

    private static void setRedisTemplate(RedisTemplate<String, Object> redisTemplateO) {
        redisTemplate = redisTemplateO;
    }

    /**
     * 获取key键对应的值（GET key）
     *
     * @param key 键
     * @return
     */
    public static <T> T get(String key) {
        if (null == key) {
            return null;
        }
        return (T) redisTemplate.opsForValue().get(key);
    }


    /**
     * 放入缓存并设置失效时间（setex key seconds value）
     *
     * @param key     键
     * @param value   值
     * @param timeout 失效时间（单位：秒，小于等于0 表示 永久有效）
     */
    public static void set(String key, Object value, long timeout) {
        redisTemplate.opsForValue().set(key, value, timeout, TimeUnit.SECONDS);
    }

    /**
     * 删除key
     *
     * @param key
     */
    public static void del(String key) {
        redisTemplate.delete(key);
    }
}
