package com.xjmz.order.center.util;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/**
 * @author wuchenghua
 * @date 2024/5/30
 */
public class PaySignature {

    private static final String DEFAULT_CHARSET = "UTF-8";

    private static final String SIGN_ALGORITHMS = "SHA256WithRSA";

    private static final String SIGN_TYPE_RSA = "RSA";

    private static Gson gson = new Gson();

    /**
     * RSA2签名方法
     *
     * @param params     待签名内容
     * @param privateKey 私钥
     * @return 签名结果
     */
    public static String sign(Map<String, Object> params, String privateKey) {
        return sign(getSignContent(params), privateKey);
    }

    /**
     * RSA2签名方法
     *
     * @param content    待签名内容
     * @param privateKey 私钥
     * @return 签名结果
     */
    public static String sign(String content, String privateKey) {

        if (StringUtils.isEmpty(content)) {
            throw new IllegalArgumentException("待签名内容不可为空");
        }
        if (StringUtils.isEmpty(privateKey)) {
            throw new IllegalArgumentException("私钥[privateKey]不可为空");
        }

        try {
            return doSign(content, DEFAULT_CHARSET, privateKey);
        } catch (UnsupportedEncodingException e) {
            String errorMessage = String.format("%s签名遭遇异常，请检查编码格式是否正确。 charset=%s",
                    SIGN_TYPE_RSA, DEFAULT_CHARSET);
            throw new RuntimeException(errorMessage, e);
        } catch (Exception e) {
            String errorMessage = String.format("%s签名遭遇异常，请检查私钥格式是否正确。%s content=%s，charset=%s，privateKeySize=%d",
                    SIGN_TYPE_RSA, e.getMessage(), content, DEFAULT_CHARSET, privateKey.length());
            throw new RuntimeException(errorMessage, e);
        }

    }


    /**
     * 密钥模式RSA2 通用验签方法
     *
     * @param paramsJson 待验签字符串
     * @param publicKey  公钥
     * @return 验签结果
     */
    public static boolean verify(String paramsJson, String publicKey) {
        Map<String, String> map = gson.fromJson(paramsJson, new TypeToken<Map<String, String>>() {
        }.getType());
        return verify(map, publicKey);
    }

    /**
     * 密钥模式RSA2 通用验签方法
     *
     * @param params    待验签字符串
     * @param publicKey 公钥
     * @return 验签结果
     */
    public static boolean verify(Map<String, String> params, String publicKey) {
        String sign = params.get("sign");
        String content = getSignCheckContent(params);
        return verify(content, DEFAULT_CHARSET, publicKey, sign);
    }

    /**
     * 密钥模式RSA2 通用验签方法
     *
     * @param content   待验签字符串
     * @param sign      签名
     * @param publicKey 公钥
     * @return 验签结果
     */
    public static boolean verify(String content, String sign, String publicKey) {
        return verify(content, DEFAULT_CHARSET, publicKey, sign);
    }


    public static boolean verify(String content, String charset, String publicKey, String sign) {

        if (StringUtils.isEmpty(content)) {
            throw new IllegalArgumentException("待验签内容不可为空");
        }
        if (StringUtils.isEmpty(publicKey)) {
            throw new IllegalArgumentException("公钥不可为空");
        }
        if (StringUtils.isEmpty(sign)) {
            throw new IllegalArgumentException("签名串不可为空");
        }
        if (StringUtils.isEmpty(charset)) {
            charset = DEFAULT_CHARSET;
        }

        try {
            return doVerify(content, charset, publicKey, sign);
        } catch (Exception e) {
            String errorMessage = String.format("%s验签遭遇异常，请检查公钥格式或签名是否正确。%s content=%s，charset=%s，publicKey=%s，sign=%s",
                    SIGN_TYPE_RSA, e.getMessage(), content, charset, publicKey, sign);
            throw new RuntimeException(errorMessage, e);
        }
    }


    private static boolean doVerify(String content, String charset, String publicKey, String sign) throws Exception {
        PublicKey pubKey = getPublicKeyFromX509(SIGN_TYPE_RSA, publicKey);
        Signature signature = Signature.getInstance(getSignAlgorithm());
        signature.initVerify(pubKey);
        if (StringUtils.isEmpty(charset)) {
            signature.update(content.getBytes());
        } else {
            signature.update(content.getBytes(charset));
        }
        return signature.verify(Base64.decodeBase64(sign.getBytes()));
    }

    public static PublicKey getPublicKeyFromX509(String algorithm,
                                                 String publicKey) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        byte[] encodedKey = Base64.decodeBase64(publicKey);
        return keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
    }


    private static String doSign(String content, String charset, String privateKey) throws Exception {
        PrivateKey priKey = getPrivateKeyFromPKCS8(SIGN_TYPE_RSA, privateKey);
        Signature signature = Signature.getInstance(getSignAlgorithm());
        signature.initSign(priKey);
        if (StringUtils.isEmpty(charset)) {
            signature.update(content.getBytes());
        } else {
            signature.update(content.getBytes(charset));
        }
        byte[] signed = signature.sign();
        return new String(Base64.encodeBase64(signed), charset);
    }

    public static PrivateKey getPrivateKeyFromPKCS8(String algorithm,
                                                    String privateKey) throws Exception {
        if (StringUtils.isEmpty(privateKey) || StringUtils.isEmpty(algorithm)) {
            return null;
        }
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        byte[] encodedKey = Base64.decodeBase64(privateKey);
        return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
    }

    private static String getSignAlgorithm() {
        return SIGN_ALGORITHMS;
    }


    /**
     * @param sortedParams
     * @return
     */
    public static String getSignContent(Map<String, ?> sortedParams) {

        if (Objects.isNull(sortedParams)) {
            return null;
        }

        StringBuilder content = new StringBuilder();
        List<String> keys = new ArrayList<>(sortedParams.keySet());
        Collections.sort(keys);
        int index = 0;
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = Objects.isNull(sortedParams.get(key)) ? "" : String.valueOf(sortedParams.get(key));
            if (areNotEmpty(key, value) && !"sign".equals(key) && !"signType".equals(key)) {
                content.append(index == 0 ? "" : "&").append(key).append("=").append(value);
                index++;
            }
        }
        return content.toString();
    }

    public static String getSignCheckContent(Map<String, String> params) {
        if (params == null) {
            return null;
        }
        params.remove("sign");
        params.remove("signType");
        return getSignContent(params);
    }

    /**
     * 检查指定的字符串列表是否不为空。
     */
    public static boolean areNotEmpty(String... values) {
        return Arrays.stream(values).allMatch(StringUtils::isNotEmpty);
    }


}