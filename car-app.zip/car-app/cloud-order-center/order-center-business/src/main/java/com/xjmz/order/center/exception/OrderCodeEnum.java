package com.xjmz.order.center.exception;


import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.flyme.xjsd.cloud.common.response.ErrorCode;


/**
 * @author haitao.liu
 **/
public enum OrderCodeEnum implements ErrorCode {
    TOKEN_NOT_FOUND_ORDER(211000, "系统繁忙，请稍后操作"),

    ORDER_TYPE_NOT_EXISTS(211001, "订单类型不存在"),

    NO_EXIST_ORDER(211002, "订单不存在或已取消"),

    ORDER_CANCEL_NOT_SUPPORT(211003, "订单不支持取消"),

    ORDER_LOCKED_NOT_SUPPORT(211004, "订单不支持锁定"),

    DEPOSIT_NOT_SUPPORT_MODEL(211005, "车型未配置定金金额"),

    DEPOSIT_MUST_BIG_ZERO_MODEL(211006, "预订金/定金金额必须大于0"),

    USER_ID_NOT_EMPTY(211007, "用户id不能为空"),

    STATUS_MACHINE_NOT_SOURCE(211008, "状态机没有匹配到订单来源"),

    ORDER_PAY_CALLBACK_NOT_SUPPORT(211009, "状态不支持支付回调"),

    LOCK_INTERRUPTED_ERROR(211010, "分布式锁中断异常了"),

    NOT_CONFIG_LITTLE_MSG(211011, "未配置此车型的小定预定信息"),

    GET_USER_INFO_NULL(211012, "根据用户id调用用户服务返回结果为空"),

    SUBMIT_ORDER_ACOUNT_ERROR(211013, "下单金额异常"),

    ORDER_SN_NOT_EMPTY(211014, "订单号不能为空"),

    LITTLE_ORDER_NOT_EXISTS(211015, "小定订单不存在"),

    ORDER_TAIL_UNPAID_NOT_SUPPORT(211016, "订单不支持支付尾款"),

    ORDER_VIN_SCHEDULE_LOCKED_NOT_SUPPORT(211017, "订单不支持导入订单锁定"),

    ORDER_VIN_SCHEDULE_UN_PAY_NOT_SUPPORT(211018, "订单不支持导入待支付尾款"),

    ORDER_VIN_SCHEDULE_ALL_PAY_NOT_SUPPORT(211019, "订单不支持导入交车完成"),

    ORDER_BIG_ORDER_NOT_SUPPORT(211020, "订单不支持大定"),

    ORDER_UPDATE_NOT_SUPPORT(211021, "订单状态不支付修改"),

    OWNER_CAR_TYPE_EMPTY(211022, "购车人证件类型不能为空"),

    OWNER_CAR_NO_EMPTY(211023, "购车人证件号不能为空"),

    OWNER_ENTERPRISE_NAME_NO_EMPTY(211024, "企业名称不能为空"),

    OWNER_ENTERPRISE_CODE_NO_EMPTY(211025, "税务号码不能为空"),

    ;


    private Integer code;
    private String msg;

    @Override
    public int getErrorCode() {
        return this.code;
    }

    @Override
    public String getErrorMessage() {
        return this.msg;
    }


    OrderCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static OrderCodeEnum getError(int code) {
        for (OrderCodeEnum item:values()) {
            if (item.code.equals(code)) {
                return item;
            }
        }
        throw new BusinessException(CommonCodeEnum.SYSTEM_ERROR,"error code not found");
    }

}
