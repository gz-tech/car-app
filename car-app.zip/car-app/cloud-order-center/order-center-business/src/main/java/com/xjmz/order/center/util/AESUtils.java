package com.xjmz.order.center.util;

import com.xjmz.order.center.util.encrypt.AESUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Slf4j
@Component
public class AESUtils extends AESUtil {

    private static String encryptAesKey;
    private static String encryptPrefix = "%^A1$#";

    @Value("${encrypt.aes.key}")
    private String configEncryptAesKey;

    @PostConstruct
    public void init() {
        setEncryptAesKey(configEncryptAesKey);
    }

    private static void setEncryptAesKey(String encryptPrefixStr) {
        encryptAesKey = encryptPrefixStr;
    }


    /**
     * 加密
     *
     * @param content
     * @return
     */
    @SneakyThrows(Exception.class)
    public static String encrypt(String content) {
        if (StringUtils.isBlank(content)) {
            return content;
        }
        if (StringUtils.startsWith(content, encryptPrefix)) {
            return content;
        }
        return encryptPrefix + encrypt(content, encryptAesKey);
    }

    /**
     * 解密
     *
     * @param content
     * @return
     */
    @SneakyThrows(Exception.class)
    public static String decrypt(String content) {
        if (StringUtils.isBlank(content)) {
            return content;
        }
        if (StringUtils.startsWith(content, encryptPrefix)) {
            return decrypt(content.substring(encryptPrefix.length()), encryptAesKey);
        }
        return content;
    }


}
