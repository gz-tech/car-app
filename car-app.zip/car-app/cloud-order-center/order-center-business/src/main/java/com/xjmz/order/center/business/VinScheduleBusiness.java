package com.xjmz.order.center.business;

import com.xjmz.order.center.dao.entity.OrderDO;
import com.xjmz.order.center.dao.entity.OrderVinScheduleRecordDO;

import java.util.Date;
import java.util.List;

public interface VinScheduleBusiness {

    /**
     *  更新排产日志表
     */
    void updateRecordById(OrderVinScheduleRecordDO orderVinScheduleRecordDO);

    /**
     * 查询n分钟之前导入的排产记录
     * @param date
     * @param fetchNum
     * @return
     */

    List<OrderVinScheduleRecordDO>  queryVinScheduleRecord(Date date, Integer fetchNum);

    /**
     * 保存排产明细表、更新排产日志表、更新订单状态
     * @param recordDO
     */
     void  dealVinScheduleData(OrderVinScheduleRecordDO recordDO,OrderDO orderDO);
}
