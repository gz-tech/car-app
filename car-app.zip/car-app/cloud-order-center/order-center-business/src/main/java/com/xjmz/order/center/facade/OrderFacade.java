package com.xjmz.order.center.facade;


import com.xjmz.order.center.business.OrderBusiness;
import com.xjmz.order.center.business.OrderOperateBusiness;
import com.xjmz.order.center.dto.request.*;
import com.xjmz.order.center.dto.request.operate.OperateOwnerRequest;
import com.xjmz.order.center.dto.request.operate.OperatePurchasePlanRequest;
import com.xjmz.order.center.dto.request.operate.OperateStoreRequest;
import com.xjmz.order.center.dto.request.sap.SapRequestRequest;
import com.xjmz.order.center.dto.response.*;
import com.xjmz.order.center.model.base.param.ApiCommonParam;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import com.xjmz.order.center.model.bo.detail.OrderQueryDetailBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrderFacade {

    @Autowired
    private OrderBusiness orderBusiness;


    @Autowired
    private OrderOperateBusiness orderOperateBusiness;


    /**
     * 小定下单
     *
     * @param orderSubmitRequest
     * @param apiCommonParam
     * @return
     */
    public OrderSubmitResponse littleSubmit(OrderLittleSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam) {
        return orderBusiness.littleSubmit(orderSubmitRequest, apiCommonParam);
    }


    /**
     * 大定下单
     *
     * @param orderSubmitRequest
     * @param apiCommonParam
     * @return
     */
    public OrderSubmitResponse bigSubmit(OrderBigSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam) {
        return orderBusiness.bigSubmit(orderSubmitRequest, apiCommonParam);
    }

    /**
     * 小定转大定
     *
     * @param orderSubmitRequest
     * @param apiCommonParam
     * @return
     */
    public OrderSubmitResponse littlePayToBigSubmit(OrderBigSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam) {
        return orderBusiness.littlePayToBigSubmit(orderSubmitRequest, apiCommonParam);
    }

    /**
     * 取消订单
     *
     * @param request
     * @return
     */
    public Boolean cancel(OrderCancelRequest request, ApiUserParam apiUserParam) {
        return orderBusiness.cancel(request, apiUserParam);
    }

    /***
     * 用户锁定订单
     * @param request
     * @param apiUserParam
     * @return
     */

    public Boolean locked(OrderLockedRequest request, ApiUserParam apiUserParam) {
        return orderBusiness.locked(request, apiUserParam);
    }


    /**
     * 个人-查询订单列表
     *
     * @param apiCommonParam
     * @return
     */
    public OrderQueryListResponse queryOrderByUid(OrderQueryListRequest request, ApiCommonParam apiCommonParam) {
        return orderBusiness.queryOrderByUid(request, apiCommonParam);
    }

    /**
     * 个人--订单详情
     *
     * @return
     */
    public OrderQueryDetailBO queryOrderDetail(OrderDetailRequest request, ApiCommonParam apiCommonParam) {
        return orderBusiness.queryOrderDetail(request, apiCommonParam);
    }


    /**
     * 根据车型获取小定预定展示页
     *
     * @param request
     * @return
     */
    public LittleDisplayResponse displayPreLittle(LittleDisplayRequest request) {
        return orderBusiness.displayPreLittle(request);
    }

    /**
     * 查询待支付的订单数量
     *
     * @param apiCommonParam
     * @return
     */
    public OrderUnPayResponse selectUnPayCount(ApiCommonParam apiCommonParam) {
        Long num = orderBusiness.selectUnPayCount(apiCommonParam);
        return OrderUnPayResponse.builder().unPayNum(num).build();
    }

    /**
     * sap回调
     *
     * @param request
     * @return
     */
    public Boolean sapCallBack(SapRequestRequest request) {
        return orderBusiness.sapCallBack(request);
    }


    /**
     * 查询用户下的小定订单数量
     *
     * @param apiCommonParam
     * @return
     */
    public Long queryLittleOrderByUid(ApiCommonParam apiCommonParam) {
        return orderBusiness.queryLittleOrderByUid(apiCommonParam);
    }

    /**
     * 查询没有完结订单
     *
     * @return
     */
    public AllowCancelResponse findNoCompletion(ApiCommonParam apiCommonParam) {
        return orderBusiness.findNoCompletion(apiCommonParam);
    }


    /**
     * 根据订单号修改:购车信息
     *
     * @return
     */
    public boolean updateOwner(OperateOwnerRequest request,ApiUserParam apiUserParam) {
        return orderOperateBusiness.updateOwner(request,apiUserParam);
    }

    /**
     * 根据订单号修改:购车方案
     * 0:分期 1:全款
     *
     * @return
     */
    public boolean updatePurchasePlan(OperatePurchasePlanRequest request,ApiUserParam apiUserParam) {
        return orderOperateBusiness.updatePurchasePlan(request,apiUserParam);
    }

    /**
     * 根据订单号修改:交付门店
     *
     * @return
     */
    public boolean updateReceiverStore(OperateStoreRequest request,ApiUserParam apiUserParam) {
        return orderOperateBusiness.updateReceiverStore(request,apiUserParam);
    }

    /**
     * 根据订单号修改:销售门店
     *
     * @return
     */
    public boolean updateSaleStore(OperateStoreRequest request,ApiUserParam apiUserParam) {
        return orderOperateBusiness.updateSaleStore(request,apiUserParam);
    }
}
