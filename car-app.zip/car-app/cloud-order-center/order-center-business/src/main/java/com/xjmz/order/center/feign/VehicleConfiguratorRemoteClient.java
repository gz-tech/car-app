package com.xjmz.order.center.feign;

import com.xjmz.order.center.model.dto.VehicleSkuResDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * vehicleConfigurator接口远程调用
 * @author haitao.liu
 * @date 2024/3/11 16:24
 */
@FeignClient(name = "cloud-vehicle-configurator-client")
public interface VehicleConfiguratorRemoteClient {

    @GetMapping(value ="/vehicle/config/client/getSkuSimpleDetailById", produces = "application/json")
    VehicleSkuResDTO getSkuSimpleDetailById(@RequestParam("skuId") Long skuId);


}

