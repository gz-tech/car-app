package com.xjmz.order.center.business;

import com.xjmz.order.center.dao.entity.OrderDO;
import com.xjmz.order.center.dao.entity.OrderTailPayRecordDO;

import java.util.Date;
import java.util.List;

public interface TailPayBusiness {

    /**
     *  更新尾款日志表
     * @param recordDO
     */
     void updateTailPayRecordById(OrderTailPayRecordDO recordDO);

    /**
     * 查询n分钟之前导入的尾款记录
     * @param date
     * @param fetchNum
     * @return
     */

     List<OrderTailPayRecordDO> queryTailPayRecord(Date date, Integer fetchNum);

    /**
     * 保存尾款明细表、更新尾款日志表、更新订单状态
     * @param recordDO
     */
     void dealTailPayData(OrderTailPayRecordDO recordDO, OrderDO orderDO);
}
