package com.xjmz.order.center.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.springframework.scheduling.annotation.AsyncResult;

import java.util.List;
import java.util.concurrent.*;

/**
 * @author haitao.liu
 * @version 1.0
 * @className AsyncExecutor
 * @description 只允许请求接口中，短暂执行（可预知执行时间）或者需要知道结果的请求调用使用。任务或者接口中可能长时间执行的代码，请使用AsyncTaskExecutor
 * @date 2023/2/6 15:54
 */
@Slf4j
public class AsynExecutor {

    private static final ExecutorService ASYN_EXECUTOR;
    private static final ExecutorService ASYN_EXECUTOR_FUTURE;

    /**
     * 订单同步得线程池隔离出来防止影响核心得线程池
     */
    private static final ExecutorService ORDER_SYNC_EXECUTOR;

    public static final int corePollSize = 10;

    static {
        BasicThreadFactory factory = new BasicThreadFactory.Builder().namingPattern("myplus-qing-poll-%d").daemon(true).build();

        ASYN_EXECUTOR = new ThreadPoolExecutor(corePollSize, 30,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(10000), factory, new ThreadPoolExecutor.AbortPolicy());

        ASYN_EXECUTOR_FUTURE = new ThreadPoolExecutor(corePollSize, 30,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(10000), factory, new ThreadPoolExecutor.AbortPolicy());

        ORDER_SYNC_EXECUTOR = new ThreadPoolExecutor(5, 30,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(10000), factory, new ThreadPoolExecutor.AbortPolicy());
    }

    public static void execute(Runnable thread) {
        try {
            ASYN_EXECUTOR.execute(thread);
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
        }
    }

    public static void executeOrderSync(Runnable thread) {
        try {
            ORDER_SYNC_EXECUTOR.execute(thread);
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
        }
    }

    public static int getActiveCount() {
        return ((ThreadPoolExecutor) ASYN_EXECUTOR).getActiveCount();
    }

    /**
     * 延迟执行
     *
     * @param thread
     * @param delayMillisecond
     */
    public static void execute(Runnable thread, long delayMillisecond) {
        try {
            ASYN_EXECUTOR.execute(() -> {
                try {
                    Thread.sleep(delayMillisecond);
                } catch (InterruptedException e) {
                }
                thread.run();
            });
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
        }
    }

    public static void executeAll(Runnable... threads) {
        if (ArrayUtils.isEmpty(threads)) {
            return;
        }

        try {
            for (Runnable thread : threads) {
                ASYN_EXECUTOR.execute(thread);
            }
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
        }
    }

    public static void executeByStep(Runnable... threads) {
        if (ArrayUtils.isEmpty(threads)) {
            return;
        }

        try {
            for (Runnable thread : threads) {
                ASYN_EXECUTOR.submit(thread).get();
            }
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
        }
    }

    public static <T> Future<T> submit(Callable<T> runner) {
        try {
            return ASYN_EXECUTOR_FUTURE.submit(runner);
        } catch (Exception e) {
            log.error("异步任务提交失败", e);
            return AsyncResult.forValue(null);
        }
    }

    /**
     * @param runner
     * @param millisecond 超过多少毫秒打印日志
     * @param msg         打印日志
     * @param <T>
     * @return
     */
    public static <T> Future<T> submit(Callable<T> runner, Integer millisecond, String msg) {
        return submit(() -> run(runner, millisecond, msg));
    }

    private static <T> T run(Callable<T> runner, Integer millisecond, String msg) throws Exception {
        long millis = System.currentTimeMillis();
        T call = runner.call();
        long useMillis = System.currentTimeMillis() - millis;
        if (useMillis >= millisecond) {
            log.warn(msg + " 耗时:" + useMillis + "ms");
        }
        return call;
    }

    public static <T> List<Future<T>> invokeAll(List<Callable<T>> tasks) {
        try {
            return ASYN_EXECUTOR_FUTURE.invokeAll(tasks);
        } catch (Exception e) {
            log.error("invokeall error: ", e);
            return null;
        }
    }
}
