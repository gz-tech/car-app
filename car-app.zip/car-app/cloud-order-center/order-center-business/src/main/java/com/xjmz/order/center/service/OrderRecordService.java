package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderRecordDO;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.stereotype.Service;

/**
 *
 * 订单操作日志表 服务
 *
 * @author haitao.liu
 * @date 2023-09-27
 */
@Service
public interface OrderRecordService extends IService<OrderRecordDO> {

    /**
     * 插入一条记录
     *
     * @param orderRecord 实体对象
     */
    Long create(OrderRecordDO orderRecord);
    


    /**
    * 根据 ID 删除
    *
    * @param id 主键ID
    */
    int deleteById(Long id);

}
