package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderVinScheduleRecordDO;

import java.util.Date;
import java.util.List;

public interface OrderVinScheduleRecordService {
    /**
     * 查询n分钟之前导入的记录
     * @param targetDate
     * @return
     */
     List<OrderVinScheduleRecordDO> queryVinScheduleRecord(Date targetDate, int fetchNum);


    /**
     * 根据id更新记录
     * @param recordDO
     */
     void updateRecordById(OrderVinScheduleRecordDO recordDO);
}
