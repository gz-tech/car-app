package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderVinScheduleDetailDO;

import java.util.List;

public interface OrderVinScheduleDetailService {

    /**
     * 插入或更新排产明细表
     */
     void insertOrUpdateData(OrderVinScheduleDetailDO orderVinScheduleDetailDO);

    /**
     * 根据订单号查询排产明细
     * @param orderSn
     * @return
     */
     List<OrderVinScheduleDetailDO> queryDetailByOrderSn(String orderSn);
}
