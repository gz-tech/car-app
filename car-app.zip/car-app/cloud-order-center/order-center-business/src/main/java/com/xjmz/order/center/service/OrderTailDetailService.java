package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderTailDetailDO;

import java.util.List;

public interface OrderTailDetailService {

    /**
     * 插入或更新尾款明细表
     * @param orderTailDetailDO
     */
     void insertOrUpdateData(OrderTailDetailDO orderTailDetailDO);

    /**
     * 根据订单号查询尾款明细
     * @param orderSn
     * @return
     */
     List<OrderTailDetailDO> queryDetailByOrderSn(String orderSn);
}
