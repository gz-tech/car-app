package com.xjmz.order.center.business;

import com.xjmz.order.center.dto.request.operate.OperateOwnerRequest;
import com.xjmz.order.center.dto.request.operate.OperatePurchasePlanRequest;
import com.xjmz.order.center.dto.request.operate.OperateStoreRequest;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import org.springframework.stereotype.Service;

/**
 * 订单修改服务
 * haitao.liu
 */
@Service
public interface OrderOperateBusiness {


    /**
     * 根据订单号修改:购车信息
     * @return
     */
     boolean updateOwner(OperateOwnerRequest request, ApiUserParam apiUserParam);

    /**
     * 根据订单号修改:购车方案
     * 0:分期 1:全款
     * @return
     */
    boolean updatePurchasePlan(OperatePurchasePlanRequest request,ApiUserParam apiUserParam);


    /**
     * 根据订单号修改:交付门店
     *
     * @return
     */
     boolean updateReceiverStore(OperateStoreRequest request,ApiUserParam apiUserParam);

    /**
     * 根据订单号修改:销售门店
     *
     * @return
     */
     boolean updateSaleStore(OperateStoreRequest request,ApiUserParam apiUserParam);

}
