package com.xjmz.order.center.exception;

import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.flyme.xjsd.cloud.common.response.ErrorCode;

/**
 * @Author haitao.liu
 * @Date 2023/9/29 16:17
 * @description:01代表支付模块异常
 */
public enum PayCodeEnum implements ErrorCode {

    NO_EXIST_ORDER(231000, "订单不存在或已取消"),

    ORDER_STATUS_PAY_ORDER(231001, "订单状态不满足支付条件"),

    PAY_ORDER_NUM_EMPTY(231002, "支付流水号不存在"),

    PAY_REALFEE_ERROR(231003, "实付金额校验失败"),

    ORDER_SOURCE_NOT_EXISTS(231004, "订单来源不存在"),

    INVOKE_PAY_SERVICE_ERROR(231005, "调用支付服务异常"),

    VERIFICATION_ERROR(231006,"支付回调签名错误"),

    PAY_REFUND_STATUS_ERROR(231007,"订单不支持退款"),

    INVOKE_PAY_REFUND_SERVICE_ERROR(231008,"调用退款接口结果返回失败或接口超时"),

    REFUND_PAY_REALFEE_ERROR(231009, "退款金额校验失败"),

    PAY_REFUND_CALLBACK_STATUS_ERROR(231010,"订单不支持退款回调"),

    PAY_CALL_BACK_NOT_FOUND(231011, "系统繁忙，请重新退款回调"),

    PAY_HAS_SUC(231012, "订单已支付完成"),

    ;


    private Integer code;
    private String msg;

    @Override
    public int getErrorCode() {
        return this.code;
    }

    @Override
    public String getErrorMessage() {
        return this.msg;
    }


    PayCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static PayCodeEnum getError(int code) {
        for (PayCodeEnum item:values()) {
            if (item.code.equals(code)) {
                return item;
            }
        }
        throw new BusinessException(CommonCodeEnum.SYSTEM_ERROR,"error code not found");
    }

}