package com.xjmz.order.center.business;

import com.xjmz.order.center.dto.request.OrderRefundRequest;
import com.xjmz.order.center.dto.response.PayRefundCreateResponse;
import com.meizu.xjsd.platform.common.Result;

/**
 * haitao.liu
 * 订单rpc服务
 */
public interface OrderRpcBusiness {

    /**
     * 创建退款请求
     * @param orderRefundRequest
     * @return
     */
     Result<PayRefundCreateResponse> refundPayRecordCreate(OrderRefundRequest orderRefundRequest);
}
