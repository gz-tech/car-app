package com.xjmz.order.center.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.order.center.dao.entity.OrderDO;
import com.xjmz.order.center.dao.po.OrderQueryDetailPO;
import com.xjmz.order.center.dao.po.OrderQueryListPO;
import com.xjmz.order.center.model.bo.OrderQueryBO;
import com.xjmz.order.center.model.bo.OrderUpdateBO;

import java.util.List;

/**
 *
 * 母订单表 服务
 *
 * @author haitao.liu
 * @date 2023-09-27
 */
public interface OrderService extends IService<OrderDO> {

    /**
     * 插入一条记录
     *
     * @param order 实体对象
     */
    Long create(OrderDO order);
    



    /**
     * 根据 ID 查询
     *
     * @param id 主键ID
     */
    OrderDO findOneById(Long id);

    /**
    * 根据 条件查询一条数据
    *
    */
    OrderDO findOne(OrderQueryBO orderQueryBO);


    /**
     * 为空判断更新
     * @param orderUpdateBO
     * @return
     */
    boolean updateSelectById( OrderUpdateBO orderUpdateBO );

    /**
     * 个人-订单列表查询
     * @return
     */
     Page<OrderQueryListPO> selectByUserId(IPage page,  String userId,  String orderSn, List<Integer> statusList);



    /**
     * 个人-订单详情
     * @return
     */
    OrderQueryDetailPO selectDetail(String orderSn );

    /**
     * 查询待支付的订单数量
     * @param orderQueryBO
     * @return
     */
     Long selectUnPayCount(OrderQueryBO orderQueryBO);

    /**
     * 根据用户id、车型code查询指定订单状态的最近一条订单记录
     * @param orderQueryBO
     * @return
     */
     OrderDO queryOrderByUidModel(OrderQueryBO orderQueryBO);

    /**
     * 查询没有完结订单
     * @param orderQueryBo
     * @return
     */
    OrderDO findNoCompletion(OrderQueryBO orderQueryBo);


}
