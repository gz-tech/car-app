package com.xjmz.order.center.business;

import java.util.Date;

public interface TailPayRecordJobBusiness {

    /**
     * 尾款支付后，更新订单状态
     *
     * @param date
     * @param fetchNum
     */

     void tailPayJob(Date date, Integer fetchNum);
}
