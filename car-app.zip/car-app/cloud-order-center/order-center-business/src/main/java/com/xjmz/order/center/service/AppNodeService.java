package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.AppNodeDO;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.stereotype.Service;

/**
 * 应用节点表 服务
 *
 * @author haitao.liu
 * @since 2023-10-09
 */
@Service
public interface AppNodeService extends IService<AppNodeDO> {

    /**
     * 插入一条记录
     *
     * @param appNode 实体对象
     */
    Long create(AppNodeDO appNode);



    /**
     * 根据 ID 删除
     *
     * @param id 主键ID
     */
    int deleteById(Long id);

    /**
     * 根据 ID 查询
     *
     * @param id 主键ID
     */
    AppNodeDO findOneById(Long id);


    /**
     * 应用上线
     *
     * @param appKey
     * @param appId
     * @return
     */
    boolean appUp(String appKey, Integer appId, String ip);

    /**
     * 应用下线
     *
     * @param appKey
     * @param appId
     */
    void appDown(String appKey, Integer appId);

    /**
     * 旧应用下线
     *
     */
    void appDownOld();

}
