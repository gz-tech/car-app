package com.xjmz.order.center.util;

public class HttpHeaderUtils {
    public static String BEARER = "Bearer ";

    public HttpHeaderUtils() {
    }

    public static String addAuthorizationHeadPrefix(String token) {
        return token.startsWith(BEARER) ? token : BEARER + token;
    }
}
