package com.xjmz.order.center.business;

import com.xjmz.order.center.dao.entity.OrderChildDO;
import com.xjmz.order.center.dto.request.*;
import com.xjmz.order.center.dto.request.sap.SapRequestRequest;
import com.xjmz.order.center.dto.response.AllowCancelResponse;
import com.xjmz.order.center.dto.response.LittleDisplayResponse;
import com.xjmz.order.center.dto.response.OrderQueryListResponse;
import com.xjmz.order.center.dto.response.OrderSubmitResponse;
import com.xjmz.order.center.model.base.param.ApiCommonParam;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import com.xjmz.order.center.model.bo.detail.OrderQueryDetailBO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 下单服务
 */
@Service
public interface OrderBusiness {



    /**
     * 提交小定下单
     *
     * @param orderSubmitRequest
     * @return
     */
    OrderSubmitResponse littleSubmit(OrderLittleSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam);



    /**
     * 提交小定下单
     *
     * @param orderSubmitRequest
     * @return
     */
    OrderSubmitResponse bigSubmit(OrderBigSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam);


    /**
     * 取消订单
     *
     * @param request
     * @param apiCommonParam
     * @return
     */
    Boolean cancel(OrderCancelRequest request, ApiUserParam apiCommonParam);

    /***
     * 取消订单公共方法
     * @param orderChildDOList
     * @param apiUserParam
     */

    void cancelOrderCommon(List<OrderChildDO> orderChildDOList, ApiUserParam apiUserParam, String reason);


    /**
     * 小定转大定
     * @param orderSubmitRequest
     * @param apiCommonParam
     * @return
     */
    OrderSubmitResponse littlePayToBigSubmit(OrderBigSubmitRequest orderSubmitRequest, ApiUserParam apiCommonParam);

    /**
     * 用户锁定订单
     * @param request
     * @param apiCommonParam
     * @return
     */

     Boolean locked(OrderLockedRequest request, ApiUserParam apiCommonParam);


    /**
     * 个人-查询订单列表
     * @param apiCommonParam
     * @return
     */
    OrderQueryListResponse queryOrderByUid(OrderQueryListRequest request, ApiCommonParam apiCommonParam);


    /**
     * 个人--订单详情
     * @param apiCommonParam
     * @return
     */
     OrderQueryDetailBO queryOrderDetail(OrderDetailRequest request, ApiCommonParam apiCommonParam);


    /**
     * 根据车型获取小定预定展示页
     * @param request
     * @return
     */
     LittleDisplayResponse displayPreLittle(LittleDisplayRequest request);

    /**
     * 查询待支付的订单数量
     * @param apiCommonParam
     * @return
     */
     Long selectUnPayCount(ApiCommonParam apiCommonParam);

    /**
     * sap回调
     * @param request
     * @return
     */
     Boolean sapCallBack(SapRequestRequest request);

    /**
     * 查询用户下的小定订单号数量
     * @param apiCommonParam
     * @return
     */
     Long queryLittleOrderByUid(ApiCommonParam apiCommonParam);

    /**
     * 查询没有完结订单
     * @return
     */
    AllowCancelResponse findNoCompletion(ApiCommonParam apiCommonParam);
}
