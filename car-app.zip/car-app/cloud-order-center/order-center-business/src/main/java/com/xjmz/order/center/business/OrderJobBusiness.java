package com.xjmz.order.center.business;

import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * 订单定时任务服务
 */
@Service
public interface OrderJobBusiness {
    /**
     * 取消订单：待支付超时的订单
     */
     void timeoutCloseOrderJob(Date date, Integer fetchNum);

    /**
     * 查询退款中的订单
     */
     void queryRefundIngOrder(Date date,Integer fetchNum);


    /**
     * 1小时未支付订单发送短信提醒
     */
    void smsOneHourUnPay(Date date,Integer fetchNum);

    /**
     * 支付成功，退款成功同步sap
     */
    void sapSyncJob(Integer fetchNum);

    /**
     * 同步权益失败的订单重新同步
     */
    void equitySyncJob(Integer fetchNum);
}
