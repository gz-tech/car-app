package com.xjmz.order.center.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Objects;

public class ExceptionUtils {

    private ExceptionUtils() {
    }

    public static String getMessage(Throwable t) {
        return getMessage(null, t);
    }

    public static String getMessage(String msg, Throwable t) {
        StringWriter stringWriter = new StringWriter();
        if (!Objects.isNull(msg)) {
            stringWriter.write(msg);
        }
        PrintWriter p = new PrintWriter(stringWriter);
        p.println();

        String message;
        try {
            t.printStackTrace(p);
            message = stringWriter.toString();
        } finally {
            p.close();
        }

        return message;
    }

}
