package com.xjmz.order.center.util;

import org.apache.commons.lang3.StringUtils;

public class DataUtils {

    private DataUtils() {
    }

    /**
     * 手机号脱敏
     *
     * @param phone
     * @return
     */
    public static String phoneMasking(String phone) {
        if (StringUtils.isBlank(phone)) {
            return phone;
        }
        String phoneTrim = phone.trim();
        if (phoneTrim.length() <= 7) {
            return "*******".substring(0, phoneTrim.length());
        }
        return phoneTrim.substring(0, 3) + "*******".substring(0, (phoneTrim.length() - 7) > 7 ? 7 : (phoneTrim.length() - 7)) + phoneTrim.substring(phoneTrim.length() - 4, phoneTrim.length());
    }

}
