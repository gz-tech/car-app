package com.xjmz.order.center.util;

import com.xjmz.order.center.exception.CommonCodeEnum;
import com.xjmz.order.center.model.enums.SnIdentifie;
import com.xjmz.order.center.service.AppNodeService;
import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * SN号生成器
 */
@Slf4j
@Component
public class SnBuilder {
    @Resource
    private AppNodeService appNodeService;

    private static String appIdStr;
    private static String appKey;

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Gson GSON = new Gson();

    private static final String NUL = "null";

    private static LoadingCache<String, String> snCacheBuilder = CacheBuilder.newBuilder()
            .maximumSize(100000)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build(
                    new CacheLoader<String, String>() {
                        @Override
                        public String load(String key) {
                            return NUL;
                        }
                    });

    @PostConstruct
    public void init() throws SocketException {
        int i = 0;
        while (true) {
            try {
                setAppKey(UUID.randomUUID().toString().replace("-", "").toLowerCase() + RANDOM.nextInt(10000));
                Integer appId = RANDOM.nextInt(10000);
                setAppId(String.format("%04d", appId));
                appNodeService.appUp(appKey, appId, getIps());
                break;
            } catch (Exception e) {
                if (i > 10) {
                    setAppKey("");
                    log.error("应用注册异常", e);
                    throw e;
                }
            }
            i++;
        }
        appNodeService.appDownOld();
    }

    @PreDestroy
    public void close() {
        if (StringUtils.isNotBlank(appKey) && !Objects.isNull(appIdStr)) {
            appNodeService.appDown(appKey, Integer.valueOf(appIdStr));
        }
    }

    private static void setAppKey(String appKeyStr) {
        appKey = appKeyStr;
    }

    private static void setAppId(String appId) {
        appIdStr = appId;
    }

    /**
     * 获取ip信息
     *
     * @return
     * @throws SocketException
     */
    private static String getIps() throws SocketException {
        Map<String, List<String>> listMap = new HashMap<>();
        Enumeration<NetworkInterface> n = NetworkInterface.getNetworkInterfaces();
        for (; n.hasMoreElements(); ) {
            NetworkInterface e = n.nextElement();
            List<String> ips = Lists.newArrayList();
            Enumeration<InetAddress> a = e.getInetAddresses();
            for (; a.hasMoreElements(); ) {
                InetAddress addr = a.nextElement();
                ips.add(addr.getHostAddress());
            }
            listMap.put(e.getName(), ips);
        }
        return GSON.toJson(listMap);
    }

    /**
     * 生成sn
     *
     * @param identifie
     * @return
     */
    public static synchronized String snGen(SnIdentifie identifie) {
        for (int i = 0; i < 10; i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(identifie.getCode());
            sb.append(appIdStr);
            sb.append(Instant.now().getEpochSecond());//截止到当前时间的秒数。10位长度
            //sb.append(DateFormatUtils.format(System.currentTimeMillis(), "yyMMddHHmmss", Locale.CHINA));
            sb.append(String.format("%04d", RANDOM.nextInt(10000)));
            String sn = sb.toString();
            if (NUL.equals(snCacheBuilder.getUnchecked(sn))) {
                snCacheBuilder.put(sn, "1");
                return sn;
            }
        }
        throw new BusinessException(CommonCodeEnum.SN_GEN_ERROR);
    }

    public static SnIdentifie getSnIdentifie(String order) {
        for (SnIdentifie snIdentifie : SnIdentifie.values()) {
            if (StringUtils.startsWith(order, snIdentifie.getCode().toString())) {
                return snIdentifie;
            }
        }
        return null;
    }
}
