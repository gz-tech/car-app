package com.xjmz.order.center.exception;


import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.flyme.xjsd.cloud.common.response.ErrorCode;

/**
 * 订单项目状态机异常
 * @author haitao.liu
 * @desc
 **/
public enum OrderStateMachineCodeEnum implements ErrorCode {

    PARAM_ERROR(221000, "状态机参数异常"),
    NO_EXIST_ORDER_CHIND_SN(221001, "订单号不存在"),
    ORDER_STATUS_FAIL(221002, "订单状态错误"),
    ORDER_STATUS_ERROR(221003, "订单状态不符合"),
    NO_EXIST_ORDER(221004, "订单不存在"),

    PARAM_ERROR3(221005, "参数异常"),

    ;

    private Integer code;
    private String msg;

    @Override
    public int getErrorCode() {
        return this.code;
    }

    @Override
    public String getErrorMessage() {
        return this.msg;
    }


    OrderStateMachineCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static OrderStateMachineCodeEnum getError(int code) {
        for (OrderStateMachineCodeEnum item:values()) {
            if (item.code.equals(code)) {
                return item;
            }
        }
        throw new BusinessException(CommonCodeEnum.SYSTEM_ERROR,"error code not found");
    }


}
