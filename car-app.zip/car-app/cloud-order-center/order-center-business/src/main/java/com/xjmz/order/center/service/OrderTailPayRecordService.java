package com.xjmz.order.center.service;

import com.xjmz.order.center.dao.entity.OrderTailPayRecordDO;

import java.util.Date;
import java.util.List;

public interface OrderTailPayRecordService {


    /**
     * 查询n分钟之前导入的尾款记录
     * @param targetDate
     * @return
     */
     List<OrderTailPayRecordDO> queryTailPayRecord(Date targetDate, int fetchNum);

    /**
     * 根据id更新记录
     * @param recordDO
     */
     void updateTailPayRecordById(OrderTailPayRecordDO recordDO);
}
