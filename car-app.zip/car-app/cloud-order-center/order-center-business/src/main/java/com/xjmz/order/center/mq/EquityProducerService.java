package com.xjmz.order.center.mq;

public interface EquityProducerService {
     Boolean sendEquityPayMsg(String orderSn);

    /**
     * 退款后同步权益
     */
    Boolean sendEquityRefundMsg(String orderSn);

}
