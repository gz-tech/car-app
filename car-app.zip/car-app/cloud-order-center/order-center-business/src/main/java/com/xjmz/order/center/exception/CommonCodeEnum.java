package com.xjmz.order.center.exception;

import com.flyme.xjsd.cloud.common.exception.BusinessException;
import com.flyme.xjsd.cloud.common.response.ErrorCode;

/**
 * @Author haitao.liu
 * @Date 2023/9/29 16:16
 * @description:00开头代表订单和支付共用异常
 */
public enum CommonCodeEnum implements ErrorCode{
	SN_GEN_ERROR( 201000, "SN生成错误" ),

	THIRD_SYSTEM_ERROR( 201001, "调用第三方接口返回结果异常" ),
	SYSTEM_ERROR(201002, "系统错误"),

	QUERY_PARAM_ALL_EMPTY(201004, "查询条件不能全部为空"),

	QUERY_PARAM_EXISTS_EMPTY(201005, "查询条件存在为空的情况"),

	UPDATE_PARAM_EXISTS_EMPTY(201006, "更新条件存在为空的情况"),

	USERID_EMPTY(201007, "用户id不能为空"),

	ORDER_SN_EMPTY(201008, "订单号不能为空"),

	SAP_CALLBACK_REQUEST_EMPTY(201009, "sap回调入参：XCXNO、XBLNR_ALT、MSGTY存在空值"),

	SAP_CALLBACK_TYPE_ERROR(201010, "sap回调入参：TYPE值异常"),

	SAP_CALLBACK_XCXNO_ERROR(201011, "sap回调XCXNO值未查询到订单记录"),

	;

	private Integer code;
	private String msg;

	@Override
	public int getErrorCode() {
		return this.code;
	}

	@Override
	public String getErrorMessage() {
		return this.msg;
	}


	CommonCodeEnum(Integer code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public static CommonCodeEnum getError(int code) {
		for (CommonCodeEnum item:values()) {
			if (item.code.equals(code)) {
				return item;
			}
		}
		throw new BusinessException(CommonCodeEnum.SYSTEM_ERROR,"error code not found");
	}

}