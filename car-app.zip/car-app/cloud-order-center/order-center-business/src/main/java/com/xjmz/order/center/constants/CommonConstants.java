package com.xjmz.order.center.constants;

public class CommonConstants {

    public static String ZERO="0";

    public static String ONE="1";

    public static String MAILCODE="send";
    public static String SIGNTYPE="RSA2";

    public static String LITTLE_CREATE="小定下单";

    public static String BIG_CREATE="大定下单";

    public static String LITTLE_TO_BIG_CREATE="小定转大定";

    public static String PAY_CREATE="创建支付单";

    public static String CANCEL_ORDER="取消支付单";

    public static String CANCEL_AUTO_ORDER="超时未支付取消支付单";

    public static String TAIL_PAY_SUC="完成尾款支付";

    public static String TAIL_UNPAID="待支付尾款";

    public static String VIN_SUCCESS="交车完成";

    public static String LOCKED_ORDER="锁定订单";

    public static String REFUND_ORDER="发起退款";

    public static String PAY_CALLBACK="支付回调";

    public static String REFUND_CALLBACK="退款回调";

    public static String BUSS_TYPE="I_FI030";

    public static String SAP_DESTINATION_SYSTEM="ERP";

    public static String SAP_SOURCE_SYSTEM="SMP";

    public static String BUKRS="5110";

    public static String WAERS="CNY";

    public static String PAY_TYPE="G";//收款

    public static String REFUND_TYPE="R";//退款

    public static String ZLSCH_BANK="T";//银行转账

    public static String ZLSCH_ZFB="A";//支付宝

    public static String ZLSCH_WX="W";//微信支付

    public static String SAP_SERVICE_NAME="MZ_SAP_SORDER_RECE_CERT";

    public static String SAP_HEADER_SOURCE_SYSTEM="SMP";
    public static String SAP_HEADER_TARGET_SYSTEM="SAP_PO_MZ";

    public static String SAP_MSGTY="S";//SAP回调成功

    public static String LITTLE_ORDER_TEXT="预订金";

    public static String BIG_ORDER_TEXT="定金";

    public static Integer maxSyncNum=5;//默认最大同步5次

    public static String SUC_TEXT="成功";

    public static String FAIL_TEXT="失败";



}
