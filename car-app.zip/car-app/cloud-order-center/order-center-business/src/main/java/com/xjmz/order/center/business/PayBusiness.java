package com.xjmz.order.center.business;

import com.xjmz.order.center.dto.request.PayCallbackRequest;
import com.xjmz.order.center.dto.request.PayCreateRequest;
import com.xjmz.order.center.dto.request.PayQueryRequest;
import com.xjmz.order.center.dto.response.PayCallbackResponse;
import com.xjmz.order.center.dto.response.PayCreateResponse;
import com.xjmz.order.center.dto.response.PayQueryResponse;
import com.xjmz.order.center.model.base.param.ApiUserParam;
import org.springframework.stereotype.Service;

/**
 *
 * 支付流水表 服务
 *
 * @Author haitao.liu
 * @date 2023-09-29
 */
@Service
public interface PayBusiness {


    /**
     * 创建支付流程
     *
     * @param payCreateRequest
     * @return
     */
    PayCreateResponse payRecordCreate(PayCreateRequest payCreateRequest, ApiUserParam apiCommonParam);

    /**
     * 支付回调流程
     *
     * @param request
     * @return
     */
    PayCallbackResponse payCallBack(PayCallbackRequest request);

    /**
     * 支付查询接口
     *
     * @param payQueryRequest
     * @param apiCommonParam
     * @return
     */
    PayQueryResponse payQuery(PayQueryRequest payQueryRequest, ApiUserParam apiCommonParam);


}

