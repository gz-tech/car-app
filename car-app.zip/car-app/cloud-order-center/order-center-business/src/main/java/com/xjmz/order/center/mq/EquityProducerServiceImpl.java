package com.xjmz.order.center.mq;

import com.xjmz.order.center.dao.po.OrderQueryDetailPO;
import com.xjmz.order.center.model.converter.OrderConvert;
import com.xjmz.order.center.model.enums.OrderStatusEnum;
import com.xjmz.order.center.model.mq.EquitySyncBo;
import com.xjmz.order.center.service.OrderService;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.common.message.MessageConst;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EquityProducerServiceImpl implements EquityProducerService {
    /**
     * 支付后同步权益对列
     */
    @Value("${equity.sync.pay.topic}")
    private String equitySyncPayTopic;

    /**
     * 退款后同步权益对列
     */
    @Value("${equity.sync.refund.topic}")
    private String equitySyncRefundTopic;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    @Autowired
    private OrderService orderService;

    /**
     * 支付后同步权益
     */
    @Override
    public Boolean sendEquityPayMsg(String orderSn){
        if(StringUtils.isEmpty(orderSn)) {
            return true;
        }
        boolean isTrue=true;
        try {
                OrderQueryDetailPO detailPO= orderService.selectDetail(orderSn);
                EquitySyncBo equitySyncBo= OrderConvert.INSTANCE.detailPoToEquityBo(detailPO);
                if(detailPO!=null){
                    if (OrderStatusEnum.LITTLE_PAID.getCode().equals(detailPO.getStatus())
                            || OrderStatusEnum.BIG_PAID.getCode().equals(detailPO.getStatus())) {
                        //处理payTime
                        if(OrderStatusEnum.LITTLE_PAID.getCode().equals(detailPO.getStatus())){//已支付预订金
                            equitySyncBo.setPayTime(detailPO.getLittlePayTime());
                        }else{
                            equitySyncBo.setPayTime(detailPO.getBigPayTime());
                        }
                        String msg = JSONObject.toJSONString(equitySyncBo);
                        Message message = MessageBuilder.withPayload(msg)
                                .setHeader(MessageConst.PROPERTY_KEYS, equitySyncBo.getOrderNo())//设置keys
                                .build();
                        rocketMQTemplate.sendOneWayOrderly(equitySyncPayTopic,message, equitySyncBo.getOrderNo());
                    }else{
                        log.info("orderSn:{} status:{} 订单状态没有支付成功，不同步权益服务",detailPO.getOrderSn(),detailPO.getStatus());
                    }
                }
        } catch (Exception e) {
                isTrue=false;
                log.error("sendEquityPayMsg orderSn:{} 发送消息失败：{}",orderSn, e.getMessage());
        }
        return isTrue;

    }



    /**
     * 退款后同步权益
     */
    @Override
    public Boolean sendEquityRefundMsg(String orderSn){
        if(StringUtils.isEmpty(orderSn)) {
            return true;
        }
        boolean isTrue=true;
        try {
                OrderQueryDetailPO detailPO= orderService.selectDetail(orderSn);
                EquitySyncBo equitySyncBo= OrderConvert.INSTANCE.detailPoToEquityBo(detailPO);
                if(detailPO!=null) {
                    if (OrderStatusEnum.LITTLE_REFUND_SUC.getCode().equals(detailPO.getStatus())
                            || OrderStatusEnum.BIG_REFUND_SUC.getCode().equals(detailPO.getStatus())) {
                        String msg = JSONObject.toJSONString(equitySyncBo);
                        Message message = MessageBuilder.withPayload(msg)
                                .setHeader(MessageConst.PROPERTY_KEYS, equitySyncBo.getOrderNo())//设置keys
                                .build();
                        rocketMQTemplate.sendOneWayOrderly(equitySyncRefundTopic, message, equitySyncBo.getOrderNo());
                    }else{
                        log.info("orderSn:{} status:{} 订单状态没有退款成功，不同步权益服务",detailPO.getOrderSn(),detailPO.getStatus());
                    }
                }
            } catch (Exception e) {
                isTrue=false;
                log.error("sendEquityRefundMsg orderSn:{} 发送消息失败：{}",orderSn, e.getMessage());
            }
           return isTrue;
    }

}
