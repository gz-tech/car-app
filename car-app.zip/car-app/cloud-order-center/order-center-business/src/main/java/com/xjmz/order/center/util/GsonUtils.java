package com.xjmz.order.center.util;

import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.Objects;

public class GsonUtils {

    private static final Gson GSON = new Gson();

    private GsonUtils(){}

    public static String toJson(Object obj){
        if(Objects.isNull(obj)){
            return null;
        }
        if(obj instanceof String){
            return (String) obj;
        }else if(obj instanceof Byte
                || obj instanceof Short
                || obj instanceof Integer
                || obj instanceof Long
                || obj instanceof Double
                || obj instanceof Boolean
                || obj instanceof Character){
            return String.valueOf(obj);
        }
        return GSON.toJson(obj);
    }

    public static  <T> T fromJson(String json, Type typeOfT){
        if(Objects.isNull(json)){
            return null;
        }
        if(Objects.isNull(typeOfT)){
            return null;
        }
        if(String.class.getName().equals(typeOfT.getTypeName())) {
            return (T) json;
        }else if(Byte.class.getName().equals(typeOfT.getTypeName())){
            return (T) Byte.valueOf(json);
        }else if(Short.class.getName().equals(typeOfT.getTypeName())){
            return (T) Short.valueOf(json);
        }else if(Integer.class.getName().equals(typeOfT.getTypeName())){
            return (T) Integer.valueOf(json);
        }else if(Long.class.getName().equals(typeOfT.getTypeName())){
            return (T) Long.valueOf(json);
        }else if(Double.class.getName().equals(typeOfT.getTypeName())){
            return (T) Double.valueOf(json);
        }else if(Boolean.class.getName().equals(typeOfT.getTypeName())){
            return (T) Boolean.valueOf(json);
        }else if(Character.class.getName().equals(typeOfT.getTypeName())){
            return (T) json;
        }
        return GSON.fromJson(json,typeOfT);
    }

}
