package com.xjmz.order.center.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjmz.order.center.dao.entity.OrderChildDO;
import com.xjmz.order.center.model.bo.OrderChildQueryBO;
import com.xjmz.order.center.model.bo.OrderChildUpdateBO;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 *
 * 子订单表 服务
 *
 * @author haitao.liu
 * @date 2023-09-27
 */
@Service
public interface OrderChildService extends IService<OrderChildDO> {

    /**
     * 插入一条记录
     *
     * @param orderChild 实体对象
     */
    Long create(OrderChildDO orderChild);
    


    /**
     * 更新通过sn
     * @param
     * @return
     */
    boolean updateByOrderSnSource( OrderChildUpdateBO updateBO );

    /**
     * 根据 ID 查询
     *
     * @param id 主键ID
     */
    OrderChildDO findOneById(Long id);


    /**
     *  根据支付流水号查询一条数据
     * @param orderChildQueryBO
     * @return
     */
    OrderChildDO findOneBypaySerialNo( OrderChildQueryBO orderChildQueryBO );

    /**
     * 根据退款流水号查询
     * @param orderChildQueryBO
     * @return
     */
     OrderChildDO findOneByRefundPaySerialNo( OrderChildQueryBO orderChildQueryBO ) ;


    /**
     * 根据订单号和订单类型查询
     * @param orderChildQueryBO
     * @return
     */
    public OrderChildDO findOneByOrderSnSource( OrderChildQueryBO orderChildQueryBO );

    /**
     * 根据 条件查询列表
     *
     */
    List<OrderChildDO> findList(OrderChildQueryBO orderChildQueryBO);


    /**
     * 查询待支付超时的订单
     * @param targetDate
     * @return
     */
     List<OrderChildDO> queryTimeOutOrder(Date targetDate, int fetchNum);

    /**
     * 查询退款中的订单
     * @param targetDate
     * @return
     */
     List<OrderChildDO> queryRefundIngOrder(Date targetDate, int fetchNum,Integer maxSyncNumRefundIng);


    /**
     * 查询1小时前未支付的订单
     * @param targetDate
     * @return
     */
     List<OrderChildDO> queryUnPayOrder(Date targetDate, int fetchNum);


    /**
     * 查询小定的订单数量
     * @return
     */
    Long selectLittleCountByUid(OrderChildQueryBO orderChildQueryBO);

}
