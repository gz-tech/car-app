package com.xjmzstarauto.store.order.client;

import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.order.client.model.param.AccountRemoveRpcPARAM;

/**
 * test表 brpc服务
 *
 * @author lin
 * @since 2024-09-05
 */
public interface OrderStub {

    /**
     * 检查用户是否可以注销
     *
     * @param uid
     * @return
     */
    Result<Boolean> checkAccount(String uid);

    /**
     * 注销用户
     *
     * @param param
     * @return
     */
    Result<Boolean> accountRemove(AccountRemoveRpcPARAM param);

}
