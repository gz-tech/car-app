package com.xjmzstarauto.store.order.application;

import com.alibaba.fastjson2.JSONObject;
import com.baidu.brpc.spring.annotation.RpcProxy;
import com.flyme.xjsd.cloud.dto.request.rpc.PointsOperateRpcRequest;
import com.flyme.xjsd.cloud.enums.PointsOperateType;
import com.flyme.xjsd.cloud.enums.PointsTransactionType;
import com.flyme.xjsd.cloud.rpc.PointsStub;
import com.xjmzstarauto.store.base.entity.Result;
import com.xjmzstarauto.store.support.client.NoticeStub;
import com.xjmzstarauto.store.support.client.model.param.NoticeEmailRpcPARAM;
import com.xjmzstarauto.store.support.client.model.param.NoticeSmsRpcPARAM;
import org.junit.Test;

public class NoticeStubTest extends JunitBaseTest{

    @RpcProxy
    private NoticeStub noticeStub;

    @Test
    public void sendSms(){
        Result result = noticeStub.sendSms(NoticeSmsRpcPARAM.builder().phones("13425088053").content("123").build());
        show(result);
    }

    @Test
    public void sendEmail(){
        Result result = noticeStub.sendEmail(NoticeEmailRpcPARAM.builder().emails("bingjun.lin@dreamsmart.com").title("111").content("222").build());
        show(result);
    }


//    @RpcProxy
//    private PointsStub pointsStub;
//
//    @Test
//    public void test(){
//        PointsOperateRpcRequest request = new PointsOperateRpcRequest();
//        request.setFlymeId(113543440L);
//        request.setPointsTransactionType(PointsTransactionType.GIFT);
//        request.setPointsOperateType(PointsOperateType.ADD);
//        request.setChangePoints(10000);
//        request.setSource("test");
//        request.setBizId("test");
//        request.setBizSn("test");
//
//        show(pointsStub.operatePoints(request));
//    }

}
