package com.xjmzstarauto.store.order.application;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Objects;
import org.junit.runner.RunWith;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = WebApplication.class)
public abstract class JunitBaseTest {

    protected final Gson formatGson = new GsonBuilder().setPrettyPrinting().create();
    protected Logger logger = LoggerFactory.getLogger(getClass());

    public void show(Object obj) {
        if(Objects.isNull(obj)){
            System.out.println("#####################");
            System.out.println("null");
            System.out.println("#####################");
            return;
        }else if (obj instanceof String){
            System.out.println("#####################");
            System.out.println(obj);
            System.out.println("#####################");
            return;
        }
//        String data = JSON.toJSONString(obj
//                ,SerializerFeature.PrettyFormat
//                , SerializerFeature.WriteMapNullValue);
        System.out.println("#####################");
//        System.out.println(data);
//        System.out.println(JSON.toJSONString(obj));
        try {
            System.out.println(formatGson.toJson(obj));
        }catch (Exception e){
            System.out.println(obj);
        }
        System.out.println("#####################");
    }
}

