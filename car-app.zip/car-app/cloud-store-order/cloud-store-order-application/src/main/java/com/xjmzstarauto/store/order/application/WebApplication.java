package com.xjmzstarauto.store.order.application;

import com.alibaba.fastjson2.JSON;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * 启动类
 */
@EnableScheduling
@SpringBootApplication
@ComponentScan(basePackages = {"com.xjmzstarauto.store.order"})
@MapperScan(basePackages = "com.xjmzstarauto.store.order.business.mapper")
@EnableTransactionManagement
@EnableFeignClients
public class WebApplication {

    public static void main(String[] args) {
        JSON.configWriterDateFormat("millis");
        SpringApplication.run(WebApplication.class, args);

    }

}
