package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.BaseGoodsDO;
import com.xjmzstarauto.store.goods.model.domain.GoodsDO;
import com.xjmzstarauto.store.goods.model.param.GoodsQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 商品 Mapper 接口
 *
 * </p>
 * @author wuchenghua
 * @since 2024-09-09
 *
 */
@Mapper
public interface GoodsMapper {

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_KEY + "'+#a0")
    int deleteByPrimaryKey(@Param("id") Integer id);

    @Cacheable(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_KEY + "'+#a0",
            condition = "!T(org.springframework.transaction.support.TransactionSynchronizationManager).synchronizationActive")
    GoodsDO selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(GoodsDO goods);

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_KEY + "'+#a0.id")
    int updateByPrimaryKeySelective(GoodsDO goods);

    int count(@Param("param") GoodsQueryPARAM param);

    List<GoodsDO> getList(@Param("param") GoodsQueryPARAM param);

    List<GoodsDO> findListByIds(@Param("goodsIds") List<Integer> goodsIds);

    List<BaseGoodsDO> findBaseGoodsFlow(@Param("id") Integer id, @Param("num") Integer num, @Param("gmtModified") Date gmtModified);
    List<BaseGoodsDO> findBaseGoodsBySort(@Param("pageNo") Integer pageNo, @Param("pageSize") Integer pageSize);


    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_KEY + "'+#a0.id")
    void updateShelveTimeById(GoodsDO goodsDO);

    List<GoodsDO> selectByCategoryId(@Param("categoryId") Integer categoryId);

    List<GoodsDO> selectByAttributeId(@Param("attributeId") Integer attributeId);

    List<GoodsDO> findByGoodsCode(@Param("goodsCode")String goodsCode);
}
