package com.xjmzstarauto.store.goods.utils;

import com.xjmzstarauto.store.base.entity.AdminCommonPARAM;

import java.util.Objects;

/**
 * @author wuchenghua
 * @date 2024/8/7
 */
public class AdminCommonParamTestMock {

    public static final String ADMIN = "admin";

    public static AdminCommonPARAM isNullTestMock(AdminCommonPARAM param) {
        if (param == null) {
            AdminCommonPARAM common = new AdminCommonPARAM();
            common.setAdminAccount(ADMIN);
            common.setAdminName(ADMIN);
            return common;
        }
        return param;
    }

    public static <T extends AdminCommonPARAM> void isNullTestFullMock(T param) {
        if ( Objects.nonNull(param)  ) {
            param.setAdminAccount(ADMIN);
            param.setAdminName(ADMIN);
        }
    }

}
