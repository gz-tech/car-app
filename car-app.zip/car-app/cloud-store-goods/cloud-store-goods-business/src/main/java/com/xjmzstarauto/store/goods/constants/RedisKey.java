package com.xjmzstarauto.store.goods.constants;

/**
 * @author wuchenghua
 * @date 2024/8/16
 */
public class RedisKey {


    /**
     * 拼接字符
     */
    public static final String CHARACTER = ":";


    public static final String ITEM_COMMON_CACHE = "goods_common";

    /**
     * 商品SKU
     */
    public static final String ITEM_SKU_KEY = "sku" + CHARACTER;

    /**
     * goodsId下的sku
     */
    public static final String SKU_BY_ITEM_ID_KEY = "sku" + CHARACTER + "goodsId" + CHARACTER;

    /**
     * 商品服务项
     */
    public static final String ITEM_SERVICES_KEY = "services" + CHARACTER;

    /**
     * Goods Key
     */
    public static final String ITEM_KEY = "goods" + CHARACTER;

    /**
     * 资源属性项
     */
    public static final String RESOURCE_ATTRIBUTE_KEY = "resource_attr" + CHARACTER;

    /**
     * 属性项
     */
    public static final String ATTRIBUTE_ITEM_KEY = "attr_goods" + CHARACTER;

    /**
     * 通过skuId缓存skuId对应的库存数量
     */
    public static final String INVENTORY_KEY = "sku" + CHARACTER + "inventory" + CHARACTER;

    public static final String INIT_INVENTORY_LOCK_KEY = "sku" + CHARACTER + "inventory_init_lock" + CHARACTER;


    public static final String INVENTORY_OPER_SUCCESS = "sku" + CHARACTER
            + "inventory_oper_success" + CHARACTER + "%s" + CHARACTER + "%s"+ CHARACTER +"%s" ;

}
