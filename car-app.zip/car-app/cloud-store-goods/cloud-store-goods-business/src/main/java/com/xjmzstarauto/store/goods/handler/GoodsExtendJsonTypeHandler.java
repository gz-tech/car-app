package com.xjmzstarauto.store.goods.handler;

import com.xjmzstarauto.store.commons.mybatis.AbstractJsonTypeHandler;
import com.xjmzstarauto.store.goods.model.domain.GoodsExtendDO;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author wuchenghua
 * @date 2024/8/11
 */
@MappedJdbcTypes(JdbcType.VARCHAR)
@MappedTypes(GoodsExtendDO.class)
public class GoodsExtendJsonTypeHandler extends AbstractJsonTypeHandler<GoodsExtendDO> {

}
