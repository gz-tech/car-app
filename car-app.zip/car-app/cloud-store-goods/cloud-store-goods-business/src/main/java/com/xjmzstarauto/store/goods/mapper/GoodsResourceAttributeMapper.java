package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.GoodsResourceAttributeDO;
import com.xjmzstarauto.store.goods.model.param.GoodsResourceAttributeQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.CacheEvict;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 产品+关键属性 关系表 Mapper 接口
 *
 * </p>
 * @author wuchenghua
 * @since 2024-09-11
 *
 */
@Mapper
public interface GoodsResourceAttributeMapper {

    GoodsResourceAttributeDO selectByPrimaryKey(@Param("id") Integer id);

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" +RedisKey.RESOURCE_ATTRIBUTE_KEY + "'+#a0.resourceId")
    int insertSelective(GoodsResourceAttributeDO goodsResourceAttribute);
    List<GoodsResourceAttributeDO> selectByResource(@Param("resourceId") Integer resourceId, @Param("resourceType") Integer resourceType);

    List<GoodsResourceAttributeDO> queryByResourceIds(@Param("resourceIds") Set<Integer> resourceIds);

    int count(@Param("param") GoodsResourceAttributeQueryPARAM param);

    List<GoodsResourceAttributeDO> getList(@Param("param") GoodsResourceAttributeQueryPARAM param);

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" +RedisKey.RESOURCE_ATTRIBUTE_KEY + "'+#resourceId")
    Integer deleteByResourceId(@Param("resourceId") Integer resourceId,@Param("resourceType") Integer resourceType,@Param("attributeId") Integer attributeId);
}
