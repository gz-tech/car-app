package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.model.domain.GoodsCategoryAndAttributeDO;
import com.xjmzstarauto.store.goods.model.domain.GoodsCategoryAttributeDO;
import com.xjmzstarauto.store.goods.model.param.GoodsCategoryAttributeQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 类目属性项 Mapper 接口
 *
 * </p>
 * @author wuchenghua
 * @since 2024-09-08
 *
 */
@Mapper
public interface GoodsCategoryAttributeMapper {

    int deleteByPrimaryKey(@Param("id") Integer id,@Param("modifierId") String modifierId,@Param("modifierName") String modifierName);

    GoodsCategoryAttributeDO selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(GoodsCategoryAttributeDO goodsCategoryAttribute);

    int updateByPrimaryKeySelective(GoodsCategoryAttributeDO goodsCategoryAttribute);

    int updateActiveByCategoryAndAttributeId(GoodsCategoryAttributeDO goodsCategoryAttribute);

    int count(@Param("param") GoodsCategoryAttributeQueryPARAM param);

    List<GoodsCategoryAttributeDO> getList(@Param("param") GoodsCategoryAttributeQueryPARAM param);

    List<GoodsCategoryAndAttributeDO> findJointPage(@Param("param") GoodsCategoryAttributeQueryPARAM param);

    int getCategoryNumByCategoryIdAndAttributeType(@Param("attributeType") Integer attributeType,@Param("categoryId") Integer categoryId);


    int move(@Param("categoryId")Integer categoryId,@Param("ids")List<Integer> ids,@Param("addend") int addend,@Param("from") Integer from,@Param("to") Integer to);

    int updateOrder(@Param("categoryId")Integer categoryId,@Param("id") Integer id,@Param("targetOrder") Integer targetOrder,@Param("modifierId") String modifierId,@Param("modifierName") String modifierName);

    Integer getMaxOrder(@Param("categoryId")Integer categoryId,@Param("attributeType")Integer attributeType);

    List<GoodsCategoryAttributeDO> selectByCategoryIdAndAttributeIdList(@Param("categoryId")Integer categoryId, @Param("attributeIds") List<Integer> attributeIds);
}
