package com.xjmzstarauto.store.goods.service;

import org.springframework.stereotype.Service;

/**
 * 系统配置获取服务
 */
@Service
public interface SystemParameterService {

    String getParameter(String key);


    String getPointsExchangeRatio();
}
