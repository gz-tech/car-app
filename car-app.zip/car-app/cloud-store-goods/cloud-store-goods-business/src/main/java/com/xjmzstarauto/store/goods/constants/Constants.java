package com.xjmzstarauto.store.goods.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author wuchenghua
 * @date 2024/8/17
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

    /**
     * 拼接字符
     */
    public static final String CHARACTER = ":";

    /**
     * 字符;
     */
    public static final String CHARACTER_SEMI_COLON = ";";

    public static final String PLANE_SALES_ATTRS_CHARACTER = " + ";
    public static final String PLANE_SALES_ATTRS_DESC_CHARACTER = ", ";


    public final static int FIND_BASE_ITEM_FLOW_LIMIT = 50;

    public final static int DEFAULT_HOME_PAGE_SIZE = 10;

    public final static int DEFAULT_HOME_MAX_PAGE_NUM = 50;

    public final static int DEFAULT_PURCHASE_NUM = 999;


}
