package com.xjmzstarauto.store.goods.service;

import com.xjmzstarauto.store.goods.model.param.GoodsDetailPARAM;

/**
 * API获取商品详情
 *
 * @author wuchenghua
 * @date 2024/8/13
 */
public interface GoodsDetailApiService<P extends GoodsDetailPARAM, R> {

    /**
     * 获取商品详情
     *
     * @param p
     * @return
     */
    R detail(P p);

}
