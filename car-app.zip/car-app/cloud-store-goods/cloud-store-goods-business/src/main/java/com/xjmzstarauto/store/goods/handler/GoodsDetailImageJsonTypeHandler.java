package com.xjmzstarauto.store.goods.handler;

import com.xjmzstarauto.store.commons.mybatis.AbstractJsonTypeHandler;
import com.xjmzstarauto.store.goods.model.domain.GoodsDetailImageDO;
import com.alibaba.fastjson2.JSON;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * @author wuchenghua
 * @date 2024/8/11
 */
@MappedJdbcTypes(JdbcType.VARCHAR)
@MappedTypes(List.class)
public class GoodsDetailImageJsonTypeHandler extends AbstractJsonTypeHandler<List<GoodsDetailImageDO>> {

    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, List<GoodsDetailImageDO> params, JdbcType jdbcType) throws SQLException {
        // 做写入操作时将对象转成json字符串
        preparedStatement.setObject(i, JSON.toJSONString(params));
    }

    @Override
    public List<GoodsDetailImageDO> getNullableResult(ResultSet resultSet, String columnName) throws SQLException {
        String extendJson = resultSet.getString(columnName);
        return JSON.parseArray(extendJson, GoodsDetailImageDO.class);
    }

    @Override
    public List<GoodsDetailImageDO> getNullableResult(ResultSet resultSet, int i) throws SQLException {
        String extendJson = resultSet.getString(i);
        return JSON.parseArray(extendJson, GoodsDetailImageDO.class);
    }

    @Override
    public List<GoodsDetailImageDO> getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        String extendJson = callableStatement.getString(i);
        return JSON.parseArray(extendJson, GoodsDetailImageDO.class);
    }




}
