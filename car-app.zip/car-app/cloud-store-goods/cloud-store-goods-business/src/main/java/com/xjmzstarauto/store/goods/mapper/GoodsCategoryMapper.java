package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.model.domain.GoodsCategoryDO;
import com.xjmzstarauto.store.goods.model.param.GoodsCategoryQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 类目 Mapper 接口
 *
 * </p>
 * @author wuchenghua
 * @since 2024-09-08
 *
 */
@Mapper
public interface GoodsCategoryMapper {

    int deleteByPrimaryKey(@Param("id") Integer id);

    GoodsCategoryDO selectByPrimaryKey(@Param("id") Integer id);

    int insertSelective(GoodsCategoryDO goodsCategory);

    int updateByPrimaryKeySelective(GoodsCategoryDO goodsCategory);

    int count(@Param("param") GoodsCategoryQueryPARAM param);
    GoodsCategoryDO getByName(@Param("name") String name , @Param("level") Integer level);

    List<GoodsCategoryDO> getList(@Param("param") GoodsCategoryQueryPARAM param);

    List<GoodsCategoryDO> getGoodsCategoryListByLevel(@Param("levelList")List<Integer> levelList);

    List<GoodsCategoryDO> getAll();

}
