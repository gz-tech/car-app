package com.xjmzstarauto.store.goods.utils;

import com.xjmzstarauto.store.goods.commons.enums.KeyNamed;
import com.xjmzstarauto.store.goods.commons.utils.RangeChecker;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * int 枚举值校验
 *
 * @author wuchenghua
 * @date 2024/8/7
 */
@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = StatusIntEnumValidation.StatusEnumValidationValidator.class)
public @interface StatusIntEnumValidation {

    String message() default "状态值错误";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    Class<? extends KeyNamed<Integer>> statusEnum();

    class StatusEnumValidationValidator implements ConstraintValidator<StatusIntEnumValidation, Integer> {

        private Class<? extends KeyNamed<Integer>> keyNamedEnumClass;


        @Override
        public void initialize(StatusIntEnumValidation constraintAnnotation) {
            ConstraintValidator.super.initialize(constraintAnnotation);
            this.keyNamedEnumClass = constraintAnnotation.statusEnum();
        }

        @Override
        public boolean isValid(Integer s, ConstraintValidatorContext constraintValidatorContext) {
            return RangeChecker.inRangeByValidation(keyNamedEnumClass, s);
        }
    }

}

