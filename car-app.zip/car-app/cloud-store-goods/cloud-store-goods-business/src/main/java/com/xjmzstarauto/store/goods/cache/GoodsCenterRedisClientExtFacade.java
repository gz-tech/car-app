package com.xjmzstarauto.store.goods.cache;

import com.xjmzstarauto.store.commons.cache.Finder;
import com.xjmzstarauto.store.commons.cache.ListFinder;
import com.xjmzstarauto.store.commons.cache.redis.AbstractRedisClientExtFacade;
import com.xjmzstarauto.store.goods.constants.CacheConstants;
import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.*;
import com.xjmzstarauto.store.goods.service.*;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 业务对象操作redis client
 *
 * @author wuchenghua
 * @date 2024/8/20
 */
@Component
public class GoodsCenterRedisClientExtFacade extends AbstractRedisClientExtFacade {

    @Resource
    private GoodsServicesService goodsServicesService;
    @Resource
    private GoodsResourceAttributeService goodsResourceAttributeService;
    @Resource
    private GoodsAttributeService goodsAttributeService;
    @Resource
    private GoodsService goodsService;
    @Resource
    private GoodsSkuService goodsSkuService;
    @Override
    public void finderMapInit(Map<Class<?>, Finder> finderMap) {

        finderMap.put(GoodsServicesDO.class, new Finder<GoodsServicesDO>() {
            public List<GoodsServicesDO> find(Collection<Integer> ids) {
                return goodsServicesService.findAvailableListAll();
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.ITEM_SERVICES_KEY;
            }

            @Override
            public int getExpiration() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });


        finderMap.put(GoodsAttributeDO.class, new Finder<GoodsAttributeDO>() {
            public List<GoodsAttributeDO> find(Collection<Integer> ids) {
                return goodsAttributeService.findListByIds(ids);
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.ATTRIBUTE_ITEM_KEY;
            }

            @Override
            public int getExpiration() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });

        finderMap.put(GoodsDO.class, new Finder<GoodsDO>() {
            public List<GoodsDO> find(Collection<Integer> ids) {
                return goodsService.findListByIds(Lists.newArrayList(ids));
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.ITEM_KEY;
            }

            @Override
            public int getExpiration() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });


        finderMap.put(GoodsSkuDO.class, new Finder<GoodsSkuDO>() {
            public List<GoodsSkuDO> find(Collection<Integer> ids) {
                return goodsSkuService.findSkuListByIds(Lists.newArrayList(ids));
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.ITEM_SKU_KEY;
            }

            @Override
            public int getExpiration() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });


    }


    @Override
    public void listFinderMapInit(Map<Class<?>, ListFinder> listFinderMap) {
        listFinderMap.put(GoodsResourceAttributeDO.class, new ListFinder<Integer, GoodsResourceAttributeDO>() {
            @Override
            public List<GoodsResourceAttributeDO> find(Set<Integer> ids) {
                return goodsResourceAttributeService.findListByResourceIds(ids);
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.RESOURCE_ATTRIBUTE_KEY;
            }

            @Override
            public int getExpirationSeconds() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });


        listFinderMap.put(GoodsSkuDO.class, new ListFinder<Integer, GoodsSkuDO>() {
            @Override
            public List<GoodsSkuDO> find(Set<Integer> ids) {
                return goodsSkuService.findSkuListByIds(ids);
            }

            @Override
            public String getCacheKeyPrefix() {
                return RedisKey.SKU_BY_ITEM_ID_KEY;
            }

            @Override
            public int getExpirationSeconds() {
                return CacheConstants.FIFTEEN_MINUTE;
            }
        });
    }
}
