package com.xjmzstarauto.store.goods.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * 缓存相关常量
 *
 * @author wuchenghua
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CacheConstants {

    /**
     * 缓存时间。1分钟
     */
    public static final int ONE_MINUTE = 60;

    /**
     * 缓存15分钟 60 * 15
     */
    public static final int FIFTEEN_MINUTE = 60 * 15;


    /**
     * 缓存一周
     */
    public static final Integer ONE_WEEK = 604800;

    /**
     * 缓存一个月
     */
    public static final Integer ONE_MONTH = 2626560;


}
