package com.xjmzstarauto.store.goods.utils;

import com.xjmzstarauto.store.goods.constants.Constants;
import com.xjmzstarauto.store.goods.model.domain.GoodsResourceAttributeDO;
import com.xjmzstarauto.store.goods.model.param.GoodsDetailContextPARAM;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author wuchenghua
 * @date 2024/8/19
 */
public class ResourceAttributeUtil {


    /**
     * 生成SKU选择KEY 111
     *
     * @param param
     * @param skuId
     * @return
     */
    public static String generateSkuSelectKey(GoodsDetailContextPARAM param
            , Integer skuId) {
        List<GoodsResourceAttributeDO> resourceAttributes = param.getSkuSaleResourceAttributeMap().get(skuId);
        Map<String, Integer> generateAttributeValueMap = param.getGenerateAttributeValueMap();
        return Optional.ofNullable(resourceAttributes).orElse(Lists.newArrayList()).stream()
                .filter(sra -> sra.getResourceId().equals(skuId))
                .sorted(Comparator.comparing(GoodsResourceAttributeDO::getAttributeOrder))
                .map(sra2 -> sra2.getAttributeId() + Constants.CHARACTER +  generateAttributeValueMap.get(sra2.getAttributeValue()))
                .collect(Collectors.joining(Constants.CHARACTER_SEMI_COLON));
    }


    public static String generateSkuSelectKey(List<GoodsResourceAttributeDO> skuSaleResourceAttributes,GoodsDetailContextPARAM param) {
        Map<String, Integer> generateAttributeValueMap = param.getGenerateAttributeValueMap();
        return Optional.ofNullable(skuSaleResourceAttributes).orElse(Lists.newArrayList()).stream()
                .sorted(Comparator.comparing(GoodsResourceAttributeDO::getAttributeOrder))
                .map(sra2 -> sra2.getAttributeId() + Constants.CHARACTER +  generateAttributeValueMap.get(sra2.getAttributeValue()))
                .collect(Collectors.joining(Constants.CHARACTER_SEMI_COLON));
    }

    public static String generateSkuSelectValues(List<GoodsResourceAttributeDO> skuSaleResourceAttributes) {
       return generateSkuSelectValues(skuSaleResourceAttributes,"，");
    }

    public static String generateSkuSelectValues(List<GoodsResourceAttributeDO> skuSaleResourceAttributes,String character) {
        return Optional.ofNullable(skuSaleResourceAttributes)
                .map(s -> s.stream().sorted(Comparator.comparing(GoodsResourceAttributeDO::getAttributeOrder))
                .map(GoodsResourceAttributeDO::getAttributeValue)
                .collect(Collectors.joining(character))).orElse("");
    }

    public static Integer generateSkuSelectOrder(List<GoodsResourceAttributeDO> skuSaleResourceAttributes) {
        if(CollectionUtils.isEmpty(skuSaleResourceAttributes)){
            return 0;
        }
      return skuSaleResourceAttributes.stream().mapToInt(s -> s.getAttributeOrder() + s.getAttributeValueOrder()).sum();
    }
}
