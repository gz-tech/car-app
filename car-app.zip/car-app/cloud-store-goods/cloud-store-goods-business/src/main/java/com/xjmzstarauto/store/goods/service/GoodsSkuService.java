package com.xjmzstarauto.store.goods.service;

import com.xjmzstarauto.store.base.entity.AdminCommonPARAM;
import com.xjmzstarauto.store.commons.entity.PageCommon;
import com.xjmzstarauto.store.goods.model.domain.GoodsSkuDO;
import com.xjmzstarauto.store.goods.model.param.GoodsSkuQueryPARAM;
import com.xjmzstarauto.store.goods.model.param.GoodsSkuStockEditPARAM;
import com.xjmzstarauto.store.goods.model.param.SkuInventoryModifyPARAM;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 产品规格表 服务
 *
 * @author wuchenghua
 * @date 2024-09-12
 */
@Service
public interface GoodsSkuService {

    /**
     * 插入一条记录
     *
     * @param goodsSku 实体对象
     */
    Integer create(GoodsSkuDO goodsSku);


    /**
     * 根据 ID 修改
     *
     * @param goodsSku 实体对象
     */
    int updateById(GoodsSkuDO goodsSku);

    /**
     * 删除Sku
     *
     * @param goodsSku
     * @return
     */
    int deleteById(GoodsSkuDO goodsSku);

    /**
     * 根据 ID 查询
     *
     * @param id 主键ID
     */
    GoodsSkuDO findOneById(Integer id);

    /**
     * 根据 条件查询一条数据
     *
     * @param param 查询条件
     */
    GoodsSkuDO findOne(GoodsSkuQueryPARAM param);

    /**
     * 根据商品ID获取所有的SKU信息
     *
     * @param goodsId
     * @return
     */
    List<GoodsSkuDO> findListByGoodsId(Integer goodsId);

    /**
     * 根据 条件查询列表
     *
     * @param param 查询条件
     */
    List<GoodsSkuDO> findList(GoodsSkuQueryPARAM param);

    /**
     * 根据 条件分页查询列表
     *
     * @param param 查询条件
     */
    PageCommon<GoodsSkuDO> findPage(GoodsSkuQueryPARAM param);


    /**
     * 根据商品Ids选择一个最符合的Sku的信息，筛选规则为 价格最小的、id最小的sku
     *
     * @param goodsIds 商品Ids
     * @return 最符合的Sku的信息
     */
    List<GoodsSkuDO> findOneSkuListByGoodsIds(List<Integer> goodsIds);

    List<GoodsSkuDO> findSkuListByIds(Collection<Integer> ids);

    Integer increaseDBInventory(SkuInventoryModifyPARAM param);

    Integer decreaseDBInventory(SkuInventoryModifyPARAM param);

    Map<Integer, Integer> editStock(List<GoodsSkuStockEditPARAM> goodsUpdateParam, AdminCommonPARAM adminCommonParam);

    List<GoodsSkuDO> findSkuListByGoodsIds(List<Integer> goodsIds);
}
