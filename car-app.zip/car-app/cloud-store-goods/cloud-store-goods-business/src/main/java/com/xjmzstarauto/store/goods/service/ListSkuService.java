package com.xjmzstarauto.store.goods.service;

import com.xjmzstarauto.store.goods.client.model.dto.OrderSkuRpcDTO;
import com.xjmzstarauto.store.goods.client.model.param.OrderSkuRpcPARAM;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 根据skuIds获取sku详情
 *
 * @author wuchenghua
 * @date 2024/8/20
 */
@Service
public interface ListSkuService {

    List<OrderSkuRpcDTO> listOrderSku(OrderSkuRpcPARAM param);
}
