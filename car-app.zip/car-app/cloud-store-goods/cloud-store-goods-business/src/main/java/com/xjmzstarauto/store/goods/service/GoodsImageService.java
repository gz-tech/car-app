package com.xjmzstarauto.store.goods.service;

import org.springframework.stereotype.Service;

@Service
public interface GoodsImageService {
    String mapToCdn(String path);
}
