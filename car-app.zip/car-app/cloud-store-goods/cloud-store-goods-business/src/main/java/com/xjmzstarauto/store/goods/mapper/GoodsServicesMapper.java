package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.GoodsServicesDO;
import com.xjmzstarauto.store.goods.model.param.GoodsServicesQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

/**
 * <p>
 * 商品服务项 Mapper 接口
 *
 * </p>
 *
 * @author wuchenghua
 * @since 2024-09-07
 */
@Mapper
public interface GoodsServicesMapper {

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SERVICES_KEY + "'+#a0")
    int deleteByPrimaryKey(@Param("id") Integer id);

    @Cacheable(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SERVICES_KEY  + "'+#a0",
            condition = "!T(org.springframework.transaction.support.TransactionSynchronizationManager).synchronizationActive")
    GoodsServicesDO selectByPrimaryKey(@Param("id") Integer id);

    List<GoodsServicesDO> selectAvailableAll();

    int insertSelective(GoodsServicesDO goodsServices);

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SERVICES_KEY + "'+#a0.id")
    int updateByPrimaryKeySelective(GoodsServicesDO goodsServices);

    int count(@Param("param") GoodsServicesQueryPARAM param);

    List<GoodsServicesDO> getList(@Param("param") GoodsServicesQueryPARAM param);

}
