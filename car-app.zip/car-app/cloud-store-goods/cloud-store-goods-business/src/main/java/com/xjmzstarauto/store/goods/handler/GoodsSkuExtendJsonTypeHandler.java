package com.xjmzstarauto.store.goods.handler;

import com.xjmzstarauto.store.commons.mybatis.AbstractJsonTypeHandler;
import com.xjmzstarauto.store.goods.model.domain.GoodsSkuExtendDO;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

/**
 * @author wuchenghua
 * @date 2024/8/11
 */
@MappedJdbcTypes(JdbcType.VARCHAR)
@MappedTypes(GoodsSkuExtendDO.class)
public class GoodsSkuExtendJsonTypeHandler extends AbstractJsonTypeHandler<GoodsSkuExtendDO> {

}
