package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.GoodsSkuDO;
import com.xjmzstarauto.store.goods.model.domain.SkuInventoryDO;
import com.xjmzstarauto.store.goods.model.param.GoodsSkuQueryPARAM;
import com.xjmzstarauto.store.goods.model.param.SkuInventoryModifyPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 产品规格表 Mapper 接口
 *
 * </p>
 *
 * @author wuchenghua
 * @since 2024-09-09
 */
@Mapper
public interface GoodsSkuMapper {

    @Caching(evict = {
            @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SKU_KEY + "'+#a0.id"),
            @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.SKU_BY_ITEM_ID_KEY + "'+#a0.goodsId"),
    })
    int deleteByPrimaryKey(GoodsSkuDO goodsSku);


    @Cacheable(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SKU_KEY + "'+#a0",
            condition = "!T(org.springframework.transaction.support.TransactionSynchronizationManager).synchronizationActive")
    GoodsSkuDO selectByPrimaryKey(@Param("id") Integer id);

    @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.SKU_BY_ITEM_ID_KEY + "'+#a0.goodsId")
    int insertSelective(GoodsSkuDO goodsSku);

    @Caching(evict = {
            @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ITEM_SKU_KEY + "'+#a0.id"),
            @CacheEvict(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.SKU_BY_ITEM_ID_KEY + "'+#a0.goodsId"),
    })
    int updateByPrimaryKeySelective(GoodsSkuDO goodsSku);

    int count(@Param("param") GoodsSkuQueryPARAM param);

    List<GoodsSkuDO> getList(@Param("param") GoodsSkuQueryPARAM param);

    @Cacheable(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.SKU_BY_ITEM_ID_KEY + "'+#a0")
    List<GoodsSkuDO> listByGoodsId(@Param("goodsId") Integer goodsId);

    List<GoodsSkuDO> findOneSkuListByGoodsIds(@Param("goodsIds") List<Integer> goodsIds);

    List<GoodsSkuDO> findSkuListByIds(@Param("ids") Collection<Integer> ids);
    SkuInventoryDO findSkuInventoryById(@Param("skuId") Integer skuId);

    Integer increaseInventory(@Param("param")SkuInventoryModifyPARAM param);


    Integer decreaseInventory(@Param("param") SkuInventoryModifyPARAM param);

    List<GoodsSkuDO> selectByAttributeId(@Param("attributeId") Integer attributeId);

    List<GoodsSkuDO> findSkuListByGoodsIds(@Param("goodsIds") List<Integer> goodsIds);
}
