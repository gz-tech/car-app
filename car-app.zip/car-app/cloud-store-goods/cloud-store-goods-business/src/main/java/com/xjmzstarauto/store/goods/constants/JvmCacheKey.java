package com.xjmzstarauto.store.goods.constants;

public class JvmCacheKey {


    /**
     * 系统参数缓存
     */
    public static final String SYSTEM_PARAMETER_CACHE = "systemParameterCache";

    public static final String SYSTEM_PARAMETER_KEY = "systemParameter" + Constants.CHARACTER;


    public static final String DETAIL_CACHE = "detail";

    public static final String DETAIL_KEY = "detail" + Constants.CHARACTER;


    public static final String GOODS_HOME_CACHE = "home";

    public static final String GOODS_HOME_KEY = "home" + Constants.CHARACTER;



}
