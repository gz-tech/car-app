package com.xjmzstarauto.store.goods.mapper;

import com.xjmzstarauto.store.goods.constants.RedisKey;
import com.xjmzstarauto.store.goods.model.domain.GoodsAttributeDO;
import com.xjmzstarauto.store.goods.model.param.GoodsAttributeQueryPARAM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 属性项 Mapper 接口
 *
 * </p>
 * @author wuchenghua
 * @since 2024-09-08
 *
 */
@Mapper
public interface GoodsAttributeMapper {

    @CacheEvict(value =  RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ATTRIBUTE_ITEM_KEY + "'+#a0")
    int deleteByPrimaryKey(@Param("id") Integer id);

    @Cacheable(value = RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ATTRIBUTE_ITEM_KEY + "'+#a0",
            condition = "!T(org.springframework.transaction.support.TransactionSynchronizationManager).synchronizationActive")
    GoodsAttributeDO selectByPrimaryKey(@Param("id") Integer id);

    GoodsAttributeDO selectByNameAndType(@Param("name") String name,@Param("attributeType") Integer attributeType);


    int insertSelective(GoodsAttributeDO goodsAttribute);

    @CacheEvict(value =  RedisKey.ITEM_COMMON_CACHE, key = "'" + RedisKey.ATTRIBUTE_ITEM_KEY + "'+#a0.id")
    int updateByPrimaryKeySelective(GoodsAttributeDO goodsAttribute);

    int count(@Param("param") GoodsAttributeQueryPARAM param);

    List<GoodsAttributeDO> getList(@Param("param") GoodsAttributeQueryPARAM param);

    List<GoodsAttributeDO> queryByIds(Collection<Integer> ids);


}
