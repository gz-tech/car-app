package com.xjmzstarauto.store.goods.utils;

import java.io.Serializable;
import java.util.Comparator;

/**
 * * 数字排序
 * * <p>
 * * 1. 从小到大排
 * * 2. 值为 null 的往后排
 *
 * @author wuchenghua
 * @date 2024/8/6
 */
public class NumberComparator<E extends Comparable<E>> implements Comparator<E>, Serializable {

    @Override
    public int compare(E o1, E o2) {
        return doCompare(o1, o2);
    }

    public static <E extends Comparable<E>> int doCompare(E o1, E o2) {
        if (o1 == o2) {
            return 0;
        }
        if (o1 == null) {
            return 1;
        }
        if (o2 == null) {
            return -1;
        }
        return o1.compareTo(o2);
    }
}