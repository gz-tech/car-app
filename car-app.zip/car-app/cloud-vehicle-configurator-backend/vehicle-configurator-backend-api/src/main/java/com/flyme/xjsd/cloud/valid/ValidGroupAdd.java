package com.flyme.xjsd.cloud.valid;

import javax.validation.groups.Default;

/**
 * @Author: wulong
 * @Date: 2024/8/26 14:16
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
public interface ValidGroupAdd extends Default {
}
