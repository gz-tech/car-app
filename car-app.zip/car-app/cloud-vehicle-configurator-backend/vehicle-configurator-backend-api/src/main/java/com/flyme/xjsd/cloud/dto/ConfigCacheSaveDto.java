package com.flyme.xjsd.cloud.dto;

import com.flyme.xjsd.cloud.dto.request.SkuGenerateRequest;
import com.flyme.xjsd.cloud.dto.response.CarModelDto;
import com.flyme.xjsd.cloud.dto.response.SkuResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: wulong
 * @Date: 2024/10/14 13:46
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ConfigCacheSaveDto {

    private Long id;

    private Integer currentStep;

    private Step_0 step_0;

    private List<CarModelDto> step_1;

    private List<SkuGenerateRequest.CarConfig> step_2;

    private List<SkuGenerateRequest.CarConfig> step_3;

    private List<SkuResponse> step_4;

    private List<SkuGenerateRequest.CarConfig> step_5;

    private Step_6 step_6;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Step_0 {

        private String name;

        private String code;

        private String description;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Step_6 {

        private String version;

        private String beginTime;

        private String endTime;
    }
}
