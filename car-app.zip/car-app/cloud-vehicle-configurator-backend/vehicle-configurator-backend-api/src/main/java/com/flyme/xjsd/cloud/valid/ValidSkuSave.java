package com.flyme.xjsd.cloud.valid;

import javax.validation.groups.Default;

/**
 * @Author: wulong
 * @Date: 2024/10/14 17:49
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
public interface ValidSkuSave extends Default {
}
