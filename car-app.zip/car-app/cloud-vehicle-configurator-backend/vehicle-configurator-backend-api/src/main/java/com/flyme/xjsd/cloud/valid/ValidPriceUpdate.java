package com.flyme.xjsd.cloud.valid;

import javax.validation.groups.Default;

/**
 * @Author: wulong
 * @Date: 2024/10/15 17:13
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */
public interface ValidPriceUpdate extends Default {
}
