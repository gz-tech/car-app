package com.flyme.xjsd.cloud;

import com.meizu.xjsd.platform.rocketmq.anno.EnableUnionConsumer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: wenhao.shi
 * @Date: 2022/8/19 11:38
 * @Email: wenhao.shi
 * @description: TODO
 */
@MapperScan("com.flyme.xjsd.cloud.dao.*")
@SpringBootApplication(scanBasePackages = {"com.flyme","com.meizu","com.xjmz.dreamcar"})
@EnableDiscoveryClient
@EnableUnionConsumer
public class CloudVehicleConfiguratorBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudVehicleConfiguratorBackendApplication.class, args);
    }

}
