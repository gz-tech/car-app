import com.flyme.xjsd.cloud.business.util.CombinedSelectionsUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Author: wulong
 * @Date: 2024/10/13 16:52
 * @Email: long.wu@xjsd.com
 * @description: TODO
 */

public class CombinedSelection {

    public static void main(String[] args) {
        List<String> array1 = new ArrayList<>(Arrays.asList("1", "2"));
        List<String> array2 = new ArrayList<>(Arrays.asList("3", "4"));
        List<String> array3 = new ArrayList<>(Arrays.asList("5", "6"));
        List<String> array4 = new ArrayList<>(Arrays.asList("7", "8", "9"));
        List<List<String>> lists = Arrays.asList(array1, array2, array3, array4);

        List<List<String>> results = CombinedSelectionsUtils.generateCombinedSelections(lists);

        for (List<String> result : results) {
            System.out.println(result);
        }
        System.out.println(results.size());
    }

    public static List<List<Integer>> generateCombinedSelections(List<Integer[]> lists) {
        if (lists.isEmpty()) {
            return new ArrayList<>();
        }

        // 处理第一个数组，生成所有可能的选择情况（每次只能选一个）
        List<List<Integer>> combinations = generateSingleSelections(lists.get(0));

        // 对于剩余的数组，递归地生成组合
        for (int i = 1; i < lists.size(); i++) {
            Integer[] nextArray = lists.get(i);
            List<List<Integer>> newCombinations = new ArrayList<>();

            // 如果不是最后一个数组，则每次只能选一个元素
            if (i < lists.size() - 1) {
                for (List<Integer> combination : combinations) {
                    for (Integer element : nextArray) {
                        List<Integer> newCombination = new ArrayList<>(combination);
                        newCombination.add(element);
                        newCombinations.add(newCombination);
                    }
                }
            } else {
                // 最后一个数组，可以选择多个元素
                for (List<Integer> combination : combinations) {
                    List<List<Integer>> multipleSelections = generateCombinations(nextArray);
                    for (List<Integer> selection : multipleSelections) {
                        List<Integer> newCombination = new ArrayList<>(combination);
                        newCombination.addAll(selection);
                        newCombinations.add(newCombination);
                    }
                }
            }

            // 更新组合列表
            combinations = newCombinations;
        }

        return combinations;
    }

    public static List<List<Integer>> generateSingleSelections(Integer[] array) {
        List<List<Integer>> results = new ArrayList<>();
        for (Integer element : array) {
            List<Integer> singleElementSelection = new ArrayList<>();
            singleElementSelection.add(element);
            results.add(singleElementSelection);
        }
        return results;
    }

    public static List<List<Integer>> generateCombinations(Integer[] array) {
        List<List<Integer>> results = new ArrayList<>();
        // 添加一个空选择（如果需要的话，根据实际需求决定是否添加）
        // results.add(new ArrayList<>());

        for (int i = 0; i < array.length; i++) {
            List<Integer> singleElementCombination = new ArrayList<>();
            singleElementCombination.add(array[i]);
            results.add(singleElementCombination);

            for (int j = i + 1; j < array.length; j++) {
                List<Integer> combination = new ArrayList<>();
                combination.add(array[i]);
                combination.add(array[j]);
                results.add(combination);

                for (int k = j + 1; k < array.length; k++) {
                    List<Integer> largerCombination = new ArrayList<>(combination);
                    largerCombination.add(array[k]);
                    results.add(largerCombination);
                }
            }
        }
        return results;
    }
}
